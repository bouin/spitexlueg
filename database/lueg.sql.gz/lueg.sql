-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1785485821,1785485821,0,0,0,0,2,'[]','a79cd3a9ee76cac8502dff95e52fc497a0868ca9','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1785485818,1785485818,0,0,'Editors have access to basic content element and modules in the backend.','pages,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,tt_content,sys_note','Editor','1','1',NULL,0,'1,3,4,7,199,254','pages,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,tt_content,sys_note','sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:alternative,sys_file_reference:autoplay,sys_file_reference:description,sys_file_reference:crop,sys_file_reference:link,sys_file_reference:title,sys_file_collection:hidden,sys_file_collection:sys_language_uid,sys_file_collection:starttime,sys_file_collection:endtime,pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:canonical_link,pages:categories,pages:rowDescription,pages:description,pages:author_email,pages:media,pages:no_follow,pages:layout,pages:no_search,pages:extendToSubpages,pages:no_index,pages:keywords,pages:lastUpdated,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:hidden,pages:sitemap_priority,pages:shortcut_mode,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:twitter_description,pages:twitter_image,pages:twitter_title,pages:doktype,pages:twitter_card,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:hidden,tt_content:imagewidth','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:shortcut,tt_content:CType:list','',NULL,'dashboard,web_layout,page_preview,records,media_management,user_setup',NULL,NULL,'','',NULL,'seo-pagesWithoutMetaDescription'),
(2,0,1785485818,1785485818,0,0,'Advanced Editors have access to all content elements and non administrative modules in the backend.','pages,sys_category,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,fe_groups,fe_users,tt_content,tx_impexp_presets,sys_redirect,sys_note','Advanced Editor','1','1',NULL,0,'1,3,4,6,7,199,254','pages,sys_category,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,fe_groups,fe_users,tt_content,tx_impexp_presets,sys_redirect,sys_note','backend_layout:hidden,backend_layout:icon,sys_category:hidden,sys_category:sys_language_uid,sys_category:starttime,sys_category:endtime,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:alternative,sys_file_reference:autoplay,sys_file_reference:description,sys_file_reference:crop,sys_file_reference:link,sys_file_reference:title,sys_file_collection:hidden,sys_file_collection:sys_language_uid,sys_file_collection:starttime,sys_file_collection:endtime,pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:cache_timeout,pages:cache_tags,pages:canonical_link,pages:categories,pages:sitemap_changefreq,pages:module,pages:rowDescription,pages:description,pages:author_email,pages:media,pages:no_follow,pages:layout,pages:php_tree_stop,pages:no_search,pages:extendToSubpages,pages:no_index,pages:is_siteroot,pages:keywords,pages:lastUpdated,pages:l18n_cfg,pages:mount_pid_ol,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:hidden,pages:sitemap_priority,pages:shortcut_mode,pages:content_from_pid,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:twitter_description,pages:twitter_image,pages:twitter_title,pages:doktype,pages:twitter_card,tt_content:pi_flexform;felogin_login;sDEF;settings.pages,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:uploads_description,tt_content:uploads_type,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:hidden,tt_content:imagewidth,sys_redirect:hitcount,sys_redirect:createdon,sys_redirect:description,sys_redirect:disabled,sys_redirect:force_https,sys_redirect:disable_hitcount,sys_redirect:is_regexp,sys_redirect:keep_query_parameters,sys_redirect:lasthiton,sys_redirect:protected,sys_redirect:respect_query_parameters,sys_redirect:starttime,sys_redirect:target_statuscode,sys_redirect:endtime,fe_users:address,fe_users:city,fe_users:company,fe_users:country,fe_users:email,fe_users:disable,fe_users:fax,fe_users:first_name,fe_users:image,fe_users:lastlogin,fe_users:last_name,fe_users:middle_name,fe_users:name,fe_users:telephone,fe_users:tx_extbase_type,fe_users:felogin_redirectPid,fe_users:starttime,fe_users:endtime,fe_users:title,fe_users:www,fe_users:zip,fe_groups:hidden,fe_groups:felogin_redirectPid,fe_groups:subgroup','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:shortcut,tt_content:CType:list,tt_content:CType:div,tt_content:CType:html,tt_content:CType:form_formframework,tt_content:CType:felogin_login','',NULL,'dashboard,web_layout,page_preview,records,web_FormFormbuilder,content_status,web_info_overview,web_info_translations,media_management,redirects,user_setup,system_log',NULL,NULL,'','',NULL,'seo-pagesWithoutMetaDescription');
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('95e047fe9442d520f2f0d1aaa596e7b621bd7940ab1d7b1c1b817468ecdda553','[DISABLED]',2,1785919023,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"26bea2265ccdf5b3dc2520c101e0710673600b44c37dcf41ccc9a0ca4fd43ab0\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1785485807,1785485807,0,0,0,0,NULL,'a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$TFg0NkZsWmk5aGk4bnFVUA$BGJukUX7cuIsM9jy9vxo77j2/sFDmhpuJXoN97a+9M8','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1785485807,1785485807,0,0,0,0,NULL,'a:18:{s:10:\"moduleData\";a:13:{s:28:\"dashboard/current_dashboard/\";s:40:\"a79cd3a9ee76cac8502dff95e52fc497a0868ca9\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:23:\"backend_user_management\";a:1:{s:13:\"defaultAction\";s:6:\"groups\";}s:10:\"web_layout\";a:3:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:0;}}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:15:\"1:/user_upload/\";}s:7:\"records\";a:4:{s:9:\"clipBoard\";b:1;s:9:\"searchBox\";b:0;s:15:\"collapsedTables\";a:1:{s:12:\"sys_category\";s:1:\"1\";}s:9:\"languages\";a:1:{i:0;i:0;}}s:6:\"web_ts\";a:1:{s:6:\"action\";s:29:\"web_typoscript_constanteditor\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:16:\"selectedCategory\";s:14:\"plugin.tx_news\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:18:\"pagetsconfig_pages\";}s:10:\"FormEngine\";a:2:{i:0;a:7:{s:32:\"750043f9a02785cc6557d2efe33fd403\";a:5:{i:0;s:9:\"Standorte\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=6\";}s:32:\"20ed475662b97ac33d3aa853a74f9c9c\";a:5:{i:0;s:8:\"Podcasts\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=2\";}s:32:\"7d9e144e24486a6668d151356ea4c9d4\";a:5:{i:0;s:8:\"Benefits\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=4\";}s:32:\"3af505b920348c1a79bf62ea28cbec90\";a:5:{i:0;s:15:\"Direkt bewerben\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:5;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=5\";}s:32:\"1994ba607913bcb01ccccf13fb01fccd\";a:5:{i:0;s:9:\"Bewerbung\";i:1;a:5:{s:4:\"edit\";a:1:{s:30:\"tx_powermail_domain_model_form\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:53:\"&edit%5Btx_powermail_domain_model_form%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:30:\"tx_powermail_domain_model_form\";s:3:\"uid\";i:1;s:3:\"pid\";i:7;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=ff46a12e7b58300860c26c8c0587d484bc66f9a8&id=7&table=&pointer=1\";}s:32:\"ca1d9f585ca31e6d709268bfa0021f7e\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:13;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B13%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:13;s:3:\"pid\";i:11;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=11#element-tt_content-13\";}s:32:\"c31c3d00814edbf9b2ddab640af3f55d\";a:5:{i:0;s:165:\"Vielen Dank für deine Bewerbung!&amp;nbsp;\r\nWir haben deine Angaben erfolgreich erhalten und werden uns so bald wie möglich bei dir melden.\r\nIhr Spitex Region Lueg\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:14;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B14%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:14;s:3:\"pid\";i:12;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=12#element-tt_content-14\";}}i:1;s:32:\"c31c3d00814edbf9b2ddab640af3f55d\";}s:16:\"opendocs::recent\";a:4:{s:32:\"a82241ea72bc024619639c48f162a817\";a:5:{i:0;s:26:\"Danke für Deine Bewerbung\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:12;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:29:\"&edit%5Bpages%5D%5B12%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:12;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=12\";}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:41:\"Lueg – mir biude &lt;br&gt; Lernendi us\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:97:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=1#element-tt_content-3\";}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:5:{i:0;s:4:\"Lueg\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=db234dfc3cb08c0591531032d7bcdf8f607b5ce8&id=1\";}s:32:\"fe7074c4b0d5bc578f49009883c1f002\";a:5:{i:0;s:103:\"Lehrstelle als Fachfrau/Fachmann Gesundheit EFZ oder als FaGe E (verkürzte Ausbildung für Erwachsene)\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:5;s:3:\"pid\";i:8;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=8b012a572dd3d778ab4f6bab63024f97ce96a562&id=8&table=&pointer=1\";}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:13:{s:28:\"dashboard/current_dashboard/\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"1ce970db96e4ed4091c0b4fe3d08ec49f6dfdd6b\";s:23:\"backend_user_management\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:10:\"web_layout\";s:40:\"810794d50511955451b96ca5d9f2491d83110ecd\";s:16:\"browse_links.php\";s:40:\"1ce970db96e4ed4091c0b4fe3d08ec49f6dfdd6b\";s:7:\"records\";s:40:\"810794d50511955451b96ca5d9f2491d83110ecd\";s:6:\"web_ts\";s:40:\"b31da63dfc18052edafc6c100c3d7a8754102356\";s:29:\"web_typoscript_constanteditor\";s:40:\"b31da63dfc18052edafc6c100c3d7a8754102356\";s:25:\"web_typoscript_infomodify\";s:40:\"b31da63dfc18052edafc6c100c3d7a8754102356\";s:17:\"typoscript_active\";s:40:\"b31da63dfc18052edafc6c100c3d7a8754102356\";s:12:\"pagetsconfig\";s:40:\"b31da63dfc18052edafc6c100c3d7a8754102356\";s:10:\"FormEngine\";s:40:\"1ce970db96e4ed4091c0b4fe3d08ec49f6dfdd6b\";s:16:\"opendocs::recent\";s:40:\"1ce970db96e4ed4091c0b4fe3d08ec49f6dfdd6b\";}s:12:\"mfaProviders\";s:0:\"\";s:11:\"colorScheme\";s:4:\"auto\";s:5:\"theme\";s:6:\"modern\";s:11:\"startModule\";s:10:\"web_layout\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:22:\"dateTimeFirstDayOfWeek\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";s:1:\"0\";s:10:\"inlineView\";s:337:\"{\"tt_content\":{\"2\":{\"lueg_podcasts_episodes\":{\"2\":\"\"},\"sys_file_reference\":{\"1\":\"\"}},\"3\":{\"lueg_ausbildung_items\":[\"1\",\"3\",\"2\"]}},\"tx_powermail_domain_model_page\":{\"1\":{\"tx_powermail_domain_model_field\":[\"1\"]}},\"tx_powermail_domain_model_form\":{\"1\":{\"tx_powermail_domain_model_page\":[\"1\"]}},\"pages\":{\"12\":{\"sys_file_reference\":[29,30]}}}\";s:10:\"modulemenu\";s:2:\"{}\";s:10:\"navigation\";a:1:{s:5:\"width\";s:3:\"307\";}}','{\"emailMeAtLogin\":0,\"mfaProviders\":\"\",\"colorScheme\":\"auto\",\"theme\":\"modern\",\"startModule\":\"web_layout\",\"backendTitleFormat\":\"titleFirst\",\"dateTimeFirstDayOfWeek\":\"\",\"titleLen\":\"50\",\"edit_docModuleUpload\":1,\"showHiddenFilesAndFolders\":0,\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":\"0\"}',0,NULL,'','studio_lg','$argon2i$v=19$m=65536,t=16,p=1$VkJwVVZZMDRBeHd2SVo1QQ$DIsREnvDiJqisnICS2cLmLWOk1cGyVsedaL6FQbIz2A','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',1785911422,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'1_37dc913efb26fa82',1786003841,'x�\��[w۸�(<�\�k����=�\��ĔċH\�q�\�q\�$�K�\�N\��>�--�%\��\�\�N�O�5�\�<��\�C?\���\����\n\0)J$%:7;yf�E(\n��(\�]���\�d\�\�\�\�鄍}�\��\�U\�7N�,L;\�d\���\��ӣ\��\�\�L\�Y��\���4�|\�q�r���\�u\��!\�7c)%Δ\�	K�\�d���\�7{R\�\�?�M��\\2;\�SF\�\�<�d1s���@?\�D!~�\��\�\'d΢y�H\Z�\�?Au^\�Q\�Ō�h\�B�DY\�0r(P\'/hݚ\�\�\�\�\�e�P?\�i�#N\�h*Z|F�9�\�\�9�\�4zCh\��wX��\�,t\�\�㗯{�O�wKM;\��]\�O�)QG���\�5�D\�*�.9z\�$~�1+U�\�\��1�TqR�:r�8�f��^\�h\n\�8>8 �og\�E\n��Γ\�^/}7�\�nOz\�(\n\�7\�\�s�|\�\�N�Lc\�}\�\�y~\0c3\�ÞG/\�K�����|\�\�\�I�\04g@��\�\�\�\�?��\�\�\�\�#\�\�\�\�\�j\�p\�Y��u\�\�\�x�\n\�b�WzqtvжNQ\�\�\�t��\�\�ӛ6�\���<|��э\�U�?}ٺfQ\��\�C\��\�\�\��\�F\�\�\����W�ڏ\�^OL\�=;r\�\����F\�q�$\�r���d\\�\n\�\�_�\�\�\0\����5q\�+\�UG�^(�I\0\�-KMY�GQ�ь!hR�[z\�s��r�\�8	|�%\�Ҕ*�C\�(KX��T�jH��\n哵S[��%\�\0&�M�\�	4\Z�\n�S�$����Ki2�\�q\�͸\�\����\�Ƨ\'Oώ�6>=|\���bYcml��M\�ѽ\��\�_��`M\�q\�)<YS�\�>Uj��\�\�\�\����\"\�,���p�3a�)Iʂ���e�\�ԝ�\�c�=;\�?�\�zt݀֏��K,�Tz�.N�4���ٌ\\e\����\�݄�1:\�V��jh�\�ϞdP�\�z��9ǗQ\r\�Mc%�Y\�,�,o�Wb\0��\�\�T��b\�@- �C�\\�؂<\�Tq�yY;uR��Z\�\�,��hհR;P}%Y�\���\�:Ҩ\�9�\�馪i��2\�ڦe[��\��I�sb62*A\�&\�\�b\�\nr\��\�Шi�`?�\�\��H�CŚ����N�\�hf�\�P\�~۱̲�Y\�:\n\"���W�r��\�\0Ǥ�4��\�H�\�KP���k\�}s\�\�\�\�uh�&�U00d`t\�Od\�\�b�WJ5\�`1[Ii�.\Z�Y\�<M\�e�\�j`\�\�%\�Z\��\�\�\�j\������Q��\���y	^�_Vx[�j�ۥy/\�\�H%�S�\�\�\�_��\�Bjl�^�X�E\�M\�\�\�\�zY\�\n��\�^�:�dI<s\�6��y�?\�ԑn��U4J\�\�V�|�(��(0\�SY�Z~�\�\�A�j�\nR�\� �\����\���3v��^�Cl���\���Vƻ��~�\�LuR7\�\��{I\ZG\�d�\'h-ɜ)�+4K&\�\���tL�\�y|����\�2p���IA��x{�#B��~���H�\�\�́S\��G~H��l�>>AK�\�#�\�,e)�\�g�bu��\�@ȧ\���Y\�\�)46�^\�OΙ�v\�kp��k9�)\�`��8\�qw�/�3M��\0�ΔC�\�&�\��\�\�\�\�\"\nN�	i���t@�%��q�e�yg�HpP��\��W�\��~J9&H�\�9\�a\�\��>&\0�\ri��A�\�\�w΃�s,��\�\���u��׿O�vw� \�j��\�S\�#w����X�\\\��\r�\�\���^�#��P\�aY\�,�\�,I�¢�g\�B\�9^<��/�z/�ŀ�\�龶\�+#A�\0m��B\�\0\�\�{\�tZ`�63\�@��T	\�&+p���,\��*P9e1�4����\�ܔ%��f\� R:�\�ũDgvPh\�\�؄\�n�i�l�C�\�O����g0O�ę\�\0\� �]\�L�ߗ4kT΃�L}�ϻ\�\���\�Ue�\ZZ\"ުe\�\�GʩZ�WQ�wטU\\W\�r�Y�\�X\�\�f\�,M��ElA<t���\�\�\�z\�.\�x1��a\�%\�\�(O\0O��\0}�FX{`���]>�\�~\�\�>\���N�>�\�tJ`\�Pd(\��\�!\�\�A�!H�A\�|\�u��\�aDq�V\�\�\�\�0̡s\�z\��^���0\�i�60~O��Ƒ[;\�4k\�.c:�\�`�5�bs��$�\�\�9T�\nـmYR\�r\n�<o\�\�xG�>p�4N}\'`+XJ\�\�\�\�l��JҬ�l	���*�%1�hJ=���$��5\�M1�\�\�y@\�\�N\�&@Z���u�h`9��\�\�W�?D�n]gy�\�o/*^�}�\�-�ސ�[RD\�=��*�����#��\�ߞQ\�y�V\�h�͑����.�E�ڽD�P�N��~\�{�૏�\�^��Q�\��K\�M�k2�ͫ\�ԟ��p��\�#\����P�^�\�9W\�`f\�4C�^%i���`D?�G.\��?~~n诱\�?~/\Z�\r\�\�K\�\�������\�K�P�[R�?\Zm\�x\�Ei4\�U9�o)�:\�fcU\�Ԯ6��\��T-Wt\�2W[,>��׶\�7\�B\�\�P*���f\�\ZqJ0\"	Y\�J\�\� \�G��T\�7q߀º&7����\�\�Ӱ��\"�\Z2�\0n}?HIf�qR3�\� oH��\�u�m\�uc\�%��\�\�o\�4I?�\�=�\�m\�r�W#�\�!���\�\�hU8\�b�\0���/\�\r�fA*�p�aD.�\�\�W\�;P�Q�\��\n�_�Z\�\�\�,�*���K\ZH��e�DAká\Z��B\��\��L|±\�p}\�J[^w��\�*f\�\Z�\�]r\�\�\�\�n�\Z%c��\'&s\�\��\�IK?K|WGM\�T��\�\��\�I�i]�(�+ ƧYP�\nh-e�\r\�WMg\�\��\�\�a9J\�jGĔ�9�\�Q|ɗm�!G%|],et���\��u4\�P>�\��Lyu��$h8u\�\�,���\�\�\�k\�\��#��uhS\\\�8�;�7\�+=\�m�\��N\�Ov\�Cx\�*\�\�~��\�B�#/\�\���\�%�\�z�\�?�\��ٿ\�@_�B7\�f�,@9\�&���V*.\�X����J\�o�\�R��b\�i�J�eKj�aE�s/\�4&,\�(\�n2\�Z��$kL�v6t�\rS2XDզ�\�BՉ�\�T\��m�,u�\r���V�ޏ��%)\�}\��4hcDc�Ä���\�=��\�v�\�q����H|\���\�DMQ��~Y`OF��w�\�\�\�t�\rXj��29\�\�3�iq\�p\��K�!�F0CL�\�8Cp�|�3��\�ZO{��[��b_�K; $�\�.\�\���\�%G\�[U\�\�	\�\\`\����i\�$�\�#\�����R_�/��̗��$\�\���U\�[5�Q�\�`z���.\Z��s\���Z8oU\�g\\\�bS[5�U�5[5+w\�{�˪�\�$�<Խ|FM{�/�\�x`F\�Ww���g::�y�o�\�h\Z2\�ř�\��\�\�\��a�|)\�7_R<\�QeRtTaޕ»�U�[ջF\�~��rSm���>�v�޲l~.چh]�\�3�(\n#\�Y�1�g�/�U\�[�]�\�*\�\�^��\�\�l\�\'�4\�\'إ\�|\'��#tI%\�\�\�݁\�\�-�\�\r�\��z��U\�[E�AQo�7U\�^\��.��\�w�U�[e��*S\�j-o�t�����xӆȟJm���U�\� �dIJ��f\�gi��\�\"\�}���P\�!y\�\�\�\�E7�\��\�\�\�f�\0�\�}���\��(���#\����rF\�Aƍz\\\�\�\�j9�/J\�B\�\�/D\�5�3�0�\�\�\�\����_�\�?\�\\����@lhNz\�?^\��\�a\��\�cq\�]\�!\"{\�P�\�\��w�\�����|��=m��I�6I\�\�r���$nZ�]z���\����t\�\\+g�[mt�\�\�{]KϷ�\�uiO\�\�\�\�\\�\�\�I�|ڍ���b�)4_�0ᡍ�o�|�(\�\��F\�.yD���<|��)ϩ!����\�\nA�ќ\�,�Y�9*p�H\�!��V\�\�\�\�SB\�\��7����J˿b��.y\�|\�G�Gĳ��\�4\�\�T�\���f�I7\�\"��\�w3Qլ�l��#\�\�\��\�\Zb8\�L`��KCE\'�]<\�\"4_\�\�b�y#��n\�\�\�\r%02\�\�FA\�e<{\�\�e���[��p�V~ގ��\�mNp/JI�\�d\�\�\�Ზ*uPN\�#\�>L\�u\��9��\�n\0�����\�3\�\�)��|\ZOz%\���b8.�%{\�}\"\�\r\\\�\�<;k�\�h�^\\6m�X�,Fu�\��S���ht68\�~�*8��ӭ\�@\�\�\�\�C\�bZ\�p5]e\�G�\�v\�\�	�\��-E\��A�bE=\�\�,@i͍��V\�m��5pM{D��=�=s�ҁ�Y�\�1��G\"@\�N�\�0`g׿�D-,N��\�\�0�h�\�1�q\ZG �A;�\�\�Ϣ\�,�s��m-FLe�>t<\�Q��3t\rMc\Z�5\�möM\�w\�,?O\�W�\�Q<��k!;��z \��zÑ۷\�\�\�\�M���\�\�?\�[T��B�8\�\�	\r�����l\�\�m�&\�\�\�k.\�\�0\�Ն�Y�jl\�2L�~\�Hb�K\��4���\�\r:�m\��\�вG\�\�t]Kw\�\�\�<]\�Dz�\"�FS����N�#�\'��O\�gE\�\�>k\�\��F_��a���#m8T��y�\�\��ȴ\�,`\��6�\�7\�e��>\�l8\�u��ĥ��2\�4�}a\�\0؊b\�$�qyݽ�LB\�\r��\���O���v����\�ϡ�\�L\�(\�4-��H>Ik�1-g�m� <f\�m;�5R5\��#K��\���x�7f%D\�\�\�\� �8\�S\�\��ɬQ_g���!<\�i_\�m\�]�*�e\�>9��+\�8\�=\�R�\�r�ǀ�2c\�\�Cn\�!Q\'L2\�z�̾��(���\�\r�\�`\�\�#g\�g�3`#�O\�$�\�\�%6�* >Yٞ懻D\�(K�5��c�\�\�\�N_\�F�\�}\�\0q\�iT\�\���||��x>5�\�ea�\�DN\��i\�5\�\�,�\Z�;2J\��n���\ntv�G\�\�Lj�p	��^*^@�\�8s\�\�����yk�� w;�\�#�\Zj_�\rK�4g0\Z2�\�9\��\03v�a\��\��\�\�]b\���y��\\��S�\r�ξ\��FJ	�a&\\e\�R\0E�\Z\�\�d�\�I@\��,�(\�9�;q@�g1s\�u�i�CR\ZO0��\�(�x\�\�0���p\��V&\�@>F<�\"2�px��j˗��]�3\�f؞\�z/p\�!T�@ń��\�l��`�\�\�-Γo�4~n���(���-\�||�B\�K:\r\�1&Z<\�f[�\�.�\�W\�R�R+�:��J�ӟ@ѡ؞`��̤\�\�\�\"$�{6\��\�\���T\�\\�2��\��M\��\�j�CJ��	\�NP�8`�P.�VR�PdN\�)\�R0�`җ�PLuLv\�}\\�\n\�\�\"Q$\�\�N	\�\"md��\�Ia�B@9˿\n(�W�\\��y�H�\�i\��T\�R\��GҤڸZ뒗��\�^4��Yc\rCwπ��qp#ᣀ�a�kT�F�j�_PL\�\�x\'؋�:{��۬\�A߶П\n\�:\rm\��z�!3\�y*o*0R�^(\��E\�!�����d��oSak����\�[q[U}\�T�\�E�\�ʢń]�,@�\�]�\�$KwI5w�PR�X��\�+\�\�h%E\�\��eC�\�*\"�K~\�\\P˥\�3�t�H\'�\�c�y�\�w\\�<9&�)�(40��d6���P\��\�CY\n���;�\�뗏p\�N)c�Ҟ\�R�\�\�E�s��#	\�\�\��BVV�rY�H^��=!��0v8m\�I�\�\�n͓�4�F�\�m\��\�I�Z,�.\���V<ݭe\�K\�{�_.e)��K����\�\�ܛa|z�1�.(\�_����\�\�\�$\�(\�\�\�sf�y�A�+^dv��\�\��NY �\�c!_\�\�\�$\��\���Sh�@D\�\\Dǯx�Oǃ,\�\�\�\�2\�3|\�|!4V\r�cX\�<\0���#�L\�\�Y;\Z�\�J�\�\�\�{\�\�EI\�߭KP\�^1#8��[Lk��g]�I���x\�[\�I���#�ٹ�\�ߤ;\�l\�[lA]�3c0|��oN\�\�J�����\�CG	\�\�OR\rw\���\r\�\�y\� g�I�p�\�(�np6/);\\���\"�и�6H\�I/�6\�m�\�,�ȗ�n\�r�6l�J\�gk5e�����7\�GV\�b�\�P>d?\�z\�4��\�\�ߋ&�\��:y7\�\�\�k�wm�a�f�IzzSe1\�\�y�6�\��\�c0U�\�1e\�Ch\�UP0\�\�A��\��`ŰL,cݚip�f2��\'��t��\�D\���j��\"��0+�\�\�\�I4�\�~�\�#ϣ\�V�l�I\�[mRt\�k\�&QL\�\�\�\�&�~8�c\'\n6\�\�R�	J8r��=\��׺�W|4�{�oR\�0�\�!?� �q�x\�\�\�\��9%��m\�\�\�D�BϷn\�VQ���UE7�FE1\�\�\�a5q\�!K�;�$VԎ�\�8\�\�\��9\�.�\\���\�J��4�ܹ��Rg�J�\�R\�\�VUlUE\�[UQt\�kT_�Oq�\�n)�gxgYD	\�4>�����Ņ�\�4��i@��\0\�W2p!]�\�k�\�{qW	��/�\�^\�Ax\\�1٘(j�\�kn\�\�V=|�rwF=\�yO\�\�ӳ\�G�g\�\�^�||\�\�\�\�`��\�R�q\�\���sFpS\�\�P%\�Q2\�K\�}@=\�r\'X�l\�&l\�@;\�[=Pt\�k\�w}\�\�ᔦwL�Fԙ�\���eG\�)�|{\�9\rC������\���Nr<�\�,�\�x\�\'(�\��ϋ�l:\�~#\�\�ꇭ~hy��n|��!e4�\�\n\�\�\�\��r\�\�\�˳\�;�\'p�rt̘ܚ�8�YJ\�)��b�\�G|�A[\�J�+�)��\�&t&,�\�Vl\�@+\�[=Pt\�k\�_��\�ϔD\�]s\�\\�\�K$��=�\�L[-s?\�\�\��\�h�\�~B;�o�;ڊ���oy+��n|�\��λ�c>�k�RR\�Iͧ\��\�w�\�Rq\�6�\�O<ʜ$\�Lx\�=�,�\�\�\�\�\�\��\�F�P�9{T��`�	Z@\�j��_�&�\�g�1\�?p�<\�/�$�5���˩�2\�v\�K�Ҝ�\�0/wh�3\�T*[\�Ȉ3\�x\�\�\�?jҧ\�¯o�}�\0^|Γ\�b��cyy&)�η\�a}\�\�\�\�1\'�\�H�\0\�\�3�t\�V�\�HQz,�\�\�duXe���k*`���,�\�q䰤}j��_��TD>\�\��	�L���n\�W\�1�)hRjWCN\�\�`YiFf\�tN3#,\�{Z��I�N��z�ds�K\�M��dSc\�\�!Po`�pP\��G�\�_K\�x$g�9?g�\���\�}\�\�E2}&\�\'7�9�\�2m\�, 4\�!�H��Ӳ�J&q\�ҋ��E�\�\"\�T\�\"،�T��|ҫ�>\�\�k\�\�\�\�\�\�\��\��d.�����Q1�!N��3;\�E\�3\���ҮX\�$\�0]c\�9J\�,U�\�!�\�D�x̒�j\�.\�\�Ę\�\�;~�%\"�L0��S�i-�;D\�<�Q\�\�M�ь\�~fل\�C\�{��4fq��>\�\�v>|637�\�\�yy\�R�	_\�p\ZB\Z\�sq�&�\�\�\�\'�b\�%�\�b_\�X&K\�x�\�4�Kw�p�l\�\�\�I\�\�\�Z(�A�ȋU�\�\�ߧy*�<]<�\�\��0�b\�\�\�\�^T�ч�+�ʺ\�V��\n\rmjG\�o؋\���\�2�fA*�\�yV\��3��1����\�wQ�*uw߶3�>\��\�\��)^\��IQ��<��zzrֵ\r\�\�;�\�g\�H\�5\��F��޷��i(\��ݼKj\�\��\�x�t���BJ\�-\�\�\�.���\�\"�Y-\�?\�S4As�Mx@�6�\0\�f\�\'��`A�>qe�AP\�%%��_�\��\�D6\0��@>ŋ�\�+~wUx^��/��z*_\�!R,Ƙ�8e\�!�M\�~	�a�&A*;n��쇘u\�\�\�qmJw\�\��\�\��\�%h��\�\�\Zdb��k�lY���\����H�\�]\�cx�\\\n��\�!q\�1\��0�uU\�UG\Zu=G�=\�T5\�6T\�C۴l�\�t\�\\\��J\0C��\�\�Tk8\�G�.;?�qN\�2_$\r��\�	-\��x\�xT�,~*\n���z�YD�GIw�ju�\�xk\�.ь�6�\����*�\�Ml\"�Z5 \�\�\�\nh�\�\n\�Z\�R\�O\�B�����\�H\�����eq���\���@Vy\�d}Ե���l\�8J�\�Z�����6��6D\�O�\�\�?ic\�U�d��\�\�EH�\�]r\�}\�\�\�k9��\�59\�\�Ц����\�4�&\��\�\�l�\�\��\�\�n��k�]MG�g1��&�0��~W3\nأ��\�9?6x�\��!갫l=zp�~B�����\�\r�i!\�-Wp,\�~X��U����\�\�W.P\�\�1�v�\�r=�)+K<�����(u9\�>$�\�.l��\�k\�\�\�����4V\0y\�\�\ZE\�\Z�bv\�!�;L\�\Z|\�j*@uK�\�W��k��\�T`\�cu�\�\�k�v�;�\�P\�\�`:\�\�]͂Gm��c�d�\�*\�\��r$v�\�@\�A��a\� P\��\�_�J��&ЦEU��&�\�\rh2PNE\�î�-P\�;�/\�\�v���\�*`�(\r/FF�\n=\�\n��\�H\�\�H�P\0�R�@���u輱�űu���TF\\4�t��Be\�s��\�,�R,�\�\�\��0LSy%\�\�&\�\ZX��r[6޲\�\�ecT�Ò\�\�[Hb���[`\�\�[6��l�A�Ԓ��<����6\�Ж��,ܖ��\�D\nb7\�,��?\�\�%Vv�PV�p\�X0\�J6N&��8�����Y�ŊS/7\�]��\�KV\�@Ո��P�\�|n�k\�w�\�\�Z�\�Q�6\� Ҍ�>m��a��[V�\�N�|���\�\�zN2\�qJ\�\�G�;9�i\�\���CdWM��\��\��ч\�Ы�5�.�}^\�V.c^	�\�Ŏ\�w\�/\"p]\�\�R�\"?�\n\�s\���bDݳc\�\���F7LM`F�\�\�^OVy\�\�\'u�XN�h��\�0Ė|\�\�߮\�s_���ܗ��\�\�+Fќaxy�\��n�\��sd\�(�\�\�\��wq;^\�ji�T��\�k�a\�Z�j[azǄ\�\�E^+P��\�\�q�)^k1>}5\�Ʈ\�8��;�ֽd\��\�K\�R\�6�\�\Z��.Oy:0\�x}y��\��\�>�p�4�[i�UJS}+M\�4]Dj\�JS\�\n\�/₣��T\�\�b}S�F�b\�\�P��}\�諪f^joǣ����\�H�oI\�����(��\��W5Iy\��\�>�\�-!t_\�\�#&\�K����_��5�\�\��\�_b\\+{M�e�d\��+@2\\�VL\�a�i�u\�U5\�4\�@�-×\�\�v�\�C:\r�Q!�\����\�z\�瑽\�\�\�\�Q�\�KN\�J\�;+y7\�M,}X\�o�Ќ�r\�\����Q\�w�\�N�|yB�\��\�\�g\r�\�\�2u\�\"K\��@)E\"O܃(v��>��\�\�\�\�\�5�	�6u\�6���i�\�\�.��Z���\�\�tyw]Q8\�-�~\�pN\��v\�\�\��g3c(�\�3F\�Ȳ\ZZ\�r�\0+��o�=\�]�\��M�vs�\�/\�e��\'��p\�m\'�W�Y�\�\�$Py��j��΀9�7��T\�\�\�;��=\�\0ZB�L\�\��Z�FWk�\�W\n\���\�\rU7�?\�\�\���A\��@�\�keB;ȸ�<�v粋�*�2\�&]g\�ٯ\�\�^\�=�u[\�\�;�\'��5\�1\�b\�\'nJ^:JQ�֊�\�aj��NDMե\�9*\�\�$\�]�Ӄ\�L�\�\�\�ߜ�-6\�@���G\�1\�70{i\"N\�`�\Z\���r�`��\�I��xom��=�\�\�۫�\�c\��\�By\�Rz#��jO\�R5`\Z,���b\�T\\!_\�5�A(\�)\�\�gs$DVw ��\�\�\�X\'\�4\nn\r\�\�tYz\�\�\�E����_\0�Vgl��S�gd\�\�\Z/8G�\�j4!���\��\�]\�\�HU�\�:\�V�Y|�>\�̒>�̪:k�f\r\�\�\�\�@g\�؟���\�\�ό\�\�,�&��\�t?u \�׹/\���I;W�\�\�`!�8a�޽\�&\�\�\�w\�KVF�?\�\����\�\'o\��?)\n�\����\���Ӈ�\�\�~8;z�;�>9C\r\�Y�\�\�\�x�\n\�)\�~�\�\��\�GG\��ӗ\�[_\�ztpvкf-�\�4���ɮ�\�vP���\�W��\��+�\�\�Li�m�zʐW\�v;O_���s\�	\�y@w\�ݿ\'��\�?�=��\�t^��\�\�*��\�a+�D���v;\'9\�p,���y�M��\�:\�U�5\�\�`��\�,t�k�s\�o\'?\��8�\�\�mjӄ�r\�\�/�AQ�̕�8;~\��`�\�mX�\n\���;0\��b]\0�	���X~z�\'}�\�\�&\�-Iݟ��b�f\�O�\�8O��\�CS��\n8\�=�,\�S�}\Z�W\�\�\�\��0�\r]p@)�W�����F\�9\�!|���m�E�\�\�\�O����HC\��ڂ]\��c��4\��uO`�b�gt�\�{�c�N\�j�*$\�\��ej�s�6�F�Qy}G\�!;\�\��\��\�C \�g�+	\�\�g\�\�J%\0\�4QrX|��&ƻ�4,�*\�\�S�\�^E�5D*�~]�\rȉ�d��#�ٚ<�\�7\�@�0�`1x��2��ŷ*�G��w4��\��I�\�\rA�`\�k�U�A��\�2�\n\nV��nD|�RiX|��\��[ŵ����ZAS�\�SG\��N�\�\�C];�\�	�e[)��O\�\�Z��t\\\'��\�2\'K�y\'f���1s�}->V\�ґ\�U�\�\�}U�:�Uc�P39	\�𢎙ėJhe����� \�\"N\�J-/R+���x\�K\�Ub\�d_|�C9�~�\�֐�\�:lV+\��؏b��N}��\�u�6D>1�)&���P;Q\�\�զ��S]+S�L+\�1\�\�\�KV\�0\�Z\�Ak�,\�j-�D6�A\��Z|o\�ML2=�fQ���\�q\�{�F�/�V/�\�+sE���S\�\�+ h�\��h\�~:qj��}$�G��\��@\�X�P7i�*��\�\�\�ky����\�n\�\�w)Kjǜ��pf�\�1CAN\�҂�y�:\�:q4\�i�#	�r��a\\����kب_�\\K\�D\�\�@����\�\�u�N\�\�PG�\\�\�\�CW\�t\�0\�_�cUKU@�\��x+0þ�Tx?R\�\� �As\�ZKȍ2;`c�7+r	Q�^E\r����:��e�\�VL��v�/t�<ǐj��w�\�G�ӂ�\�:V\�a�\\��/\�O\�\�[�0+�j�U\�\�\�����Yi�6��s��\�\���u�FL��B4���\�j�\�\�Ɯ\�f\�e��\�atX\�\�\�\�:�����)_\�q:/%[��8Z<֙|0sV(\�e�C~�S\�t^_\�\�?5\�J�\�^� �\�Yf\�i�Y�V\�\�\ri\�e\�(�5\�\00�\�G�qE�/�\�Nid\�M\�v�\\\�i�6\���x�\�C�ɨ\�-6VJԢ\�1.��\�V/\�\�%j	\�#\n�)X\�yH�\�?̗\\\��!\�\�lREڔ_ꆟȇ��K�ύuƿ_��R\�\�R��\�x\\��0c|��Ps���`��ٜ�����ji\�H|qba\�_L\�2>.�\�`���X\�\�_pS�Ʃ0\�\�;u�[~S\�c\�	ؽ|^@\�\�\�)g-ԭ),�.1M\�`\���a���s�CF\� y��\�\�\�X��/\'P�\�\�XI�u?\'Q;�Hn\�:\�x)\��\����\�\Z�\�\�;�<�	�\�\0��\�\n\�9\nN\"�����*�O�F�� �xBp\�#�\�\�\�\�h\�\�\�Xd�Z~�K\�0\�}NC\�R��]��\�΢�H6>\�\�^�\�\�\\\\�\�\�x\�wr\�\�\�\�eo\�98xc�s���xms\�|\�}�5\�1�}�5W��\0�J#\�\�_^&\�\�,\�ʡ�y=Yz]�o\�\�<]��\�r�\�\Z0�R\n�\�(���9�Z�v\�\�\�\�t�a\�\'%\�\�9\�#\�\\��s�-�\\�5��%G&o�*	s���~\�\��XйB\�]a��\��n��J\�\�\�%\�[|^M��!�7\�OW\�)\��YihP\�\�ի\�x\�|��<���XI��F��\�\�v$\"\�+�\�WQ4+�3��#�	,\�T&p\�!!\'����[\��[@(#�\�R\'.M�\�b\�\�-\�@7�%\��{;0�.[|\�Q��\�\�	_?\�\'�\�	�A�o;\�\0e\�\��7{g�1@à�\\V\�C\�QZ[K��a�/@�\�m��\�ϥk^&xtt\\�^ɃZy!H�\�I7\�KAwr�\��\�[\�\�/x#\�^���[+\�ͽ\'\Z3\�\�\��\�\�\�?:���\�d̺<̟����e7Cb��\�ty��O���S����\��H�#\�ť\�ۥ~��\�\�\Z��t��7Ɨj\�#炻\�I��~�N�\�\�\�\�cܒ�	�5\�\�\�h�Ǉ\'uW\�򫨞\�v�\�ԓ9�?!�\�\� �\�A�`�ϓ\��\�3<�\�\�?��\� ����\�\��)�]�gޥE\�xo��\�\�b6\�hJSy��\Z\�I\�I\�\0��Ȕ˓+�\�\�x<\� \�\�N\��\�\�\�_O\�<�!�0\�w\��}a\�\� �uQ䓋\"�\��S	\"��s�\�3�\�\�\���!r\��\�Py\�iz{�N\�~\"vȷM��h\�\�$\�7c�T\�\�\�\����\�oU\�#\�^O�{�����;�u\'\0l�;.;�/e�F�{7.\��\�~!�edA\0~ܘ\�2ҳ\����d\�=^\��K;ȿ�,\�g�}�{L��\��� J��h@+ V�\�\�&S~\�V)����0y ܴ�����^\�8\�\�\�\�*\�C\�*z�\�|��_\��1*\�\�9���W�%@�RL6�->�ɫ�{ܥ�v�\0\�\�\�O\"w\\@�\�4K0B��\"S6[\�H\0E\�<\�:��?���<ژ\�J/�\�M�\�i����r�FrN\\��+�o�oSk��\�1�\rbZ;\�\�6�\�-\�\� ��C\�h��\�1�\rbF�~Q�_{�����σn!�L\�1(J\'|(pp\'��U����[\�m�<�jJ�\�q˟E���\�C\\�\�?��˘<ȗ�c�6S^\�\�\�\��F\�\���\�ػ\\�,^fl|\�o�d\�\'ћ\"�(K�\���\�Ux\���T\�%\�jR\��\�~Ֆ�\"ޚ\�[�]�\�.Bl!��\�E�\�\"\�v\�fhl!��\�E�\�\"\�vb��]�\�.Bl!��\�E�\�\"\�vb��]�\�.B�\�\"D\�E(�a\�)s\�O|wlS\�Qt�H�\�/\�`\"���GρJ�X\�#�95\�\�\"�8=�\��\�\��F\�-P���\�\�Τ�P�\0��I\Z\�EBN�|I�\��\0\�+\�\�\�\�9%t����\��4\�\�ޱ/�\�\��\�lד%z\�IOz\'��NoQ�\'��\�\�\�7@�_e3S�y��\�!|�Ut���ḍ�tw�K\"xtĿ�K:�\�|*9\�r\�A�\'\\�<�+-\�\�\�e\��\�C\�ɱ\ZF�\�`.�\�l[+\�k@\��_j\�\'\�\�ې�R�;\�\�FNSy״}<K�\�O�.�|X��		�\�\�-v�\�\�8\�B\0;�\n\�5\���\�\�e]�\�\�\�Y$z���(v\�\0|\�՗r\�\�,\�\�\�co\�uvyoF��\�\�\�T�r�$7\�h\�V<\�Y�M.}\�S\�\�\�\n|r�,L\�w��r_~v\�)+\�>|\'r伈\\\�\�{F�e!\��x\�n��C��\�	8�I���IpL]L�\�\�\\;#�\�8�c\�C>\'0ǌ\\\�\�\�1\�.M�\�:]n���x�\�p\�UIC��!\�\�l;���a��\�˅1�~\��ː�>\�-\�ź\"�48���a��d��\�\�^E9�w \�E\"\�\�Op��σ8J\\�\�W\�\�h�\�.�\�L\�4\�\�,e\�Z\�\"\�lϩs�V�\�H\�dy�\�uo\�\�}ܥ�3q��n}\�C\���C8|�y\�\"\�g�v~4\�ۙ�n����k�B\�\n\�i\�\�]\�\�-J/A&\�7W��NGP�|:�`u�1>\"\�\��\"A\Z�s�;\�\�rR\�\���\�S^1\�o�]x\�L*\�f�\Z\�\�Y�\�yH\�i��́�w\"\�2�Q1M8�t\\\�+8|-\�\�O�!K{�sid\�Fz���i\�ܿ�d.��\�*Ʈ\�\�)�\�\�\�SG��0�a\�\Z��W�\�B\�cw.3\0~og�I\�\� \�)��@�{z\�\�!X\�Gd�\�\�1�9�\�V݀�\�\�\�Oȥ\\���|�0�\�\��\�B�0B��\�Y4I#�\0�؟��GQ\�Q\�Ō\�\ZLļ#2U\0yAC�\09ƭ8�Q|@y��\�qb��=���&s\\:�4�Fo\r]3��	|\�\�5\"�_�\�=>y\�-5\�D\�w1\�\r!\�h4T��f�\�[\�%Gy.J�6f�jP8�2?\���ƽ��\\�,N����t�t\���\�)\�\'�ѻQ<\�	�Z\�N\Z\Z���<y4\�\�*\�~\�[r+Ў\�CJ&��mЫ\�\�/\��\�^O��܊̔�\�m)�L\�\��V�jEA\�\�\"S\�>\�\�\�ad\����\n\�\�\�\'<\�C\�Hs!�Fq\�d��r�\�z���\�}O���sO���\�\���x�<�S����%��m\�Eb��*v..6�F�\�\�\�\�{��6��gF\�]Q�\�w�\�~G&\�-�\��\���&N:E\�*���//5eqD\�E�F|�n)쿼P\�8�U\�\�$\�1*,R\�r(�#\�AuY�~��$\�<�\�Ґ��\�e\�6X@��M\��K�8�˿4\\�\�\�~\�\�\�ӳ���O��~�X\�X[�\�CSwto���\�\�5]�ar|䯦L\��WΤ�x�L\�U�֥�ϓ�\��2\�gJ\�\\��M\�	\�1�\�槢T5�vu��2uË\�Su���\�p�\�\�UF��H�y\�M\����\�T�[`j���t�x\�9��jH/l\Z+	\�\n�`�dAx[���\�DR�\�<\�\�U�-\�\�M\�vI�\�\'�|\��\�\'oH^^,\�\\�\�\r\�ϫ��\�\�� �1YNL��\�@�,T^�3i\�y\����9\�\�|��\nF\�$�\"`�ÿR�a�\�JJSu\�p�l\�\�\�CY`��XJh�\�ȏ\�yJ\�rK�{.T\Z\�\�w@1^S$\�_\"yM��g�\�}q\�N\�T�f\�<����[H�MB\�\"�!E\�M\�\�\�\�zY\�\n��\�^�:�dI<s\�&.*\�%�Y�,SG���_e\�J�FY\�\�\�\�wN\�W@\�\�U�<ȋˈ�\nR\�}U�\����`���3v��^�Cl�n\�\�%E5u?��\rP\'�W�\�\�\�R\�d�\'�\r)s�\�.\�,�0\\�f\��Sgz\�\"l���wx�0x��Ż\�\��\0\�\�!F㻠�<~�\n�?\�C\�}d\�\�\�\��\�\�eඥ\�G��\�\�#!��c�\�\�2l\�\Z�R/\�\'\�\�Z\�\Z\�1r\0S\�O�\�I	^\�H\�j_2g����\�H\���I�(�O1t5����S~�g\�w\�\�(n�K�ߒܰ8\�2ݼ3H�,\�L\�\�\�\�<GㅟR�	_� \�\�0p��?\�[\�\�\�~\'H��Cu`�K\�9\�α��w\�Cb�S�ׅ\�_\\�>�J\�\�U�p��F�O��\�A\�cAr	?p��]�;\�e\�92�\�\�\�M�oJ\�o\���\�\�X�}q�|j1_j\�^���C�\�}m�WF�(\�01����\��\��mf\�d�4n��\�?\��B�\nTNY#\�\�\�ߦA37e	g�9��Np|q*љ��\��\'O��M\�&�\�\�6;/c��=r���<\�w\�\0\� �]\�L�ߗ4kT΃�L}�ϻ\�\��Ĥ\�m\�jZ\�\\\��QZ\�T-ȫ(ܻ�k\�*q��$�(�\�\�\�\\�S?\"\�\��\\�.\ZDKO�\�1�X\�Ŭ��ŗL��< <9\�\r�ko.|��\��E��\��\r�u\��\�QY;\�4\�\�xj\�\Z���\�k\�Hr\�\�s�`��۲�\�\�ly�\�歵��z?�\�B�&���g[\�T�f\rfK\0.���UQ�+�qES�\����\'q\�)o��<\���v\"7\�\�^$�+�DÝy�\�\�W��m]gy�\�o/³�7ގ\�m\�)�\�MU�\�\�\�Kˑƿ\�\�oOF�W/\�\�\�Kc�ݱ�w\�e�HQ��\�\n\�I\�TG﭂�>2�{=\�F-�/]7E0��\�\�6�6�W����S<j\�z��f#Ԯ�~|\�\�2�\�1\�\�\�WI\�x\�\�!��=*\�\�\�\r�5\��\�\�EC ��\�zi�|�\�Q�:����\�K�P�[R�?\Zm\�x\�Ei4\�E1�o)�:\�fcU\�Ԯ6��\��T-W\�eƻ\"�\�\r�\�\�3��g\�ٸD��\�\�-��/@\��#���n\��uMnt\'\n:s/p\�u\�\��\�\�e\0a\�=\�͐�̮?3\�\�T�\�^w�\�\�\�^7_\�_^�\�L�\�S9\�#\��\�V� �{5\������V�c-�p7	\��*\�,�|\�\�V�����\�w\"\�	_����\�@�\�}@\�\�B�h���TYY��A�6��A\�Z*�Q\\���\�\�\'k\�W��\�u�J��b�͡ѻ�J\�%\�x0T\�E\�b5J\�P3�OL\�\�\�\����~�������\�\�\���rӺTQ8V@6�O���c~�q��Uә\�x\�!\�x|\�G�Ҽ\�1\�~\�br_\�e�e\�Q	_K�%\�$yfM1�l��&S^]��&	\ZN]\�0�\'\��{��\Z��<�\�/X�6E�\��Ӻ{S�҃\�V(,9\\�\�t�d�<\�k�@\�^�S\�g�Ñew\�\�\��\�s\\=Z\�\�\�\�\�\�y��Q�l�Z�\�\�\��K;�$oo�\�yś*\�E����u\Z�\�jْZjX�\�\�6�	�=\nx���`\�κ\Z���\r\�`Ô�Q��j�Pub&1�\�m[.K]hA\�\�f�տ\�\�%nI�w\�v>\�\�\�X\�0\�h�bqO\�?��\�s\\\�g\��?�\�c1QS-\�_���ч\�i\���{#~�\�\�L�j/a��\Z\\�1��\��9\�Eΐ\�k=\��^\�oM��Ip|�G,퀐任pg؆~�uoU\�\�\'̭�=G\Z\�\�=H�G\�O_=1��0^\�K�/\�GI\�s�\�g�Ʒj|�\Z��\�x?\r]4pO;\�\�)�p\��\�Wϸ\�Ŧ�jv�fk��jV\�+\�P�U+�Iy�{�<���\�8_\�\�8���!�\�\0WM1\�tt�\�\�n\�#\�4\�$�q\�\�O!\�9\�+\�>�R�o��x��ʤ\�¼+�wg�z��w�\��\�\�\�8o}Z\��e\�2�\\�\rк\��g�QF<г.c\�^h���\n���U\���\�!�\�\�O.i��K��N(\�G�<\�J�\�\�1�\�/\�[v�J%\�=\�c����z��\�4n��9�\��]\n^?9\�\�p�L�\�\�+U��\�Z\�J\�7SOc\�\r�?�\�>5�v\�A6ɒ�h}\�\"�\�\�\\�E��Uu�\�C\�F^�\���t��\�L \�Ѿ\�5x\�~%3rD�r�\�s0Q��(9(r0�����$,d�B\�|PP<\�	㮸��	w���\�\��5z�3ͥ����6�\�\�.\��\�|f\�k=FG\�U\"�\�\�{ax�@<�	\��\�\�F[�dk�T�*/\�z\�J\�إ\�ʹ��\��\�O�͵rF�\�F\�\�b�k\��\�7�.\�i���b��\�\��>ɒO��\�6��M1����	mL|;\�D?|\�7�v\�#��d\�\�Y\�\�4LyN\r\�\�\�,mW2�\�\�fi\�2\�Q��XE��%��g6�\"�׿\�@��_PZ�\�t\�C\�#>\�<\"�U<\��\�T�\���f�I7\�\"��\�w3Qլ�l\�\�ۥ`�\�\�O�!�\�^\��ٹ4T\��\0\�(�\�|\�s�\�捰6�kO7��\�s�\�\�-;�\�r\�n-�\�\�Z�y;ޮ��9��L(%�&�u\'gx�\�Z�\�A9���0\�H\�B\�V»\��k�Z\�$���\�6\�i<\�Q��\�c��\���\�!3\�h7p�KP\���[G\�\�\�i����Zd1�\�7�\�D{��1��o,Qp^+H\r�[Á�\�\�Շ�Ŵ�\�j�\�\�!�L�?\�\�\�<\�D	Z�$�L�\�>�z��Y�ҚM�\�}\�puk\��\��U{h{\�H�K�\\\�cZ�D�̝\�\�	`�ή�ZX�B;׿a�!\�l�c\�4(�@�vp\�\�)�E�Y�\�<M\�Z��\�}\�x��5g\�\Z�\�4@k\�چm�\�\�\�Y~�\��\�-�x�g1\�Bv<\�1MM\�@�9T\��#�o�á��LuU����_��\���\��Oh\�\'\�$�`��oC5��v_sW�i�60ͲT{`[�a\�K�E�]��	褵puo\�Ёm�\�\�T��=2G�\�Z�\�F�\�\�\"$\��4�b��v�8)\�\�xrG<+��\�Y\�n\�5�\Z\�\r\�\�+\�\�PX�\�9�K#\�vг�ٓژ�~�YƠo\�C\�V�\�\\GI\\\�9*\�M�\�7V@��(&K\"�g\�ݛ\�$T\��8\������\�d\n*j\'Q�A!\�X[�\�/|��Q�iZ.{�|�\�cZ\�ZۀAx\�\�U\�vk�j�;TG�N-\�:�/\�\0n\�J���\�1�A6q����T�Y��\�,UcCx\�Ӿ>\�ێ�Uʘ}rGW�q�{\�3�\0�\�d�����7r��:a�9֣e\�]\�E��\rLo\�\�W9�>s��|�&!�\�\�.9�QT\�\�\�\�4?\�%*GY\Z���\�\0\�%�\�LOu��7�=\�\�{�KO�j�\�\�#^GJ���`\��0La\"\'l�4s��gz�M\r\��cL7`\�\�\0�:��#ty&5N�\�Q//�\�n�9\�w�\�T̼�MR����P\��A\r��چ��?�3\r\���tA�	��0t�\�\�\�\�.�z\��<Q\\�\�P�)\���\�\�\�o���\Zf\�U/P;�\�_\�zД_>�H����^\�\�y�\�\�	\�u��\�}\�\�\�\�\�\�F1\��#\�x�2y\�1\�	�Q�\���\�U[���슜�6\�\�\\\�[x��\�a���(&�u8f\�\'[>oq�|c<�\�s�$\�Eٯͧh�G\�\��B�^\�i0�1\�\�y6ۺwѥP�\n���Z5�\�\�\�U\���\�\�#Md&\�>n\�A �\���ί\�\�Фb\�B���\��Ⱦ(m\"�0�V����PJ\�LXw��\���r\�l��\�2�\�f)�]0\�\�Z(��:&�\��Naw�(�al��n�6�D̓pƤ0_! ��\�_��\�+}�˼\�\�OQK�,Ŝ4 M����.�K\�9ދ\�B6k��\�`b\�N^\�53n$|0�S\"\�p��\�\�\�\n\���ɌK��Xѯ�w�K�\��\�m�ɡ\�\�\�\�\r�\�0Ü��\"\�#\�\��B[4~b�P�\nL�\n�6�v\n[X���U\�wOUk_���,ZLؕ\��\�\�\�\�1L�t�Tsw%�����r�VRt\�A\�1Y6䊮\"\�\�\�\��\\\�=�K7�t�?&�<|\�ɓcr���B\�*K\�b(P(x\�졬�L\�\\��\�\�\�G�w���}i\�z)G{\��	\�9_̑a\�d�\0G!+�D��U$�Dמ���\�D;�6\�$\�t	�f�\�\�U�R�T�\�e��H-�JwR\�\\+�\�\�2\�%\�G��/���}\�%R~Ӏ�Y\�a\�\�0>=ށ�F\�/\�R\�\�\�sa�a\�i\�9\n3\�<͠\�/2��\r\�\�yJ�,��籐�prk�\�\�{�\�)4	V �q.�\�W<�ɧ\�A�\��wa�>p��\Z�\�1�{��\�GΑ^�\�\n\�\r^w%Mi\�\�5q\���$\�\�\�%(m���\�\�-�5^\�.\�$\�I\�?<\�-\�$^�\�\�\�\�\\\�oҝk�\�-� �.֙1�\�}�7�cyX%|\�T\�R롣�\�\�\'��;�ށ\�ņ\ng\�<��c��\��$_�H�\rE78���.�N\�}Kh\�`�\�$^���o\�\�fE�lepC�\�a[Uz?[��)S\r.m��\�>�rO�u���\�!�9\�C�q]��^4��\�\�ɻ\�v__��k\r�5pM\�ӛ*�yσ�	�o]_��\Z�\�)�gB������>��\�\'0+�eb\�\�tH�34��\�=�p�3T�P&�G�4T��\�\�/�Y_>N�8��\�\�\��\�yM�\�d�M\�@\�j��_�6�b\ZN\�6�\�\�1;Q�Ivה\�O`�S��\�\�i�\�Ž\�\�\�c|�\Z���\�8�q��3\�{Ol���\�\�(\�\�o3_�&�&�xyx�u;���䭢(�\�5*�9�8\���c?\rY�\�1� ��v\�\�).�_\�\�w\�\�\�ҿt�dV\�\�\�1�\�\�e�p�:\�\�P���R���b�*Z@ު��_���|��UwKQ<\�;\�\� J��\���t\�\�-.l��1|Ls\0:\0��\����\�\�\04_�<\�؋�J�|9\�R�\�\���\�\�DQ[\�P_s��\�\�#��3\�\�\�{/��=>:=;x~\��\�\�;�&^\�<}�\�{�\�D�3���.���*��I_\�8\�\���;�\�\r`[7a�\�A\�ꁢ_��뻞�4�c\��0�\�\�\'\�\0,;JoM\�\�{\�i�%\\5���t�\�<f\�<\�K>A,v?-|~^$d\�\�#^\�V?l\�C\�[�Pt\�k\�)���VgG/���^��\�1=����`\�\�\�Tā\�RJN1l{,?�\��\r\�?T\Z\\�LY\�\�6��0au�z`�ZA\�ꁢ_��6���x�$\�\�Ð/\�b^\"y�\�\��\r�e\�j���G��\�4�G\�\�|\�\Z\�)}�\�\�V�o\�\�[\�_t\�k�w\�\rx�\��]ۗ*�RN\�h>}з��3���ϵ�O}\�Q\�$g\�\�d�Lgw�_�Ɨ6���x͉أ�\�[M\�\�V\��\�4�G>\�)��\�\��$Q�9\�\\N��)�s^\�\�d\0�y�C˝ِ�R��\�2?@F�i\�S�^�Q�>�~}�\�\�\�\�s��5\�\�0I9�u�(\�c\'~�9!tFB\\\0��~� �k��GB�\�c�\�&s�#�*�Է]S�d\�4�#�%\�S,���\"\�1�O�ez-\�t���b��LA�R���r*/\�\0\�JC02\�p�aq\�\�2�Mjuj\�\�S$��]\�o\"(�%�\Z�\���zc���\�?\��bXR\�#9\�ρ�9\�\�\�\�.\�30/�\�+0i�<��\��Ֆ�hf�\�	D\0���\�W2���^\�,ʌ!��y�fܤڜ�\�^\�\�q�^\�v\��>\�ȗ߰%s\�����\�qʯd��\�a.Z�a\��v\�Z\'9�\�\Z˘�\�Q�g�\�\�)L� \�\�c�|Uc�wq�\'Ɯ>\�\�\�p,�e`�����Hsh!\�!2\�ȵ�oB�f�\�3\�&<2ߛħ1��ݭx\�A.�\�\�q���A�H7�\�\�#��L���\�\����\�5�,?\�`?\��.�\����D�2Y\�\�\�|�Q\\��fg/NR�-\'\�B�\rF^�B]^�>\�Si\�\�\�$�ׇ\��>\�x\�\�����>\�\\�T\�M�\�7UhhS;�^x\�^Lg�\��y4R��γ2���L�\�\�W净���T�����\�\�!70���M\�z\�O�\�\�\�\��\�\�\�ӓ��m\�n\�\�\�>\�F��\�\��\�5\Z�\��=tLCQ\�\�\�]R\�>W\�\�Uǫ���\�R\n�k\��~v�\�M�\�\�j���o��	ʘ�l\�\�\0��)p6\�P?U\��+�\r���0P.)\�\������\'�\�e\�)^�,^\�\�\�ʕ�|y\�S���b1Ƽ\�)#�\�Eh�\�K�\r�\�5	R\�q�Ud?Ĭ#.�W�k\�P�#׿\�/)@{T\� [�][e\�2\�gt\��\�D\Z\r/\�ã�\�R����\�)އ�\���\�:Ҩ\�9�\�馪i��2\�ڦe[��30\�\0TB�~�Z\���?\Z\�u	\�yX��sb��\"i`�\�Nh9\�;ƣjd\�SQ�]\�`\�;\�\"\n>J�KT�;4\�=�[\�v�ft�ѽ��W\�ob)Ԫ��\�V@\��\�pP�ֺ���z�\�\�wGzVt-��E\r\'��?\0�ʻ/ 룮e \�G�\�`�\�Q:}К\�U��au�!�~vǥ�aH��:, ]u��</B��\�\�����n_\����\�?\�f�6\r܏\��\�59ޯ��`��f\�w`v�\\\�\�j:\�=��m5��\�l\���Q�u\r\� \���\�����\0Q�]�`\�!Ѓ�\���\�݇\�n\�Oq�n��c1\�\�ꘌ�Ҍ\���/�r��n��h�����\�LaXY\Z\�\�\�E�\�\�!1\�va�E^\�Fw\�\�\r��\�+F\�(j\�\���\�\�azװ\�\�`\�TS�[�%�\�?]cՇ���\�G]s�\�\�t���\�aG\�j<j; 0\�$|V�x&��#��Ht\�\�\0\�cq�\�X\�\�t��z8U�}5�6\r(��\0\�4\�\�p\0o@��r*\��v-�l�\�`�� \��~Y\�ΰ\�\�V @ix12U\�T8dMG�X�FGb���\0\���R\���@\�\�/��uU�2\�!��\��*��;�U�di�by\����?���`�Z\�+1_7��\���۲\�?/�\��Ԯ\�B\�\rl\\\�[6޲\�\�ec\r���&\�\�Mll4�17��,�e\�,ܘ��&R�Ig����&.����;�����ǂ\�V��q2au\��\�e�<\�\�\�(V�\�x�a\�J\�D(_�b�FT\�:$\�s\\�����v\�J������f\�\�iS\�\r\�=<ز\�Tv\�\�K\�\�\�ho\�s�\�8�S*�Xg<2\��\�1L�v\�\�\'\"�j\Z}d\�O�Ќ>��^\�P�	u\�\�\�j\�d�r\�J ��(v\�k�\�bV�*��P�K?�d0�#\�C?�\�7�aj3\�w�\�z�\�{o?��\�rE��u�h�!�\��v��\�}D\�\�\r_�0�\�\�\�K]� \�u{]���#C^@ٍw��\����\�\�\�Z�VK�\n\�]^k\r�\�\�T\�\n\�;&L.\�Z��\�\\.P�\�(L\�Z�\�髱6vU\�\�4ݱ�\�%�\�_��☷!U_\��<�py:X\�ӁQ\�\�\�\�\�&\�\�����\�JӯR�\�[izǤ\�\"R�V��\�P��|����*�\�\�蛺5R[7��E\�{F_U5\�R{;\�Gt\�\�F�}Kb�\�\�\�\�GQ\�v����I\�\�f�l\�y�o	���v1�_Ⅽ��*寱��wL��\�Z\�k�-\�${�X]�\�\n�b�SMí����i�A\�m����#}\�i8�\n��\�׻?�\�]F美\�wp_r\�V\�\�Yɻiob\�\�B@�fԗ�\�\�\�\'�b�k�?u\�\�\�B|n�?k\�w���;Yڎ�J)y\�D�[\�\�	^\�^ގذ�M𴩓�A�\�O�\�wWw�\�\�\�=յg�˻\�\�n\�ӆs�\�ӎ�>\�=��C�|��12G�\�\�\n�\�X�<dx�\�	\�\r�6\�\�o:��\�\�~I.\�<\�퇓o;��\�Z\�L�&�\�k\�W\�t̱@���\\�*\�\�\�_\�)\��d\">\�\�J4�Z3���R\0�,ؽo��a��A��\�\�\rd\0��_+\�A\�M\�i�;�]�W��Y6\�:\�\�~��\�\�\�\�Q�\�b_7\�Q<�]`�)��a�>qS\�\�Q�:�Vm�P�\�t\"j�.�\�Q1v\'A�f\�%�_��\�\�oٰQJ\�\�<r���\�Kqr{\�X8\�\��[õ�O�$\�xk-\�	%�\�^%5X�7ȯ\�3�\�Id�P{\�~/����\�`y\��s�\�\n�:���\\B)O��?�#!��!�\�4�^G\�:�ئQpk��\�ҫ�f-J\�7��ȵ:c<옢=#�ޠ\�xa�9�DU�	�\�|\�/\�\"7F�:4\�i��\�\�k\��f�\��eV\�Y#5k8~�\'�8�\�\��<\�=\'}f4>g)4�����\�\�}�P\�@\�L2�ع\�M�\�	\�\�E7�.\��\�^�:0�����4>y���ɮ�\�\��\�`�c\�\�\�\��\�\��\�l\�õ��W,���\�I\�_@\�ޙ��\�^��x\�t�\�,�\�Z�㇨�KD�\�LK:\�n\�\�B	��6_*��NY�t)Sw;b��)\�\���Vy���7\�\�.�\�c�\��`\��\�\�\�3�{,~�Xa�\nVTS]���#{0tu�\�}\�a\�4M�4�\�}���(��\nz�H�\�7	\�\�\�Us4\�\�@��Ʊ�v;� �ip�$�$\�s$e�,\�\�E\�f{\Z�\�ϸ\�^���#\0=C��$|�r\�&P\�-N~,}=\�-\�ѵ�\����\�w�8�*¢\��t�T\�\04\�9g�d�G���\�9���\�__��r~\�/�\�G�\�.2ɀ��.h\�\�\�\�(t\�?L;lޤ\n\�B�~F\'8[�\�wE\�F�\�=)\�\�P+m�\�9r\'L�~AC`�xA$\��y:\Z�\'V&��5�{�ط��c<A3��Q^	\'�\�\�9�rV�\rh�\���d\�I\�_9��2��,*\��,�\�1�Oo\�w�	\�\�%�{�i\�\��\�H\�\�H\Z߹\�_�p\�s\��u8q\�ի-�h�\�`�\�ɡC\������	\�\�\�߄��~M�\�y�\"��\�\�w:e��i]�!/ �s\�\�B�M\�����\�sx\�\�\�\�\�\�\�\�Ƨ�O^?Q,k����fM\�\�=�%`���]й�?�?m�?5\�:h�\�wux\Zb�4\�\�Pgoo�\�`.}0��Q\�Or�\�Qz\'Ȟ�\�R�\�7�}\�B�5\�765�+G��b�{6UUfS\�hg\�oD��MW\�\��}XO�\�@S�B\�\���$\�~\��u\�\�3/J��\�\�L�o)�:\�fc�\�\�\�\�\���\�j�\�<lIB^P�P\�ߌ�>�\n�?6��9\�`6�q�\rxer�FNm�i�ߌ_[�P�\�ܫu\�\�G�jpꩍ\��\�m��|��(\'\�ވ~m��\�\�;�����#վ\�\�\�\�^b�!�U\�f\��^\��k#��1���\�4z\�@�ް�O�Hw\�14o4��\��6�\\3���l�\��\'�\�U\�\�4?�;\�ғJ\�V-;ye�\�\�\�\�Z�?�3jl�E�\0[k\�r�nk\�nm٭-��e��\�֖\�ڲ[[vk\����e;d�tN\'\��\�RgʊЯ1��\�򒿼bN�\�\�I]�.ƍ��\�=.3w;�1v6ϛ��a�2��K�hJ��,\�ա\�I\�\�._{\�\���Y�\�\�8ir�%��w;���\�-�M\� �gT,RY�\�\�\�&c�#Q~�u$\'o\�\�\�\�\��\�(�\��A���o\�\"\\��K\�8ܢ=K:\�[\�4��\�\�|�/\�U\�~T}ϑU�\���V?\�ΨZ\�\�a(�-hdT�\�N��\�>\�fc\'\�wk���l\�XM|�V\�=\���\�\�wu�\Zﮦ5V\�娧o\�!�\�k��SH�\�}w<\�_\�\�[|q#ܱ7�E.\�NI\�\�XN𠵱\'�6\�XNtf��P�/�ŁY8�\�wu��Q-\ZGUG:j�\�Q\�Պڈ�7�+\�y�A�E\�\�l�(![�\�<6WF�����~sEQ�B�s�\�LY�J>F3qd�\nq4!�\�G������8�@�8:g�A3qd�\\���\�@[�\�\� e�\�	\�Ԡ���Y�șt`5W�����押�\�6�\�9\�ݒ\�\�=2�E����r&����]lJY���+E66Fز0\�I\�\�B\�Y�\�a�,\�)eZ-Ks0�-Ks\�5G-K\�9b\�[�\�S\�R[��:r�{;\�c�H[\�\�\�\�!�_MU�G\�Co`��\�\�t\�j#g\�i�g�N_3�N\r���\�_\�'),
(2,'1_328092a9ccd7df3a',1786003842,'x��\Z\�r۸u?%\�\��SǢ�+�͌�8�[�㱔mw�\"@�1EpAж�\�\��?\�sp!Aڦ\�7\�\\\���D�0�VE�hP�-�3:�Ȣ\�BA^HV\�\�&\�h\�\�\�\�ήo\�\�jy}�~=KÔ,ƋI�&J(ac� \�\�,\�`Aó�7�3��և�!h4��=\�\�\�\�����ez6W[F\�\0.ʊd���H �\�P!��\��}��\�3�ϣA]1\�.�/^׿\�}?/Z}�z�R�\�K.\�緜\�J\nR��u��\Z�vVT/n\�^q��w���=\�r�\�U\�\�6kV���lbq���\\X\\]�N�ţ�\�s&\�\�b�\�i4 ���ͭ{\"�̊����\�Z�\�u#��\�\�:l��T�K��\��8\�R�d��<\Z//Zf7_}s�\�\�h2v\�\�^(�R�\�.,f�\�\�\�\�pS$5[I�7\�GA�;�r�P�\�w~���߲t�\�\���\�\�dF\�\�+�j�2[Е�t�\�\�=#\�Hu\���\�\Zp`�\�5_\�B�]@Ն\�%\�\�л𵹋A\�@\��w\�RK�sM��QX�QW0\�/\�dnl)\��\�\�n\�\�\�\��;%��L���\�\"D�J3�Skf8�\�;5\�\�&!�$9op\�mZ\��ټ�\����\�\��\�#D�R)\�\'\�\�\�Sc:�N�\�/S\�\��j�@!dBd�\��hq}\�g��\�\�j_\�\�MV\�\�zod���`\�Y\�;n\�\�\�:\�{$\�,Ƨ�L�\�\�4oP�]o����ʷ+?\�Ἑ�,\ZN�{C�h�\��\�x\�\�Ĩ�l\�\��۾\':�V\0�zfI-Oێ�\�\�\�E\�\�\nQ\�}�\n�\�\�;�;v0>Z\�3��}Ƥ1�=,5 \�7��+\�D\�\�i�x#\�\�O7j�\���\��H�\�<\�\�\�J�\�I\�\�ޘ�T���lI\�\�o�\�(:\�1�(����Fx���$\�_5�(\�-;H\�=uL4\�\���MM\r\�k:h7K�(!~A�\�c�_P-�Dnb\�\�q�k7���\�q�8�\\f\�nC`7�Dj��\�ȴ9a\�\�\��\�w\'%\r\�\�w�z\�`C\��\�sZ�\n��+�׶�d=\ZN\�Ч\�\�A�ʫs�\�J�\�8e�\�P���F�v�O��\�%��%�\�d�9�׬�\0m�ǌ�\�+s�3�\�\�\�\�\�\'�_�?�-\�\�|\�ϬJ�@�Ħ\�s̬��w\�GL\�\�\�Ht\�3\�ke�\�\�\�\�J�\�z���\�\�^�@A8�>ip�\'\�\�\Z�\���Ax\�\0����\�\n��=�\�\�#\�E�\��RVL\�<~2C��\�\rf\rvt�5p�\'2[�*fMY�<Q\�*4�\�\���\�\�H\�e�mm)D\�ik���\�P\�<\�h�\�p��^|\r�O\�\�\�ϓG\�S\�Y6/N�\�N\�\�W\�\"J\�$\�n\�ap�MJ���E�\�*\�s\�%�86ˌ�N���\�x�O��\�S\�\�Nx\0�R\�]\�2�\�\�ui4\��\�|!\�\�B�\\\Z*��\�\�\�\�޶x|�\�K�\n\����\'\"��\�+\����P\��\�\'�Y��\���\�`!\�6\��O\�\�`|\�W��~.m\�\'\��\��\�A\�}q�\Z>\�|S��n�Q�z6\�\�\�J�}�г�d\�y�1�\�u�ƌ\�\�p8\�\�P�C!➲\�(e��B��\�;\r�a��.d�\�g\��^\���u4.\��^�\�%�\�;V�D�\�n\�~F3�\�\�Y�Vy�b|��\�}�nyE�ɃaC!�\�z�x-��8��K%�[\�2\nF�4�ˁ�!\��m�^a��m�\�K3�I\�j�\�\�\�L�]*Ȇ$ ��\0a��\�,\�\�lQ~K|\�r\� \�愄�\��ǘV,\� 蘘ݦ\�#N\�\�h\nJIk\0����&�\�\�\�\�TO𝖮��\�\�붹�Q��KQ㬊���sCsSl�Y̋8I�Ds��D��ЊkT3\�\�\rAy�w��\�\�$o�\�\�S!�\n�<\��S3\�\nʞ�YňHvzʷqOF\0\�\�\�DؙsS�+c)c\�FG�`\�\�.͞�1t�Ŗ���څ\�\�W4���Z\�\�\�z\�\n�-3Bs��6^`:\�kjU\'�2\�D�A���\����{^l�>�;�9����\�\Zj�\�޶`L|L\��5�Oe/WVؽ�݀\�0�e`�ᣙM�\nn(N\�I�Z���o.W\�\�\�\�?_�k\�l4Z\�hU�\�K\�2n�\�y`B\���K0\�F�.���A\�[7�a\�;�\���\'&�ZG6���:��Koj�5CeM\��Ĺ)ʚ��c!J�c֎T�0Ӧ\���p\�\�޺j�\�Q\�\�m\ni\��# j��\���֯���\�Ǎx�\�\�՚�1ǘ{\��8\������\�Ě\��&`X\�\�(\�vd\�D\�\�l\�	%\�)\�2\�=\�0\�6_��2\�ɂM�Q\0,�u�qx\ZEݼӢ�t\�\�\��-x\�d\�sG�&\�vՄn\'��9\�R�yY\�PRR\�\n�\�\��wz�\�^ \�H�\r�]��\�ޱ�&X\�/$;BVoA��۹�\�	\�-G\�\�*�\�\'��t�s\�\"\�\�\�S��\�	��\0\��5�h�\�EQ\�\�~�d�۷.\��\�)���\�\�ߜ~&�_�~И���\���W�P\�/M�aVܳ�\�\����\�\�Yr�\�G]M\�\"ϋu�-�>�i��;0\�\r�\�t�ԯ��\�`\rk\�\�o@�\��R��8|D�_\�3[sl��m\�1�\�4��\�F#\�N0ƈH���3�*�\�\��\����A�F��\�,�5\�#l\�>Q�ϴ򦠰����Ԭ8>T5[�\�՛<K\�\�=\�\�\�.~�T�bB�4\�\�O�K�%q\'�շ\�\�*\�Z�k�a\��\�yڑ\�x<2F\�E�\�Y\�b�~o�\�\0@\�\�mAS\�E�\�װĳ\�o���S\�\r�\�Oe\�\�\��P��j�.RwM\�@-���\�L\�\�4M�\�p4�G\�)�\�t4\'\�4dc�l�YBOg�N�t4�,f�\�?\Z@\�\�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_37dc913efb26fa82','pages_1'),
(2,'1_37dc913efb26fa82','pages_2'),
(3,'1_37dc913efb26fa82','pages_3'),
(4,'1_37dc913efb26fa82','pages_4'),
(5,'1_37dc913efb26fa82','pages_5'),
(6,'1_37dc913efb26fa82','pages_6'),
(7,'1_37dc913efb26fa82','sys_file_1'),
(8,'1_37dc913efb26fa82','sys_file_metadata_1'),
(9,'1_37dc913efb26fa82','tt_content_1'),
(10,'1_37dc913efb26fa82','tt_content_2'),
(11,'1_37dc913efb26fa82','tt_content_7'),
(12,'1_37dc913efb26fa82','tt_content_3'),
(13,'1_37dc913efb26fa82','tt_content_4'),
(14,'1_37dc913efb26fa82','tt_content_11'),
(15,'1_37dc913efb26fa82','tt_content_5'),
(16,'1_37dc913efb26fa82','sys_file_6'),
(17,'1_37dc913efb26fa82','sys_file_metadata_6'),
(18,'1_37dc913efb26fa82','sys_file_3'),
(19,'1_37dc913efb26fa82','sys_file_metadata_3'),
(20,'1_37dc913efb26fa82','sys_file_7'),
(21,'1_37dc913efb26fa82','sys_file_metadata_7'),
(22,'1_37dc913efb26fa82','sys_file_4'),
(23,'1_37dc913efb26fa82','sys_file_metadata_4'),
(24,'1_37dc913efb26fa82','tx_news'),
(25,'1_37dc913efb26fa82','tx_news_pid_8'),
(26,'1_37dc913efb26fa82','tx_news_domain_model_news_1'),
(27,'1_37dc913efb26fa82','tx_news_domain_model_news_2'),
(28,'1_37dc913efb26fa82','tx_news_domain_model_news_3'),
(29,'1_37dc913efb26fa82','tx_news_domain_model_news_4'),
(30,'1_37dc913efb26fa82','tx_news_domain_model_news_5'),
(31,'1_37dc913efb26fa82','sys_category_1'),
(32,'1_37dc913efb26fa82','sys_file_32'),
(33,'1_37dc913efb26fa82','sys_file_metadata_32'),
(34,'1_37dc913efb26fa82','sys_file_29'),
(35,'1_37dc913efb26fa82','sys_file_metadata_30'),
(36,'1_37dc913efb26fa82','sys_file_30'),
(37,'1_37dc913efb26fa82','sys_file_metadata_29'),
(38,'1_37dc913efb26fa82','sys_file_23'),
(39,'1_37dc913efb26fa82','sys_file_metadata_23'),
(40,'1_37dc913efb26fa82','sys_file_27'),
(41,'1_37dc913efb26fa82','sys_file_metadata_27'),
(42,'1_37dc913efb26fa82','sys_file_26'),
(43,'1_37dc913efb26fa82','sys_file_metadata_26'),
(44,'1_37dc913efb26fa82','sys_file_25'),
(45,'1_37dc913efb26fa82','sys_file_metadata_25'),
(46,'1_37dc913efb26fa82','sys_file_24'),
(47,'1_37dc913efb26fa82','sys_file_metadata_24'),
(48,'1_37dc913efb26fa82','sys_file_28'),
(49,'1_37dc913efb26fa82','sys_file_metadata_28'),
(50,'1_37dc913efb26fa82','sys_file_31'),
(51,'1_37dc913efb26fa82','sys_file_metadata_31'),
(52,'1_37dc913efb26fa82','tt_content_13'),
(53,'1_37dc913efb26fa82','sys_file_19'),
(54,'1_37dc913efb26fa82','sys_file_metadata_19'),
(55,'1_37dc913efb26fa82','sys_file_21'),
(56,'1_37dc913efb26fa82','sys_file_metadata_21'),
(57,'1_37dc913efb26fa82','sys_file_22'),
(58,'1_37dc913efb26fa82','sys_file_metadata_22'),
(59,'1_37dc913efb26fa82','sys_file_20'),
(60,'1_37dc913efb26fa82','sys_file_metadata_20'),
(61,'1_37dc913efb26fa82','pages_10'),
(62,'1_37dc913efb26fa82','pages_9'),
(63,'1_37dc913efb26fa82','pageId_1'),
(64,'1_37dc913efb26fa82','tx_powermail_domain_model_form_1'),
(65,'1_37dc913efb26fa82','tx_powermail_domain_model_page_1'),
(66,'1_37dc913efb26fa82','tx_powermail_domain_model_field_1'),
(67,'1_37dc913efb26fa82','tx_powermail_domain_model_field_2'),
(68,'1_37dc913efb26fa82','tx_powermail_domain_model_field_3'),
(69,'1_37dc913efb26fa82','tx_powermail_domain_model_field_4'),
(70,'1_37dc913efb26fa82','tx_powermail_domain_model_field_5'),
(71,'1_37dc913efb26fa82','tx_powermail_domain_model_field_6'),
(72,'1_37dc913efb26fa82','tx_powermail_domain_model_field_7'),
(73,'1_328092a9ccd7df3a','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_0_0',1788509441,'x�uVɎ\�6���\�A�\�+{`0$��\\\�sȉ�EJ&,�\n���F�Yn���\�Uv\�zܪ^U�Az\�(&h�Eo\nU(3�f\�ϳ5Z+k�2�4\�\�yy�[\�b��\�J-)\�̯�v�*\��\�e�uL�\����\rأn�Z\�y����\�e\rí�W(GYf\�)!5Z��X�L�\�W�j\�G\��\�ݞg�\�N\�\�\\Q7�;2����kQ��+\��D�A?�JY\�\�\�z&az�X;�\�\�\���^}\�^�\Z\�f\�O9*-I��e\�I\�\���\�\�\"GR��\��&��\��jܱW\�Ԥ>1�I�6�n�\� ^�w|8{L�VH\��11h\�7R\�x���	\�g}�5\�\�r9�\�n�/\�`�#�\�	I�-W)\�7WXqͤ\�\�3�]��\�`W\�\\7�ю(�c�J�z \�ՃW\�}\nj:\�\�@^1<�X\Z�\�&���O\� p#�N\\�\�ʮ�R�\��dM\�\��\0\�=�\�\�4b-�b�����1\�Dzj��\'#�OPͬ�\�%>J�\�7�v\�[Ϛ\�\\\nk-s����\�Aם�>u�\�5\�\�D\�%\��_HH\�Px\�=�⠫W�Eқ�/jٱuM�\�F�ic�W\�(&�\��\�\�*\\>\ZLhU�\��^n]\�[\�Pގ�\�\�M�t�\�}>�|�\�\�\�\��\Zu[�{�V\n�^\�F�j\�ЁQB{a`!u�Q_�\�]G�oSy��\�2�\�\�?����FvԀ\�67\�\r\"�Ͱ\�}\�\�4݊�_2\�}\�7�����NXMd&\n;�\�:6\��A1b��[\�;[:N�P\�`�\�ח�\��6O���>寜��Fz\�\�x)�;+dD晐\�M|*h���Bwڻ�!�t�{�,�Ir�/��$\�\�^��<�A\�\�@�n\�$1�h9z\���\�O�\�\�S�ʳo�2�K,\�uw���\�\�(��v�� �ZaЕ��n�\�\��\�t����M\�l����\�\�\�Ta>��H��W\�~\�.	�ay\�n��Ć��\�jYJk��GJt\�٥L/\�c�\�qi����^\�\�WkR\�%\�\������\�zs\\5UC\�4�6%\�\�\�m��TV'),
(2,'2__0_0_0_0',1788509441,'x�\�VM�\�6�+\�Z4��![[��=A�\�z\"h��	K�JRk���g�\��u$�\"e9��\�nR�7\��\�<?�%\�#\�\�-\�\�4{T\�\"�:N�[�%�CԚA�\�\"�4�\�H7�-Z$\�\�drI�f.�ܢ\�*�L�E�UL�a�ج\�sJY\�m��Rk^3��g��!�ɢ�\�R��WY�E�Y��Լ)��Wk�\�2��8�g*��\�\\�I\��r]��\�6EP�:+\\��\�Hɰ���CYT���-��\�3X�N\�cy(v�\�\��V��(\�r�-S8\�1��\�ES\�2��|��Ғ\�\�F�\��Ƭ&�2Ȏ\�\�T}���ᆝ4�\���\�PT)$g\�\�T\��e&�b\"\�w�4\�\�\�۵\��\��Cd_s�\�V\\3)���B�煽eE��\�\�D�\�W��b~6\�ö\�G\ZJt!;~j�kF#�bD\�{��k\����\�]pa�T\�ْ<\�L\�킣 W2[^+\�t�7y\�QזN5=E�\�z\��$�bՔg�Թ�N`$��\��~R\�\�\�\�\�L\�\�\�\�\�\�\�6�\���<\�\�<\���_\�\���w\�\�~~�\�\�é��:\�t8Z\�%��ƅ5j�\�Ԣ�DX\'��>a^�\�\�b�j\�b?���������}��[Y!p�\�Tk�\�\�\���9�O\r��R޴A\nV��i��o\�TAc��\��ZZ\�\�ɷ\�\�\�\�\��=v\�fI\�1�^śÕ�\�̠\�z*W\�]�g���\�2\� ex\��&\�,�8b\�ZL.s`磐T\�6���b�أ.\0\�\�J�?����F�P��J�\Z\�	E*���X�mX\�0\�.\�fT5\�9��B���du�\�9(�����L\Z���J\�);���U%�c�?B��\�X!\�o\�\�\��a\�\�T\�\�\"\�\�\��\'\0_{7�y=\�_\rd\�G��\�\�>7\�.�p�i\�s9�4H\�VFV�s\��!\�2\�;h\�w\�\�~�7��~g�^ě\�\�;�z_�\�\�\�_\�\��\�V\�,4a�U�4��2\�\�\�K���\Z\�8+�f\�eY9q��k\�Bf&\�E�Iϵl�\��p�e|�	/\�\�&�3Af\��\�\�\Z\�yu߈��o4��&\�\�+4�\�\�@�\�~\�Xya�o�U�1��\�\���\�\�\�\�\�?\�\�;��\�枑�f2�P�Q	�/>\�\"\�K�\�a�\�\�� +\�*�,W��\��w�/\�2\�\�)IV\�\�\"-\�n)���%q���,٤\�6]&���%�'),
(3,'3__0_0_0_0',1788509441,'x�\�VK�\�6�+���\�\�\����C�\�l=	�%{��-W�wv�\�\�[�Xh\�ayfR\�m�\�\��(�E~$\��$0��x��O\Zg8\�Kn\�nG��i��\rm�\�lW�U��+�)��{\�r�ֻ4�0^s\�G+�={�\�\�;��Ue�h�\�\�7޲\�\�\�R�\�\Z#���=��2����+�tK�(y|\�u�Dg�W�	΄�eq\�\"�F�4�i[\��\�\�]~ԁ�\Z�-\�⭹��\�U\�C��͘��!Z9���\�\�!\�\�\'O\�ݾ�m)�\'\�7	͵Q�0N\�\�A���\���\�\"9-\�!=\�I\�\�\ZFZ�hH\�����ŁC+=�!��BA[ي�֤\��\���\��&[� ��\rJcDY�i\�{s\�Bέ\�\�\n�`�\�\�}�w�}\�ĕ\��-4\�\�p%��򞟎R1w�Fۖ�\�aM��\�\ru\�<0%��8�����]-} \�0��\�E~�\�\Z�\�V�Rֵ<Q��?Is���eE.��h\��A�<u��\�9��\�,tV\�#����\ZR\�Ў�_^*��\�3\'�ֽK\�\�oV\�\�\�(\�*\�\�ږ+\\��{\�\���\�!Ul�\\\�\�+�$x(�yN,#�\�`uc\����\��E]\�]��	��\�j4\�5W\�\�H�\�G~�;�~Y9\�\��\�\�\�\��š\�\�)�\�,�j�۞���{�\���\�.b\�\�rc�IC���71?]\�\�ě�\�A|h!\�\��}\�@v\�aY>�n\�\�Է�\�|۾�K\�ϊ~�7��\��v�+ǻߗÁo\�t\0n�β\�\�Y�Gَ\0;2\\\'G7�\��)-SO6�xj\�i��ʟ9s0ap��]\�wgBD>��� >\��q\�\�\�\'\�\�}�DV|�`��J� m��ѳ�a܌\0\�\�M�\�\�\�,�\�3��(,�F��O\�\�Qǅ\"%2�a�=	\�^(й�6\�\�չ2�zQhCO\\�\�,��\�\�3|TZa���\Z\rG\��|�Μ�90�\�l��w3$:\r\�0\�\�H�\�W�84✓\�?�\�I5��jJ\�\�\�\�\�\�\�\�\���Ch�ͮ��\�u�n_p}tW�o��\��˻\�6]�\��;�G~\�$_7\�v�D��&�C�\�b\�l�@�\�{^�>~U\�\�z{蛛?����\�?\�\�G�\�\��\�l�\�\�\�?\��~\��\��\�\�8v��\�x��}m�h��\��\�\�\�.�\�%ۦK�#�b\�v�\\\�(\�[/�EJ�f�\"�f9]~\�ʓ�'),
(4,'4__0_0_0_0',1788509441,'x�\�VM��6�+#r�����f�H�\�(9�\�2���,��\Z0�\�twF\�\�r\�K�ml�^i�hf7Jn\�+�\\.�*I�\���薤q�>\�t�=+�[��oG�\�k�J*\�t#\'�ZE\�xrQE�g�Cq�O����c�P�ݳ���vi\0Q�R���m�-|$I��\�J\���i��^\'�P���u\�6�\�@\�\�{*s�:\�8�\�QG�S5\�6(�d\�Y⚴UO*�\�\�GJ�\Z�-�Z��\�\"�\�C��\�X�\�@�1X�\�\�.�\�:�S�����%��ɷɤ$W\�\�՞�ӆ�Z#\�P\��\�{u\r\�-=)\\\�j�\�T\��R\�?�sG�1UE[�\�\�8)�\��]�uP�{z�\�2�9~3�%STpn\�Q\�\�4���T���(�\�\Zȃ\�ϖ<`K�� Ek\�\�V\�b�KJD�\�f�\��\�;p�\�FLֽI\�QO�}\����\�|X\�ì\�뾰e\�Ř\�S�I�VT`\�1*�\�Q\�y�QC�+p\�\�Z��F\�^R��D����2\�C݆]!\�[?��\rg5\�\�\�)�\�~�\�\�\�ݿ�\�\�ǟz\�5����W~kA��>\n��7\�\�	�\�\�~�\�\�\�Y\�\�S����ߋC��\Z\�\�N0\�s�\�S�\�\�\�\�ኀ@��\�t~?Җ�LɱSM\0�ʛ\�s�ʩ1u���\�+�\�Vn&A��\�^\��Fr�p\�v1�\�\��WcK\�\�a���\�լ=\\��8��t����9��\�\�{��\�\�/NR�\�n2\��\�7|v�=�(�)3\Z~ˉ=\�\��ۚ\�\�\�:b6#�(����\Z\�\�\�V%1�ʰࢿ|�i�\�\�P\�\�\�G�K�?��ԆXL�Y�%\�W�\�a}AO>�8.y]\�\�b\�Z(\�\������\���\�-\�I�-�\�!�Z=l�ڻ̚qn�\�@ud\n*���s�E8\�\"h\�|9�\�\Z���M\�qM�4d�w\�L\�\�\�\�&��z\'ٮ\�\�\���\�׬v�\�K��i>��d�1��HZ���t�\����������fCe�qbM=p�I���`1ݹ\�\�Nz�d�f�6��l�O2\�\�\�\�l\�̐\��\�\�kM缺nD_T7\�\ZG\�\�+�\�B@�\�\�\�B<B-\���Dcy�\�\�\�\�\��͟\�\�3\�+\�\�=%\�3Ĥ\'���\"\�>�\"\�K�ȱ�\�\��\�0WJ\�\�\�Y�\�3��W�/�2G\�\�)�\�$�Q�6dM�pWfYNP�	3�\�6\�\�f�W\�/a\'%�'),
(5,'5__0_0_0_0',1788509441,'x�\�V\�n\�6��@\�\�!\�v,+E���h�\�$�芠EJ&,�*I\�v��Yw���I��<@0�d�hw��\�}\�\�\�C�${\��!\�z�=�l�E�\�\r\�V7�\�\Z�u�EZiR��NW�HPjNrI�f\�d�A\�E\�a�E�UL��Kl\�\�8��q�&���Ԛ\�\�a\�kh��YT0\\J\�Ax�\�Y�{JH͛r�\'K\0\�2��8\�2�K\�j. \�{\�Q�+�\�W٨�\�iʎ�\�\�3�E�\�\�\Z=��\�d>\�b\�}@��\�E᮫l����\��].����\�}D�JK�kkuz\'d���\�\� [�\�=�\�It��vԸb\�~�CR���)cS�ק�c슱l\�q\�`ߋ�n\�B\�\�\�K�}\�\�7WXqͤ6�\n�\r\�[eE��\�\��B\�K�!b~6\��[\�-\r):�>4\�5�X1\"\�1\�]��d\�A\��\�fa�T\�ٔ�\��\��\�d6�V\�\�0o򪣮-�rz�\�T\�\��X;\�sfP;:\�\�\�	\�$��b\�xIz|\�\�\�e�A�=�@\�}pp��3kpy\�\nz\Z=�\�\�w�ݛ�����y�ۯ��v*R�w:\\-\���ƅ5r�\�Ԣ��0O\�e}ļnٱ\�0�e����\�\\դŭ\�p�O�!��Ǖe7\�}��@�\�\�l\�\\���ڲ�۞~`336\�Ot�\�Cx*\�,u\�\�ɐ�\�̓x�cT3[,\�\Z?\�\�G���z\�u\��Ǡ̊7�i#&U�\�1.�\�}\�W�\�\�w&,*H�\�W4\�h\�\�\r�Ť�=;��ʶ\�� s&�r\0�jK�>n�)\�\�G\�C6�m��W�n\�b1�ẇiw�F#۹ϡ\�gl\�\�\'�\�Ð��\��͘1Τ����##\�>e\�p�.DU�Øb\�W+\��� +$�3�\��\r\�I�\� � ���\�?�һ\�\�\��m}\�\Z:?\��\�g3w\�3��?ˉ��Q�qde;\��_���!s!�&B(�,�\�u��(�\�\�E���r�\�-��4�\Z*h\�жDf�ɤ_O��5#�\�5ƫi��1�@qY6�\�e\�ę�p.I�3Fp�\�\\g��+\�F\�3\�\�&�(^NNxg�\�\�\�\�\Z㼺�D_UO\ZB]\'\�\��\�LXɾ\�Xy.&AK��\�cy�\�u\�\�_\�\�?���\�N\�\�=#\�3De ���\"�/>�\"\�K�\�a�\�\��\��+\�*�,U��\��W�/�2\�\�)ʓ4GI�o�U�N\�9]n�$)\�2^-\�nQ���\�.O'),
(6,'6__0_0_0_0',1788509441,'x�\�W͎\�6~��z\r\ZQ�lI[��=�xsȉ�%J&,�*I\�\�.\�\�z\�uHJ%9@.i�7\�7\����dQ\�\�2tO��>{�\�&zV\�,\�\���j�J*\�t\�\'q�\�(\�ZN.\n�\�\�٦(�R\�쳠�5U\�H	\�\�+\nڎ@� U(\�\Z:b\�3\�>�dAIq%x\�efA`\�I.k+�9J\�S�\��/o�\�\�\�\�A�j��G���W�k\�V=�(�7<�5\n[\�A[��%\�E\�\�C\�+�\�V���e�S��\Z�ρ\r�\�|�sπp/rn�EM7\�j�AWGE#q/��R\"�oF܄t�t��F7h\�7b\������z\�\�\�I\�\�\��{}xx\��\�\����\�K�<A\�\�^��\�y� Ҹ���M��\��\�\�ԫG̚�>v�V��\�ie�6�Ý`�U\��\�s�s<N�\�\�ڙHm\0kmJ�\"m&\Z\Z\nJ\�}\�y)}&8\�p\0\�KV\riױ=uX	J!�\�c�C\�*0�J���ܚ\\�<\Z\��Q<\�C\� �ҋFK>ag\� #�0\��\�3�?.\�6&��\�\�����\�[��z\'R}\�t��\�^>��\�\�\�v/?Q�\�\�&tR�~kW8����\�K�7|\�͙^/\\r�3\�\�e\�\�\�(� ��\0�Kz=��+,��F��e\��� �k\�\�$\�%8W~k��\�܅a�\�_&�FI�\�r?��I~�\�1�\�}/���z�5t�o�\�i��6���.,)�Y+\�\�ѯ*�K^\��\�LL�6\�O0\"i)\����Nl\�[��\Z�4)\�\�J��	��\�0k\�\�^C1�S���t\�\��?\\	�&^ND\�\��\��\��?y���c�^�h�&\�\�k\�\�\�5�\�6a\�o�\�aG&\�N/I7X��Sc[\�v�\�=4�A�u\�;ʰ�\�\�\�,�Y���\�^n1��j�a�\�\�\�RCN-�\\uI6\�P)\�۟TpC\�PnY\�\�0�\�\�A�i��v[\�Q\�y1\�K��2�v\�\�0�\r�\n#f�w�<M\�\rk�EAl\Z�\\��\��\�o�\\\�Yr\\��\Z֩�\�\�\�`��?zf\�\����A\�\�|D\�\�|�u�\�\��w$\�w=��\'$l�\�p���7��������/�\�Q�b��{�����һ���w$\�\�|\�D_\�4�\�W\�\\)I_�/:,?\��ͯuh\Z\����<�(�\�8\�\�(Mv	I�E�q�St$�$ڧa��]�'),
(7,'10__0_0_0_0',1788509441,'x�\�VɎ\�6���\�A\"Y�v`0$sq\�!\'��\�2aITH�m�\��[~,%qe��	�l�o�G���X\�X�\�\�\'\�##\�%yQ$%Qǋ\���q0[k�� �V�\�\�\0,W\�j�\�\�k��˂iV\�l�+KP���Kl�\�\�\�k�W�5��a�\r�\"DV$\�-�\�0�\"1�\"\�R\�\"ϗ3�9��8~\0�K\�j.0\�\'\�\n�+��\��QgE+֔+�\�\�k	��$nh\�$4�\nV���\�/����If��\�v\�w\�#ƨ/\�\�&͎�嫈m��,\�\�\�\�^\�\�B\�xe�-\�Hf}���\�N�V\�vK\�\�=P\�J5��`\�!g�hx\�*Z\�\�\�0\r��\�6\�h\�i_\ZZL@\��cx΍e�\�\'\�V<�M�m�}\�\�\�`\�b����k�B؜p>\nY؍U�jh���VL\�\�m_��F�j̊\�OQt�M�a\��\�\�	\�ύv�\��U%�\�\�M\'o)`2\�S�\�#\�x��\�V�ݷTK\0,&ai�(\�S \�]=55ki�\�j���_�x+9^�>[�\�,Qc\��\�Nq�KZ+S�x\�\�\nwu�\�5\�͙,�\�\��\�B@��|�\�\�\�N�Ao\�<�i\�\Z\�6\�\r�\��\�Z\�N�4^�H>T\�4踡G\�ĺ�\�,m\�\�P���8{O���yC?�\�<��\�ݧ��0*\�z��Z)\�{�w:T��U�.�	�<\�2\�©�x\�e(o�\�]V�\���\�̊�kd�`\�\�nL��\�V�R]\�\�(�CIY��\�\�\"\�˝�ƞ\�I�$�3J=�k88����l�\�;�X��\�\�z�]�O�\�\�1<\� �#2<�ʌO��\n�kJ.$wr\\�ͣ\��^D/�&(\�V�8z%4\�&d�\�\��\�\�\0\�)\�C�iF�/θ��ods\�@(\�Ak�j�\�Ӱ Nm\'w\�u\�mG�/\�8[\��%kE\�^��G�\�\�\�\���\�\�\�J�&�ċ\�^���\�\�\�\"�\�7�<\'�\�\�$�W�開g\�]�9���2�\���\�M\�}8U\�i)L}\\\�\�D9r�\�\�pc����\�r�$�Uzk���\� ��\�\�\�\�>?\�\�\���x��\����\�\�\�:Y\�f\�����\"���\�rt\�\�\�;0\�\�\�\�z�\�\�_��\�S\�n\�w�PO�\�� ��$�Oߘ$��m�\�\�I��\�*�Es\��ޘ+\���a�|͗�e\�,\�N�Y̶�d��g\�\�\"^\',M�mY�^�\�(��'),
(8,'9__0_0_0_0',1788509441,'x�\�VɎ\�6���\��D\�&�L\�a0�\�9\�D\�\"%�D��\�\�4�\�rˏ�$.�l70A0Y\0\�T�b��X\��Z���{�\��(�DQ\�it\�Q~?Z���6(\�J���4[g�l�L\�J!)\�̭��4]İ�����i6z�Ϳ;N)k���J�y\�\�XKC$CQ\�p%E\�+�(2�)!5o�\�\�U���P$\�ၩB\�NsG}2.\�\�\�yM \ZuR�&mՓ�a{�q-AQ�\�-\�d����\�e\�\�Kb둇\��dm1\�\�\��q\�p\�K\�\�X��\�UW�.\"[�%)��z�2�Ƭ!�6Ȗ{��>�^_\�pˎ\Z\�\�\�-)vkR��\r{iE\�R㚷{�iV	ə\�&Z\r\\\�R��1�4`\�\0b�O3�\�\�X\�Y�qo\�I<\�\�ط��w-�,\�7WXqͤ6\�=;��vc�d-.J\�hM��\�\rYI0\�\�@T\�~\n\�\�6��<c80�4\�Lv�\�j\�����kq\�&o);zK1\"��1E�/8�7pio\'u�k\�$��4�%\�)&\�]5\r\�p��lf�d�\�\�NrxJ}�h\�[��\�3f�\r�\�Z\�,i!�L\�¥���\�\�\�kx\\I\�\�\��\�B@���9��\��|X�;\�\�kP[�W\�j��nL6\n\��I\�e1\�K��Y8?t\�0�\�ĺ�ݤ��\re(O[AO\�,=���?�|�\�\��O?�\�p���V\n\�^�\�\�\'mDa� ��w\�\�ax�*��A�\�3\�h~�nm\�\��\�\0�y{\�`�UŮ\�_tw\�*K\�\�t�7\�g\�q`z�\�Ӂ\�Lz1\�*nq�\"%SO>24���\���\��\�a6�\'�8�ㄌ� ���_y�p�.љ\�ή\�z\�=\��+I\�\�%\�\n;��CCo�f\�욠o5#\0��\�&�\�\�\�δ)`�s\�@�\�A}��\�\�ӰANrgo\�\�\�m�\�\Z�M\�ᑵ\��	^1�GG�\��\�a�j\�B�F&�A\�+\�<_���\�\�\�ś�k\n��B\�=vv�o\�-g�\�=�o�ߐs	\r\�rtU�}\�\�x�\n3U���YQNܾ<\\Α\�l���͑y�l�\�9r�m�\�L\��Α.�nC\�m��\r��!\�/�ɿ>D\�I�X\���!D\�cϪ\�\�f\��\��_��\�îo\�\�w��~\�\�9UwO�4�A\�+I\�|c�L�\�$��&I\�J\�\���\�\�7\��1W�/p.�\�p���eΒ����\�E�\�n\�I�]\�\�\�\�q�\�\�O�\"�\�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_0_0','pageId_1'),
(2,'2__0_0_0_0','pageId_1'),
(3,'2__0_0_0_0','pageId_2'),
(4,'3__0_0_0_0','pageId_1'),
(5,'3__0_0_0_0','pageId_3'),
(6,'4__0_0_0_0','pageId_1'),
(7,'4__0_0_0_0','pageId_4'),
(8,'5__0_0_0_0','pageId_1'),
(9,'5__0_0_0_0','pageId_5'),
(10,'6__0_0_0_0','pageId_1'),
(11,'6__0_0_0_0','pageId_6'),
(12,'10__0_0_0_0','pageId_1'),
(13,'10__0_0_0_0','pageId_10'),
(14,'9__0_0_0_0','pageId_1'),
(15,'9__0_0_0_0','pageId_9');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
INSERT INTO `fe_sessions` VALUES
('4a16dab9919764d3890fd6e772e0880949d5ee76704e23649383c2f191ab311f','[DISABLED]',0,1785919023,'a:2:{s:9:\"powermail\";a:1:{s:19:\"powermail_marketing\";a:7:{s:13:\"refererDomain\";s:14:\"lueg.ddev.site\";s:7:\"referer\";s:23:\"https://lueg.ddev.site/\";s:7:\"country\";s:28:\"Country From Ip is disabled.\";s:12:\"mobileDevice\";b:0;s:16:\"frontendLanguage\";i:0;s:15:\"browserLanguage\";s:62:\"de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7,fr;q=0.6,it;q=0.5,es;q=0.4\";s:10:\"pageFunnel\";a:146:{i:0;i:1;i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:1;i:6;i:1;i:7;i:1;i:8;i:3;i:9;i:1;i:10;i:1;i:11;i:1;i:12;i:1;i:13;i:1;i:14;i:1;i:15;i:3;i:16;i:3;i:17;i:1;i:18;i:1;i:19;i:1;i:20;i:1;i:21;i:1;i:22;i:1;i:23;i:1;i:24;i:1;i:25;i:1;i:26;i:1;i:27;i:1;i:28;i:1;i:29;i:1;i:30;i:1;i:31;i:1;i:32;i:1;i:33;i:1;i:34;i:1;i:35;i:1;i:36;i:1;i:37;i:1;i:38;i:1;i:39;i:1;i:40;i:1;i:41;i:1;i:42;i:1;i:43;i:1;i:44;i:1;i:45;i:1;i:46;i:1;i:47;i:1;i:48;i:1;i:49;i:1;i:50;i:1;i:51;i:1;i:52;i:1;i:53;i:1;i:54;i:1;i:55;i:1;i:56;i:1;i:57;i:1;i:58;i:1;i:59;i:1;i:60;i:1;i:61;i:1;i:62;i:1;i:63;i:1;i:64;i:1;i:65;i:1;i:66;i:1;i:67;i:1;i:68;i:1;i:69;i:1;i:70;i:1;i:71;i:1;i:72;i:1;i:73;i:1;i:74;i:1;i:75;i:1;i:76;i:1;i:77;i:1;i:78;i:1;i:79;i:1;i:80;i:3;i:81;i:1;i:82;i:3;i:83;i:1;i:84;i:1;i:85;i:3;i:86;i:1;i:87;i:3;i:88;i:1;i:89;i:3;i:90;i:1;i:91;i:3;i:92;i:3;i:93;i:3;i:94;i:3;i:95;i:3;i:96;i:3;i:97;i:3;i:98;i:3;i:99;i:3;i:100;i:3;i:101;i:3;i:102;i:3;i:103;i:3;i:104;i:3;i:105;i:3;i:106;i:3;i:107;i:3;i:108;i:3;i:109;i:3;i:110;i:1;i:111;i:1;i:112;i:1;i:113;i:1;i:114;i:1;i:115;i:1;i:116;i:1;i:117;i:1;i:118;i:1;i:119;i:1;i:120;i:1;i:121;i:1;i:122;i:3;i:123;i:1;i:124;i:1;i:125;i:12;i:126;i:12;i:127;i:12;i:128;i:12;i:129;i:12;i:130;i:12;i:131;i:12;i:132;i:12;i:133;i:1;i:134;i:1;i:135;i:1;i:136;i:1;i:137;i:1;i:138;i:1;i:139;i:1;i:140;i:1;i:141;i:12;i:142;i:1;i:143;i:1;i:144;i:1;i:145;i:1;}}}s:20:\"powermail_spamfactor\";s:2:\"0%\";}',0),
('630f082f5b1c81b7dd96ddcec59b482d3be04de973c946978e3a32d811922ea2','[DISABLED]',0,1785913910,'a:1:{s:9:\"powermail\";a:1:{s:19:\"powermail_marketing\";a:7:{s:13:\"refererDomain\";s:0:\"\";s:7:\"referer\";s:0:\"\";s:7:\"country\";s:28:\"Country From Ip is disabled.\";s:12:\"mobileDevice\";b:0;s:16:\"frontendLanguage\";i:0;s:15:\"browserLanguage\";s:2:\"de\";s:10:\"pageFunnel\";a:6:{i:0;i:1;i:1;i:1;i:2;i:1;i:3;i:1;i:4;i:1;i:5;i:1;}}}}',0),
('70706dc0a503172be165d4420ee56f7497cf9ddf68562772db87447b07a16726','[DISABLED]',0,1785911662,'a:1:{s:9:\"powermail\";a:1:{s:19:\"powermail_marketing\";a:7:{s:13:\"refererDomain\";s:0:\"\";s:7:\"referer\";s:0:\"\";s:7:\"country\";s:49:\"Länderermittlung von IP Adresse ist deaktiviert.\";s:12:\"mobileDevice\";b:0;s:16:\"frontendLanguage\";i:0;s:15:\"browserLanguage\";s:35:\"de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7\";s:10:\"pageFunnel\";a:9:{i:0;i:1;i:1;i:1;i:2;i:3;i:3;i:3;i:4;i:3;i:5;i:3;i:6;i:3;i:7;i:3;i:8;i:1;}}}}',0),
('d23ff7fdd52e70b384b6053776c495c8e708509314dbe9b5947f2062565e034d','[DISABLED]',0,1785852568,'a:1:{s:9:\"powermail\";a:1:{s:19:\"powermail_marketing\";a:7:{s:13:\"refererDomain\";s:0:\"\";s:7:\"referer\";s:0:\"\";s:7:\"country\";s:49:\"Länderermittlung von IP Adresse ist deaktiviert.\";s:12:\"mobileDevice\";b:0;s:16:\"frontendLanguage\";i:0;s:15:\"browserLanguage\";s:35:\"de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7\";s:10:\"pageFunnel\";a:1:{i:0;i:1;}}}}',0);
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_ausbildung_items`
--

DROP TABLE IF EXISTS `lueg_ausbildung_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_ausbildung_items` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_ausbildung_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_ausbildung_items` WRITE;
/*!40000 ALTER TABLE `lueg_ausbildung_items` DISABLE KEYS */;
INSERT INTO `lueg_ausbildung_items` VALUES
(1,1,1785911698,1785502894,0,0,0,0,'',1,0,0,0,0,NULL,'{\"content\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,'Voraussetzungen FaGe','<p><strong>Voraussetzungen FaGe Lehre</strong></p>\r\n<ul><li data-list-item-id=\"e378522b5fd3817e204d231e18a896c08\">Abgeschlossene obligatorische Schulzeit</li><li data-list-item-id=\"eb0b4d375d6b9a81b8bf691a5727dcfe2\">Einfühlungsvermögen, wertschätzende Grundhaltung und Freude an der Kommunikation</li><li data-list-item-id=\"ee1e438cf4c182c8d422e28bf908b4bb6\">Aufmerksamkeit und Sorgfalt</li><li data-list-item-id=\"ecf3c6621fdedca1f89d0bd88736e1d1c\">Flexibilität und Organisationstalent</li><li data-list-item-id=\"e1675db02db4bce2d285e2771b5b77466\">Verantwortungsbewusstsein</li><li data-list-item-id=\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\">Freude mit hoher Selbständigkeit und im Team zu arbeiten</li><li data-list-item-id=\"e0d402a34bd785928815742fcbda596bc\">Belastbarkeit</li><li data-list-item-id=\"e7450638fb1d37dc29b77dafc1e364006\">Bereitschaft, sobald als möglich die Autoprüfung zu absolvieren<br>&nbsp;</li></ul>\r\n<p><strong>Voraussetzungen FaGe E (verkürzte Lehre für Erwachsene)</strong></p>\r\n<ul><li data-list-item-id=\"eb44665fe731bbc479123d81973a72d85\">Mindestens 22 Jahre alt</li><li data-list-item-id=\"ef15ab3516e7903e712e85160a0390bcd\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet</li><li data-list-item-id=\"e60d3dd231256f50255d39c90ecc5e9d6\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung</li><li data-list-item-id=\"ebfe6f1c01f9bfd60f4522f2a105e5498\">Gute Deutschkenntnisse</li><li data-list-item-id=\"e3c82f6f7ba46d58eaacee47b9b7795b6\">Gute mündliche und schriftliche Ausdrucksfähigkeit</li><li data-list-item-id=\"ea9a85af9bf1394a4101b4721b42c598e\">Abschluss Allgemeinbildung (ABU)</li></ul>\r\n\r\n<p class=\"text-small\">Weitere Informationen zur Ausbildung findest du auf der Plattform <a href=\"https://gesundheitsberufe-bern.ch/\" target=\"_blank\">Gesundheitsberufe Kanton</a> Bern und unter <a href=\"https://www.spitexbe.ch/de/ausbildung/fachfrau-fachmann-gesundheit-efz-fage\" target=\"_blank\">FaGe-Ausbildung</a> bei der Spitex</p>',3),
(2,1,1785911698,1785502894,0,0,0,0,'',2,0,0,0,0,NULL,'{\"content\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,'Berufswahlpraktikum','<p><strong>Pflege – mein Beruf?</strong></p>\r\n<p>Wenn du gerne mit und für Menschen arbeitest, könnte ein Pflegeberuf genau das Richtige für dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah. So findest du rasch heraus, ob ein Pflegeberuf der richtige Weg für dich ist.</p>\r\n<p><strong>Anmeldung</strong></p>\r\n<p>Die Anmeldung für ein Berufswahlpraktikum läuft über das Internetportal Gesundheitsberufe Kanton Bern. Nach der Anmeldung nimmt die Spitex Region Lueg mit dir Kontakt auf und organisiert gemeinsam mit dir das Berufswahlpraktikum.</p>\r\n<p><br />Link zu <a href=\"https://myoda.gesundheitsberufe-bern.ch/de/\" target=\"_blank\">myoda</a><br /><a href=\"https://gesundheitsberufe-bern.ch/schnuppern-praktika/myoda-erklaert\" target=\"_blank\">Anleitung zu myoda</a></p>',3),
(3,1,1785911698,1785502894,0,0,0,0,'',3,0,0,0,0,NULL,'{\"content\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,'Weiterbildung','<p>Bei uns wirst du gezielt gefördert: Wir unterstützen dich in deiner persönlichen Entwicklung und planen deinen Weg gemeinsam mit dir. Zudem bieten wir jedes Jahr Ausbildungsplätze auf HF Stufe – zusmmen mit dem Berner Bildungszentrum Pflege und XUND. Ausgebildete Berufsbildner:innen und Bildungsverantwortliche begleiten dich eng, damit du die Spitex Arbeit wirklich kennenlernst und deine Praktikumsziele erreichst.</p>',3);
/*!40000 ALTER TABLE `lueg_ausbildung_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_benefits_tiles`
--

DROP TABLE IF EXISTS `lueg_benefits_tiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_benefits_tiles` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `color` varchar(255) NOT NULL DEFAULT '',
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_benefits_tiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_benefits_tiles` WRITE;
/*!40000 ALTER TABLE `lueg_benefits_tiles` DISABLE KEYS */;
INSERT INTO `lueg_benefits_tiles` VALUES
(1,1,1785746902,1785503461,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'sky',1,'Weiterbildungen','<p>Dein Wissen, unsere Unterstützung – profitiere von internen Weiterbildungen und Entwicklungschancen.</p>',4),
(2,1,1785746902,1785503461,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'purple',1,'Kinderzulage plus / familienfreundlich','<p>Wir unterstützen dich mit einer zusätzlichen Betreuungszulage und 16 Wochen Mutterschaftsurlaub bei 100 % Lohn.</p>',4),
(3,1,1785746902,1785503461,0,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'orange',1,'Win a colleague','<p>Wenn deine Empfehlung zu einer Anstellung führt, bekommst du eine Prämie von 1000 Franken.</p>',4),
(4,1,1785746902,1785503461,0,0,0,0,'0',4,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'pink',1,'Fitnessabo / Sportverein','<p>Wir unterstützen deine Gesundheit mit einem Beitrag an ein Fitnessabo oder einen Sportverein.</p>',4),
(5,1,1785746902,1785503461,0,0,0,0,'0',5,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'orange',1,'Kostenlose Parkmöglichkeiten','<p>Stressfrei ankommen – wir stellen dir kostenfreie Parkplätze zur Verfügung.</p>',4),
(6,1,1785746902,1785503461,0,0,0,0,'0',6,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'pink',1,'Mitgestaltung','<p>Wirke aktiv mit – setz deine Fähigkeiten bei uns gezielt ein.</p>',4),
(7,1,1785746902,1785503461,0,0,0,0,'0',7,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'sky',1,'Coaching Angebot','<p>Bei uns kannst du von bis zu 3 Coaching-Gesprächen profitieren – wir übernehmen die Kosten.</p>',4),
(8,1,1785746902,1785503461,0,0,0,0,'0',8,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'teal',1,'Team-Events','<p>An unser Sommerfest und die Team-Events bist du herzlich eingeladen.</p>',4),
(9,1,1785746902,1785503461,0,0,0,0,'0',9,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'purple',1,'Beitrag zur Mobilität','<p>Unseren Lernenden bezahlen wir das Halbtax-Abo.</p>',4),
(10,1,1785746902,1785503461,0,0,0,0,'0',10,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'teal',1,'Grippe-Prophylaxe','<p>Wir sorgen dafür, dass du gesund durch die Erkältungssaison kommst.</p>',4);
/*!40000 ALTER TABLE `lueg_benefits_tiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_bewerben_steps`
--

DROP TABLE IF EXISTS `lueg_bewerben_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_bewerben_steps` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_bewerben_steps`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_bewerben_steps` WRITE;
/*!40000 ALTER TABLE `lueg_bewerben_steps` DISABLE KEYS */;
INSERT INTO `lueg_bewerben_steps` VALUES
(1,1,1785847146,1785769756,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"hidden\":\"\"}',11,'Deine Anmeldung','<p>Du meldest dich einfach per Formular, Mail oder Telefon. Wir rufen dich spätestens am nächsten Arbeitstag an, lernen uns kurz kennen und vereinbaren einen Schnuppermorgen.</p>'),
(2,1,1785847146,1785769756,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',11,'Schnuppermorgen','<p>Du erlebst unseren Alltag live vor Ort. Beim anschliessenden Gespräch klären wir offene Fragen und tauschen uns aus.</p>'),
(3,1,1785847146,1785769756,0,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',11,'Vertrag','<p>Wenn es für beide Seiten passt, reichst du deine Diplome/Zeugnisse ein. Wir erstellen dein Angebot und besprechen gemeinsam die Details.</p>'),
(4,1,1785847146,1785769756,0,0,0,0,'0',4,0,0,0,0,NULL,'{\"hidden\":\"\"}',11,'Dein Start bei der Spitex Region Lueg','<p>Herzlich willkommen! Ein persönlicher Mentor begleitet dich beim Einstieg, damit du dich schnell eingewöhnst und im Team entfalten kannst.</p>');
/*!40000 ALTER TABLE `lueg_bewerben_steps` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_podcasts_episodes`
--

DROP TABLE IF EXISTS `lueg_podcasts_episodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_podcasts_episodes` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `claim` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `mediafile` int(10) unsigned NOT NULL DEFAULT 0,
  `poster` int(10) unsigned NOT NULL DEFAULT 0,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_podcasts_episodes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_podcasts_episodes` WRITE;
/*!40000 ALTER TABLE `lueg_podcasts_episodes` DISABLE KEYS */;
INSERT INTO `lueg_podcasts_episodes` VALUES
(1,1,1785498866,1785497882,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"claim\":\"\",\"description\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"mediafile\":\"\",\"poster\":\"\",\"starttime\":\"\"}',0,0,0,0,'Starte dort, wo du wirklich gebraucht wirst','Lernende bei der Spitex Region Lueg',1,1,2),
(2,1,1785498866,1785497882,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"claim\":\"\",\"description\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"mediafile\":\"\",\"poster\":\"\",\"starttime\":\"\"}',0,0,0,0,'Jeder Tag bringt eine neue Geschichte','Pflegefachfrau bei der Spitex Region Lueg',1,1,2);
/*!40000 ALTER TABLE `lueg_podcasts_episodes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_stellen_stellen`
--

DROP TABLE IF EXISTS `lueg_stellen_stellen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_stellen_stellen` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `intro` longtext DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_stellen_stellen`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_stellen_stellen` WRITE;
/*!40000 ALTER TABLE `lueg_stellen_stellen` DISABLE KEYS */;
INSERT INTO `lueg_stellen_stellen` VALUES
(1,1,1785746473,1785745312,1,0,0,0,'0',1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Zur Erweiterung unseres Fachteams Psychiatrie in Hasle-Rüegsau b. Burgdorf suchen wir','Pflegefachperson FH, Bachelor of Science in Pflege, Schwerpunkt Psychiatrie 40 – 60%','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/pflegefachperson-fh-bachelor-of-science-in-pflege-schwerpunkt-psychiatrie-40-60.php',6),
(2,1,1785746473,1785745312,1,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Für unseren Standort Weier i. E. suchen wir\nnach Vereinbarung','Pflegeassistent/in oder Pflegehelfende SRK 40-50%','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/pflegeasisstent-in-oder-pflegehelfer-in-srk-40-60.php',6),
(3,1,1785746473,1785745312,1,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Für unsere Standorte suchen wir ab sofort oder\nnach Vereinbarung','Fachfrau / Fachmann Gesundheit EFZ, mit / ohne Berufsbildner 50-80 %','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/fachfrau-fachmann-gesundheit-efz.php',6),
(4,1,1785746473,1785745312,1,0,0,0,'0',4,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Für unsere Standorte Hasle-Rüegsau, Sumiswald und Weier\nsuchen wir ab sofort oder nach Vereinbarung','Dipl. Pflegefachperson HF 40-80%','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/dipl-pflegefachperson-hf-dn-ii-akp-40-60.php',6),
(5,1,1785746473,1785745312,1,0,0,0,'0',5,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'Lehrstelle','Per 1. August 2027 bieten wir an unseren vier\nStandorten je eine','Lehrstelle als Fachfrau/Fachmann Gesundheit EFZ oder als FaGe E (verkürzte Ausbildung für Erwachsene)','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/lehrstelle-als-fachfrau-fachmann-gesundheit-efz-oder-als-fage-e-verkuerzte-ausbildung-fuer-erwachsene.php',6);
/*!40000 ALTER TABLE `lueg_stellen_stellen` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1785911683,1785486308,0,0,0,0,'',0,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1785917229,0,0,0,0,0.5,1,'Lueg','/',NULL,0,0,0,0,'',0,'Chum zu üs<br>ids Team','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',1,1,0,'',0,'pagets__default','pagets__default','','',0,0,'','','',NULL,0,'',NULL,0,'',''),
(2,1,1785913205,1785491657,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"categories\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"url\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Podcasts','/podcasts',NULL,0,0,0,0,'',0,'','','Podcasts',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'','#podcasts'),
(3,1,1785750305,1785491690,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1785750947,0,0,0,0,0.5,1,'Freie Stellen','/freie-stellen',NULL,0,0,0,0,'',0,'','','freie-stellen',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',''),
(4,1,1785913211,1785491709,0,0,0,0,'',768,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"categories\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"url\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Benefits','/benefits',NULL,0,0,0,0,'',0,'','','Benefits',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'','#benefits'),
(5,1,1785913218,1785491735,0,0,0,0,'',1024,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"categories\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"url\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Direkt bewerben','/direkt-bewerben',NULL,0,0,0,0,'',0,'','','Direkt-bewerben',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'','#bewerben'),
(6,1,1785915294,1785491929,0,0,0,0,'',1280,NULL,0,0,0,0,NULL,'{\"title\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Standorte','/standorte',NULL,0,0,0,0,'',0,'','','Standorte',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'','/#standorte'),
(7,1,1785491945,1785491942,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Storage','/storage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',''),
(8,1,1785745614,1785745609,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Jobs','/jobs',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',''),
(9,1,1785848537,1785747720,0,0,0,0,'',1408,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1785848537,0,0,0,0,0.5,1,'Datenschutz','/datenschutz',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Textseite','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',''),
(10,1,1785848549,1785848054,0,0,0,0,'',1472,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1785849408,0,0,0,0,0.5,1,'Impressum','/impressum',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__Textseite','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',''),
(11,1,1785916334,1785916332,0,0,0,0,'0',1664,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Kontaktformular','/kontaktformular',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'',''),
(12,1,1785916632,1785916473,0,0,0,0,'',1504,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,2,0,31,27,0,1785916848,0,0,0,0,0.5,1,'Danke für Deine Bewerbung','/danke-fuer-deine-bewerbung',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',1,0,0,'',0,'pagets__Textseite','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'','');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,8,1785748739,1785748739,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,0,0,0,'Lehrstelle',0,0,0,0,'','','',NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,5,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1785490037,1785490037,'/user_upload/SPITEX_SCHUH-77_2.jpg','b4cc8c1f1d5021cb2c14d7c3ae3c7ece78f40992','19669f1e02c2f16705ec7587044c66443be70725','jpg','SPITEX_SCHUH-77_2.jpg','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba',1785490037,1785490037,1020742,1,2,'image/jpeg',0,0),
(3,0,1785497882,1785497882,'/user_upload/podcast-demo-1.wav','59783830b95b9a1f74761adb88a21446627000f0','19669f1e02c2f16705ec7587044c66443be70725','wav','podcast-demo-1.wav','21724154088ac378f569066f57f4d8bd0c148fba',1785497849,1785497849,24044,1,3,'audio/x-wav',0,0),
(4,0,1785497882,1785497882,'/user_upload/podcast-demo-2.wav','7d8695ea9705d31aede3c5812b9ceca1986d40f3','19669f1e02c2f16705ec7587044c66443be70725','wav','podcast-demo-2.wav','4e121e877971d9cd60c98587b23c07b761025e50',1785497849,1785497849,24044,1,3,'audio/x-wav',0,0),
(5,0,1785498501,1785498501,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1785485715,1785485715,0,1,5,'application/x-empty',0,0),
(6,0,1785498521,1785498521,'/user_upload/podcasts/test.jpg','fced536a20ee4b1227b4c33bf2dd73958ca52a23','139c5f340a12ff6d76b8a7fb5f8d88f9e172df9d','jpg','test.jpg','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd',1785498521,1785498521,2944890,1,2,'image/jpeg',0,0),
(7,0,1785498691,1785498691,'/user_upload/Bildschirmfoto_2026-07-31_um_13.51.25.png','a0ee235bbe3ae1a02d1ec17bb2678e3f676910a5','19669f1e02c2f16705ec7587044c66443be70725','png','Bildschirmfoto_2026-07-31_um_13.51.25.png','6533ff2478b8f1307b2d80356159ecd843b89473',1785498691,1785498691,11892016,1,2,'image/png',0,0),
(8,0,1785501118,1785501118,'/favicon/spitex-favicon.png','0238aee2076656b4b28a527cbc1d5363c0216236','d250a708fb312b9f6db43a2eadf8a1882a93e725','png','spitex-favicon.png','06ff5592072e31318f265c9d4214b57a6f8ce456',1785501104,1785501013,12948,1,2,'image/png',0,0),
(9,0,1785504207,1785504207,'/user_upload/icons/weiterbildung.svg','93ebf22f8b1552eadbeae5ba39e8c931665d6f3f','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','weiterbildung.svg','7a28e1ed9045367999a439d25167b239cd00ab2c',1785504180,1785504180,308,1,2,'image/svg+xml',0,0),
(10,0,1785504207,1785504207,'/user_upload/icons/familie.svg','e9b3709258564ac1ad111b7b32955e1d514725fe','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','familie.svg','0991f88b7af9bcfb4388cf019221ad06ac289292',1785504180,1785504180,385,1,2,'image/svg+xml',0,0),
(11,0,1785504207,1785504207,'/user_upload/icons/empfehlung.svg','7936f8659e5337add9b2b839da548204ccffc3c6','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','empfehlung.svg','44589e3facf2ccbc74d9b01316e15407ecae4f26',1785504180,1785504180,289,1,2,'image/svg+xml',0,0),
(12,0,1785504207,1785504207,'/user_upload/icons/fitness.svg','826e70d2f51d07839554791f46666146dfe56539','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','fitness.svg','da4787f47f240e24917b311cb1c1498cb6320127',1785504180,1785504180,353,1,2,'image/svg+xml',0,0),
(13,0,1785504207,1785504207,'/user_upload/icons/parkplatz.svg','a3d2d221a192321d9d738206970f768d172d5a1c','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','parkplatz.svg','448587010e8a0b1b95f2b6851b5adf698bd85354',1785504180,1785504180,264,1,2,'image/svg+xml',0,0),
(14,0,1785504207,1785504207,'/user_upload/icons/mitgestaltung.svg','1c425761bb407c195c41c6a49349addcf3f50f3e','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','mitgestaltung.svg','4be54d2dccd5e4d9d01665b9485a481ff5e9503d',1785504180,1785504180,281,1,2,'image/svg+xml',0,0),
(15,0,1785504207,1785504207,'/user_upload/icons/coaching.svg','e5d368012dd9f9d23e7fd5f7e0e2b374c1dd10e6','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','coaching.svg','32ef701922af80da8b5adbe2d08190edd38eac1e',1785504180,1785504180,319,1,2,'image/svg+xml',0,0),
(16,0,1785504207,1785504207,'/user_upload/icons/team.svg','c81ad786e3d01bf9c7bb1a24ff338c6a0a0e1cc8','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','team.svg','a71039589805fbb93729c8bfd6460fea3417b6de',1785504180,1785504180,348,1,2,'image/svg+xml',0,0),
(17,0,1785504207,1785504207,'/user_upload/icons/mobilitaet.svg','ad4648537cebb3f21d9f1a00a83373ea8d4c5b33','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','mobilitaet.svg','5c39a033c64954eedb882c92a417e8b56fee16e1',1785504180,1785504180,337,1,2,'image/svg+xml',0,0),
(18,0,1785504207,1785504207,'/user_upload/icons/gesundheit.svg','43820fc67a2b21f7ba91c1871765d31e89ec2119','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','gesundheit.svg','05fa4f036d55081fb5c94fd157514a90482f5e34',1785504180,1785504180,243,1,2,'image/svg+xml',0,0),
(19,0,1785509214,1785509214,'/user_upload/Homepage/standort-weier.jpg','2c2bae590285de1ca51e5a93126a27fbe1ee8eb3','c3bc98602796440503b991e8b2595fcaa67ff01c','jpg','standort-weier.jpg','e50628414c2574017711e28be06fe7fb7a2cbc9d',1785509214,1785509214,467637,1,2,'image/jpeg',0,0),
(20,0,1785509265,1785509265,'/user_upload/spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp','0c542d7bb9972623ea5f3f90a426136c5e8c0b35','19669f1e02c2f16705ec7587044c66443be70725','webp','spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp','a3c86044ef4a40ce9fccc13fd56b6323544a1eca',1785509265,1785509265,118238,1,2,'image/webp',0,0),
(21,0,1785509423,1785509423,'/user_upload/Homepage/Frontbild_SR_2.webp','c2157ed9b6bf4fa50f5f1a969d7ae1be031b2ebc','c3bc98602796440503b991e8b2595fcaa67ff01c','webp','Frontbild_SR_2.webp','9c563176a47dedebeec108e29fc9b8ae8127403b',1785509423,1785509423,557084,1,2,'image/webp',0,0),
(22,0,1785509465,1785509465,'/user_upload/Homepage/spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp','1e66f18230dda608781cc6a6a270d2ac42006b0e','c3bc98602796440503b991e8b2595fcaa67ff01c','webp','spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp','dfe424e51de593e0765291a0266432375413a938',1785509465,1785509465,269444,1,2,'image/webp',0,0),
(23,0,1785743003,1785743003,'/user_upload/icons_OK/Fitness.svg','4b9739b096335f086eccca1628deeb2f49314b28','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Fitness.svg','a890703c476a701fff4d7b48ff3d2b397c6cdc15',1785743003,1785743003,1628,1,2,'image/svg+xml',0,0),
(24,0,1785743003,1785743003,'/user_upload/icons_OK/TEAM-EVENTS.svg','0720c26162024dd03a6404c3f06eb1c529d27bab','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','TEAM-EVENTS.svg','357ebef8c4299621cebf7641d896da5bd2395ac0',1785743003,1785743003,2806,1,2,'image/svg+xml',0,0),
(25,0,1785743003,1785743003,'/user_upload/icons_OK/Chat.svg','f8e7ff15f86c385bf2ba4f57d183919dd7cd6cac','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Chat.svg','80dde84560c5c02140efddf0abfb7997a7720971',1785743003,1785743003,1798,1,2,'image/svg+xml',0,0),
(26,0,1785743003,1785743003,'/user_upload/icons_OK/MITGESTALTUNG.svg','0e53449a25e48174ca4af7fc842860aa5cb7c715','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','MITGESTALTUNG.svg','5073125ea2c6d56310b8f42d45cc177c30c8f02e',1785743003,1785743003,3756,1,2,'image/svg+xml',0,0),
(27,0,1785743003,1785743003,'/user_upload/icons_OK/Pin.svg','33b2ee482ae3b875fb7a9e408c7e36955d60aeb7','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Pin.svg','61068b3dc040ebe8d99ef09780cb7ce33ab249fb',1785743003,1785743003,986,1,2,'image/svg+xml',0,0),
(28,0,1785743003,1785743003,'/user_upload/icons_OK/Mobilitaet.svg','69e5f81261c49cbf03d08a86fceda29cb37643c6','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Mobilitaet.svg','18ac53db50b479c2a2e6717a025fd32cb7fda582',1785743003,1785743003,2439,1,2,'image/svg+xml',0,0),
(29,0,1785743003,1785743003,'/user_upload/icons_OK/Familie.svg','3a7aa207b1a5c8fcd0fbfe8e34aa3ddd56715cd5','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Familie.svg','5abe3d909da1cf0e493adbdde448a9364b24fb90',1785743003,1785743003,2645,1,2,'image/svg+xml',0,0),
(30,0,1785743003,1785743003,'/user_upload/icons_OK/win_a_collegue.svg','eae321849390a960c086ce3b66e62034b2612e56','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','win_a_collegue.svg','a883cb4b3fbbba750a6dc51b0be7bc169f8ea92d',1785743003,1785743003,2082,1,2,'image/svg+xml',0,0),
(31,0,1785743003,1785743003,'/user_upload/icons_OK/Grippe.svg','155b23674a0c345478039b4879b7c3064103c7f2','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Grippe.svg','1e34601e49ac1b5717d343b40bbdfae5eb1d5065',1785743003,1785743003,1241,1,2,'image/svg+xml',0,0),
(32,0,1785743003,1785743003,'/user_upload/icons_OK/Ausbildung.svg','fb19deadde7a666231ec64431a3c4a7fb9b4b794','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Ausbildung.svg','406631126905837655d0b70eb484127f009a0bf7',1785743003,1785743003,2939,1,2,'image/svg+xml',0,0),
(33,0,1785746489,1785746489,'/_assets/f6ef6adaf5c92bf687a31a3adbcb0f7b/Images/dummy-preview-image.png','35bdcfc42903a4189e40028928741a79bc48cf24','557d1939219cbaef9f24c50a9ca50baf799cfe0a','png','dummy-preview-image.png','b069aa085f06da6743b904400b0e412c3b0b5b07',1785745927,1779137606,25896,0,2,'image/png',0,0),
(34,0,1785916628,1785916628,'/user_upload/danke.jpg','abe18bd82704a9b13797ca86237f59a5d5af3064','19669f1e02c2f16705ec7587044c66443be70725','jpg','danke.jpg','4b886ab4175d31bff78ed5389aaa796688b3a934',1785916628,1785916628,2462651,1,2,'image/jpeg',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1785490037,1785490037,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,2280,1895),
(2,0,1785490085,1785490085,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1800,1000),
(3,0,1785497882,1785497882,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,0,0),
(4,0,1785497882,1785497882,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,0,0),
(5,0,1785498501,1785498501,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,0,0),
(6,0,1785498521,1785498521,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,3364,2020),
(7,0,1785498691,1785498691,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,3308,2184),
(8,0,1785501117,1785501117,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,439,439),
(9,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,48,48),
(10,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,10,NULL,48,48),
(11,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,48,48),
(12,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,12,NULL,48,48),
(13,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,13,NULL,48,48),
(14,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,14,NULL,48,48),
(15,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,15,NULL,48,48),
(16,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,16,NULL,48,48),
(17,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,17,NULL,48,48),
(18,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,18,NULL,48,48),
(19,0,1785509214,1785509214,0,0,NULL,'',0,0,0,0,NULL,NULL,0,19,NULL,1126,751),
(20,0,1785509265,1785509265,0,0,NULL,'',0,0,0,0,NULL,NULL,0,20,NULL,1126,751),
(21,0,1785509423,1785509423,0,0,NULL,'',0,0,0,0,NULL,NULL,0,21,NULL,2500,1395),
(22,0,1785509465,1785509465,0,0,NULL,'',0,0,0,0,NULL,NULL,0,22,NULL,1126,751),
(23,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,23,NULL,119,119),
(24,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,24,NULL,119,119),
(25,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,25,NULL,119,119),
(26,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,26,NULL,119,119),
(27,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,27,NULL,119,119),
(28,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,28,NULL,119,119),
(29,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,30,NULL,119,119),
(30,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,29,NULL,119,119),
(31,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,31,NULL,119,119),
(32,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,32,NULL,119,119),
(33,0,1785746488,1785746488,0,0,NULL,'',0,0,0,0,NULL,NULL,0,33,NULL,128,128),
(34,0,1785916628,1785916628,0,0,NULL,'',0,0,0,0,NULL,NULL,0,34,NULL,4333,1998);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1785490037,1785490037,1,1,'/_processed_/f/c/preview_SPITEX_SCHUH-77_2_2658161611.jpg','preview_SPITEX_SCHUH-77_2_2658161611.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.Preview','2658161611',64,53),
(2,1785490037,1785490037,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_6788af91eb.jpg','csm_SPITEX_SCHUH-77_2_6788af91eb.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','6788af91eb',180,150),
(3,1785498413,1785490037,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_14e7b14a64.jpg','csm_SPITEX_SCHUH-77_2_14e7b14a64.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','14e7b14a64',54,45),
(4,1785490401,1785490401,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2200;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','037fdf9c54df759f107ca49571c860f676dae8ae','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','7a3f4201ba',0,0),
(5,1785490802,1785490802,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8efa321b15bcada168a023d7550b15722242377b','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','8c66315667',0,0),
(6,1785491944,1785491944,1,2,'/_processed_/e/a/csm_hero-lueg_44575b8025.jpg','csm_hero-lueg_44575b8025.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1125c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d4e0b8fa4fe9062871db4f91cbb6b796b64c82fa','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','44575b8025',2000,1125),
(7,1785492221,1785492221,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_e56555b5fb.jpg','csm_SPITEX_SCHUH-77_2_e56555b5fb.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1125c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d4e0b8fa4fe9062871db4f91cbb6b796b64c82fa','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','e56555b5fb',2000,1125),
(8,1785492402,1785492402,1,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8efa321b15bcada168a023d7550b15722242377b','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','b846968f07',0,0),
(9,1785497884,1785497884,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_aadbe5e607.jpg','csm_SPITEX_SCHUH-77_2_aadbe5e607.jpg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','aadbe5e607',1600,1330),
(10,1785498413,1785498413,1,3,'',NULL,'','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','21724154088ac378f569066f57f4d8bd0c148fba','Image.CropScaleMask','45e5f21ca1',0,0),
(11,1785498501,1785498501,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_51fcfddad2.jpg','csm_SPITEX_SCHUH-77_2_51fcfddad2.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','51fcfddad2',138,115),
(12,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_02943daaa8.jpg','csm_test_02943daaa8.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','02943daaa8',166,100),
(13,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_62f470d34a.jpg','csm_test_62f470d34a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','62f470d34a',250,150),
(14,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_506fc9ef25.jpg','csm_test_506fc9ef25.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','506fc9ef25',60,36),
(15,1785498533,1785498533,1,6,'/_processed_/9/8/csm_test_f8739afa84.jpg','csm_test_f8739afa84.jpg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','f8739afa84',1600,961),
(16,1785498626,1785498626,1,4,'',NULL,'','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','4e121e877971d9cd60c98587b23c07b761025e50','Image.CropScaleMask','f2bac3877a',0,0),
(17,1785498691,1785498691,1,7,'/_processed_/7/8/preview_Bildschirmfoto_2026-07-31_um_13.51.25_caa660e4e3.png','preview_Bildschirmfoto_2026-07-31_um_13.51.25_caa660e4e3.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','6533ff2478b8f1307b2d80356159ecd843b89473','Image.Preview','caa660e4e3',64,42),
(18,1785498691,1785498691,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_22508f7cf5.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_22508f7cf5.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','22508f7cf5',227,150),
(19,1785498691,1785498691,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_353f7372ba.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_353f7372ba.png','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','353f7372ba',60,40),
(20,1785498694,1785498694,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_175e08d87a.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_175e08d87a.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','175e08d87a',1600,1056),
(21,1785499136,1785499136,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_782b863c3f.jpg','csm_SPITEX_SCHUH-77_2_782b863c3f.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','782b863c3f',1920,1280),
(22,1785499136,1785499136,1,6,'/_processed_/9/8/csm_test_3fba11eba7.jpg','csm_test_3fba11eba7.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','3fba11eba7',1920,1280),
(23,1785499136,1785499136,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_9865617d25.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_9865617d25.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','9865617d25',1920,1280),
(24,1785507436,1785507436,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_52a84846be.jpg','csm_SPITEX_SCHUH-77_2_52a84846be.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','52a84846be',640,380),
(25,1785509208,1785509208,1,15,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','32ef701922af80da8b5adbe2d08190edd38eac1e','Image.CropScaleMask','84f58b5353',48,48),
(26,1785509208,1785509208,1,11,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','44589e3facf2ccbc74d9b01316e15407ecae4f26','Image.CropScaleMask','87126e49eb',48,48),
(27,1785509208,1785509208,1,10,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','0991f88b7af9bcfb4388cf019221ad06ac289292','Image.CropScaleMask','90e097e9bc',48,48),
(28,1785509208,1785509208,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','da4787f47f240e24917b311cb1c1498cb6320127','Image.CropScaleMask','16cf7f4ccf',48,48),
(29,1785509208,1785509208,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','05fa4f036d55081fb5c94fd157514a90482f5e34','Image.CropScaleMask','35d2b3ef33',48,48),
(30,1785509208,1785509208,1,14,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4be54d2dccd5e4d9d01665b9485a481ff5e9503d','Image.CropScaleMask','3c34cd0a54',48,48),
(31,1785509208,1785509208,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5c39a033c64954eedb882c92a417e8b56fee16e1','Image.CropScaleMask','9ba76819fd',48,48),
(32,1785509208,1785509208,1,13,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','448587010e8a0b1b95f2b6851b5adf698bd85354','Image.CropScaleMask','54ca5817c6',48,48),
(33,1785509208,1785509208,1,16,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a71039589805fbb93729c8bfd6460fea3417b6de','Image.CropScaleMask','ca7f0f2281',48,48),
(34,1785509208,1785509208,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7a28e1ed9045367999a439d25167b239cd00ab2c','Image.CropScaleMask','789a4cffb9',48,48),
(35,1785509214,1785509214,1,19,'/_processed_/a/9/csm_standort-weier_35870212f5.jpg','csm_standort-weier_35870212f5.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','35870212f5',166,111),
(36,1785509216,1785509216,1,19,'/_processed_/a/9/csm_standort-weier_51ccf8e2c9.jpg','csm_standort-weier_51ccf8e2c9.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','51ccf8e2c9',225,150),
(37,1785509216,1785509216,1,19,'/_processed_/a/9/csm_standort-weier_c7a49ad61a.jpg','csm_standort-weier_c7a49ad61a.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','c7a49ad61a',60,40),
(38,1785509478,1785509265,1,20,'/_processed_/6/2/preview_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_e73e6eef93.webp','preview_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_e73e6eef93.webp','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.Preview','e73e6eef93',64,43),
(39,1785509265,1785509265,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_6b31097e14.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_6b31097e14.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','6b31097e14',225,150),
(40,1785509265,1785509265,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_2e212dd40e.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_2e212dd40e.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','2e212dd40e',60,40),
(41,1785509291,1785509291,1,19,'/_processed_/a/9/csm_standort-weier_96d59c46ba.jpg','csm_standort-weier_96d59c46ba.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','96d59c46ba',640,380),
(42,1785509291,1785509291,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_d12264a512.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_d12264a512.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','d12264a512',640,380),
(43,1785509423,1785509423,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_94c15e59e8.webp','csm_Frontbild_SR_2_94c15e59e8.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','94c15e59e8',166,93),
(44,1785509424,1785509424,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_4249a9aa6e.webp','csm_Frontbild_SR_2_4249a9aa6e.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','4249a9aa6e',269,150),
(45,1785509424,1785509424,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_68c36343a8.webp','csm_Frontbild_SR_2_68c36343a8.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','68c36343a8',60,33),
(46,1785509465,1785509465,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_2bad66f211.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_2bad66f211.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','2bad66f211',166,111),
(47,1785509466,1785509466,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_782cd51ba5.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_782cd51ba5.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','782cd51ba5',225,150),
(48,1785509466,1785509466,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_0eee4dc871.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_0eee4dc871.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','0eee4dc871',60,40),
(49,1785509489,1785509489,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_d1ccf23cb2.webp','csm_Frontbild_SR_2_d1ccf23cb2.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','d1ccf23cb2',640,380),
(50,1785509489,1785509489,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_909a90f91b.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_909a90f91b.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','909a90f91b',640,380),
(51,1785740608,1785740608,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_b50c93929a.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_b50c93929a.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','b50c93929a',166,110),
(52,1785740608,1785740608,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','21724154088ac378f569066f57f4d8bd0c148fba','Image.CropScaleMask','1de74212f5',0,0),
(53,1785740608,1785740608,1,4,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4e121e877971d9cd60c98587b23c07b761025e50','Image.CropScaleMask','8111df323b',0,0),
(54,1785740608,1785740608,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_75bce87f5f.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_75bce87f5f.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','75bce87f5f',166,111),
(55,1785743003,1785743003,1,24,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','357ebef8c4299621cebf7641d896da5bd2395ac0','Image.Preview','9916222a98',64,64),
(56,1785743003,1785743003,1,25,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','80dde84560c5c02140efddf0abfb7997a7720971','Image.Preview','5f29c3c396',64,64),
(57,1785743003,1785743003,1,23,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a890703c476a701fff4d7b48ff3d2b397c6cdc15','Image.Preview','8ca1bcd9f0',64,64),
(58,1785743003,1785743003,1,26,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5073125ea2c6d56310b8f42d45cc177c30c8f02e','Image.Preview','1d680b73f7',64,64),
(59,1785743003,1785743003,1,28,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','18ac53db50b479c2a2e6717a025fd32cb7fda582','Image.Preview','8276a29a69',64,64),
(60,1785743003,1785743003,1,27,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','61068b3dc040ebe8d99ef09780cb7ce33ab249fb','Image.Preview','3f47f81b64',64,64),
(61,1785743003,1785743003,1,31,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','1e34601e49ac1b5717d343b40bbdfae5eb1d5065','Image.Preview','ddbeb36d0b',64,64),
(62,1785743003,1785743003,1,30,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a883cb4b3fbbba750a6dc51b0be7bc169f8ea92d','Image.Preview','59861d824b',64,64),
(63,1785743003,1785743003,1,29,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5abe3d909da1cf0e493adbdde448a9364b24fb90','Image.Preview','8f96ee1675',64,64),
(64,1785743003,1785743003,1,32,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','406631126905837655d0b70eb484127f009a0bf7','Image.Preview','e379131db1',64,64),
(65,1785743005,1785743005,1,32,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','406631126905837655d0b70eb484127f009a0bf7','Image.CropScaleMask','02b9cd7cb0',115,115),
(66,1785743005,1785743005,1,25,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','80dde84560c5c02140efddf0abfb7997a7720971','Image.CropScaleMask','2b0e553126',115,115),
(67,1785743005,1785743005,1,29,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5abe3d909da1cf0e493adbdde448a9364b24fb90','Image.CropScaleMask','557c59f332',115,115),
(68,1785743005,1785743005,1,23,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a890703c476a701fff4d7b48ff3d2b397c6cdc15','Image.CropScaleMask','d50afe0657',115,115),
(69,1785743005,1785743005,1,31,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','1e34601e49ac1b5717d343b40bbdfae5eb1d5065','Image.CropScaleMask','2297efb62f',115,115),
(70,1785743005,1785743005,1,26,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5073125ea2c6d56310b8f42d45cc177c30c8f02e','Image.CropScaleMask','558603351d',115,115),
(71,1785743005,1785743005,1,28,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','18ac53db50b479c2a2e6717a025fd32cb7fda582','Image.CropScaleMask','7fed278db3',115,115),
(72,1785743005,1785743005,1,27,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','61068b3dc040ebe8d99ef09780cb7ce33ab249fb','Image.CropScaleMask','816b9d6465',115,115),
(73,1785743005,1785743005,1,24,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','357ebef8c4299621cebf7641d896da5bd2395ac0','Image.CropScaleMask','2a4258edd3',115,115),
(74,1785743005,1785743005,1,30,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a883cb4b3fbbba750a6dc51b0be7bc169f8ea92d','Image.CropScaleMask','261cea90f9',115,115),
(75,1785743006,1785743006,1,8,'/_processed_/4/f/csm_spitex-favicon_b63c652888.png','csm_spitex-favicon_b63c652888.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','06ff5592072e31318f265c9d4214b57a6f8ce456','Image.CropScaleMask','b63c652888',115,115),
(76,1785746488,1785746488,0,33,'/typo3temp/assets/_processed_/6/6/csm_dummy-preview-image_a1d8a4dff2.png','csm_dummy-preview-image_a1d8a4dff2.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:100;s:9:\"maxHeight\";i:100;s:4:\"crop\";N;}','1de85feb3e25752eaaeafd731583414ea1d5b62a','b069aa085f06da6743b904400b0e412c3b0b5b07','Image.CropScaleMask','a1d8a4dff2',100,100),
(77,1785911683,1785911554,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_b4b75e708a.jpg','csm_SPITEX_SCHUH-77_2_b4b75e708a.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','b4b75e708a',54,45),
(78,1785916514,1785916513,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_38aa13a986.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_38aa13a986.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','38aa13a986',68,45),
(79,1785916628,1785916628,1,34,'/_processed_/3/1/csm_danke_f1949025be.jpg','csm_danke_f1949025be.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4b886ab4175d31bff78ed5389aaa796688b3a934','Image.CropScaleMask','f1949025be',166,77),
(80,1785916629,1785916629,1,34,'/_processed_/3/1/csm_danke_3410d7a245.jpg','csm_danke_3410d7a245.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','4b886ab4175d31bff78ed5389aaa796688b3a934','Image.CropScaleMask','3410d7a245',325,150),
(81,1785916629,1785916629,1,34,'/_processed_/3/1/csm_danke_2bb8397d46.jpg','csm_danke_2bb8397d46.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','4b886ab4175d31bff78ed5389aaa796688b3a934','Image.CropScaleMask','2bb8397d46',98,45),
(82,1785916634,1785916634,1,34,'/_processed_/3/1/csm_danke_6725e49ffc.jpg','csm_danke_6725e49ffc.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','4b886ab4175d31bff78ed5389aaa796688b3a934','Image.CropScaleMask','6725e49ffc',1920,1280);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(3,0,1785911683,1785492219,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,1,'pages','media',1,'',NULL,NULL,0,0),
(4,1,1785498866,1785497882,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,NULL,NULL,1,'lueg_podcasts_episodes','mediafile',1,'',NULL,NULL,0,0),
(5,1,1785498532,1785497882,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,1,'lueg_podcasts_episodes','poster',1,'',NULL,NULL,0,0),
(6,1,1785498866,1785497882,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,4,NULL,NULL,2,'lueg_podcasts_episodes','mediafile',1,'',NULL,NULL,0,0),
(7,1,1785498693,1785497882,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,2,'lueg_podcasts_episodes','poster',1,'',NULL,NULL,0,0),
(8,1,1785498866,1785498532,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,6,NULL,'Podcats Nr 1',1,'lueg_podcasts_episodes','poster',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(9,1,1785498866,1785498693,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,NULL,2,'lueg_podcasts_episodes','poster',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(10,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,32,NULL,NULL,1,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(11,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,29,NULL,NULL,2,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(12,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,30,NULL,NULL,3,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(13,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,23,NULL,NULL,4,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(14,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,27,NULL,NULL,5,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(15,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,26,NULL,NULL,6,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(16,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,25,NULL,NULL,7,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(17,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,24,NULL,NULL,8,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(18,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,28,NULL,NULL,9,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(19,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,31,NULL,NULL,10,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(20,1,1785509276,1785507434,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin1_image',1,'',NULL,NULL,0,0),
(21,1,1785509276,1785507434,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,NULL,0,0),
(22,1,1785509487,1785507434,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin3_image',1,'',NULL,NULL,0,0),
(23,1,1785509487,1785507434,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin4_image',1,'',NULL,NULL,0,0),
(24,1,1785746876,1785509276,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,19,NULL,'standort weier',5,'tt_content','lueg_standorte_pin1_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(25,1,1785509487,1785509276,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,'standort sumiswald',5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(26,1,1785746876,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,21,NULL,'Marktgasse 5 3454 ',5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(27,1,1785746876,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,22,NULL,'Standort Affoltern',5,'tt_content','lueg_standorte_pin3_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(28,1,1785746876,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,'Standort Hasle',5,'tt_content','lueg_standorte_pin4_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(29,12,1785916632,1785916515,1,0,0,0,NULL,'',0,0,0,0,7,NULL,NULL,12,'pages','media',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(30,12,1785916632,1785916632,0,0,0,0,NULL,'',0,0,0,0,34,NULL,'danke',12,'pages','media',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1785490031,1785490031,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1785485818,0,0,0,NULL,'User Upload','1:/user_upload/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1785490041,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1785490041,1,'BE',2,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"spitex lueg\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"1\",\"sys_language_uid\":0,\"crdate\":1785490041,\"t3ver_stage\":0,\"tstamp\":1785490041,\"uid\":1}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:4cf496f597e7b095ce8b755e6cec3c0c'),
(3,1785490041,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1785491657,1,'BE',2,0,2,'pages','{\"doktype\":\"3\",\"slug\":\"\\/podcasts\",\"link\":\"Podcasts\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Podcasts\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491657,\"t3ver_stage\":0,\"tstamp\":1785491657,\"uid\":2}',0,'0400$omWpoRvZkeQ57UXdvAnM8zOxu7lb366N:f11830df10b4b0bca2db34810c2241b3'),
(5,1785491662,2,'BE',2,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4m3XTRyS-hi7BI7OSIyTYJgM_fBar73U:f11830df10b4b0bca2db34810c2241b3'),
(6,1785491690,1,'BE',2,0,3,'pages','{\"doktype\":\"3\",\"slug\":\"\\/freie\",\"link\":\"freie-stellen\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":512,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Freie Stellen\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491690,\"t3ver_stage\":0,\"tstamp\":1785491690,\"uid\":3}',0,'0400$cIHHYZBoo0Sbtg5q5wEYesEP5A4j-rB7:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(7,1785491694,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$u_pRDRoOI5jt0Yz1DNjZKDAwq_XaKgMC:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(8,1785491709,1,'BE',2,0,4,'pages','{\"doktype\":\"3\",\"slug\":\"\\/benefits\",\"link\":\"Benefits\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":768,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Benefits\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491709,\"t3ver_stage\":0,\"tstamp\":1785491709,\"uid\":4}',0,'0400$OUe05A_qUllmq2hYXIbKvGRJ09s-SsxY:412add0b3eb6ec8f1cb6710aea92e21e'),
(9,1785491735,1,'BE',2,0,5,'pages','{\"doktype\":\"3\",\"slug\":\"\\/direkt-bewerben\",\"link\":\"Direkt-bewerben\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1024,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Direkt bewerben\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491735,\"t3ver_stage\":0,\"tstamp\":1785491735,\"uid\":5}',0,'0400$bRDqUABHrCHsPge9R9pOOsd8s2cB6jby:7ef5a4e3e11db8ac3fea4d7a75468161'),
(10,1785491741,2,'BE',2,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$o5n_iRIvF235Nli5Ofw3OxONrqYKAurQ:7ef5a4e3e11db8ac3fea4d7a75468161'),
(11,1785491743,2,'BE',2,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Zabi7RvB3Q7FOOTFB4P5MR3ipON8KjJH:412add0b3eb6ec8f1cb6710aea92e21e'),
(12,1785491929,1,'BE',2,0,6,'pages','{\"doktype\":\"3\",\"slug\":\"\\/standorte-spitex-region-lueg\",\"link\":\"Standorte\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1280,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Standorte Spitex Region Lueg\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491929,\"t3ver_stage\":0,\"tstamp\":1785491929,\"uid\":6}',0,'0400$N85uCLaz2cCqgIbuWwOj6Erylk7QyEIK:c75354c439a48dbde16b03ac553a080d'),
(13,1785491933,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$femDvlEtlqnvAlb7ysZnJ4KkZKxfYs4-:c75354c439a48dbde16b03ac553a080d'),
(14,1785491942,1,'BE',2,0,7,'pages','{\"doktype\":\"254\",\"slug\":\"\\/storage\",\"module\":\"\",\"hidden\":\"1\",\"categories\":\"0\",\"pid\":1,\"sorting\":1536,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Storage\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491942,\"t3ver_stage\":0,\"tstamp\":1785491942,\"uid\":7}',0,'0400$4lgVRcYJkgbeGPL8SHF7kY_GIpDYKO3P:df50bb24cbce671cf0d61f42fbbef601'),
(15,1785491945,2,'BE',2,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$TkZA_AURYEk5YRSVCsZ8sjmHOIsW74Ii:df50bb24cbce671cf0d61f42fbbef601'),
(16,1785498371,2,'BE',2,0,2,'tt_content','{\"oldRecord\":{\"lueg_podcasts_episodes\":0,\"l18n_diffsource\":null},\"newRecord\":{\"lueg_podcasts_episodes\":2,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_podcasts_episodes\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:01dbc21fdb1263685b9147b3b1596ea8'),
(17,1785498371,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:0132d725a3cbba8232db69b70fa8cea4'),
(18,1785498371,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:147949966161cea7a4448f46cffcc51f'),
(19,1785498532,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:0132d725a3cbba8232db69b70fa8cea4'),
(20,1785498532,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autoplay\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:cea5fcd7b97871880cfe3717d6b52ef4'),
(21,1785498532,1,'BE',2,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Podcats Nr 1\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1785498532,\"t3ver_stage\":0,\"tstamp\":1785498532,\"uid\":8}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(22,1785498532,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:0132d725a3cbba8232db69b70fa8cea4'),
(23,1785498532,4,'BE',2,0,5,'sys_file_reference',NULL,0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:5f15a1453f67b933ed3314381f5d67e4'),
(24,1785498693,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:147949966161cea7a4448f46cffcc51f'),
(25,1785498693,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autoplay\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:cea5fcd7b97871880cfe3717d6b52ef4'),
(26,1785498693,2,'BE',2,0,8,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(27,1785498693,2,'BE',2,0,6,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:768f9cd4e98812f969df7ebe17f11b50'),
(28,1785498693,1,'BE',2,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1785498693,\"t3ver_stage\":0,\"tstamp\":1785498693,\"uid\":9}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:729356755eb8ee035abf6b9b02e20c8f'),
(29,1785498693,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:147949966161cea7a4448f46cffcc51f'),
(30,1785498693,4,'BE',2,0,7,'sys_file_reference',NULL,0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:117c97010b9af15cb554d115dba4e316'),
(31,1785498866,2,'BE',2,0,9,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$hNxqfbc6dgh5pKeA-3CvEaFkPC7wQPqp:729356755eb8ee035abf6b9b02e20c8f'),
(32,1785502132,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p><strong>Wir suchen ausgebildete Fachkr\\u00e4fte, Quereinsteiger:innen und Lernende.<\\/strong><\\/p><p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll \\u2013 genau das macht sie so wertvoll.<\\/p><p>Wir unterst\\u00fctzen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und er\\u00f6ffnen ihnen die M\\u00f6glichkeit, Verantwortung zu \\u00fcbernehmen, beispielsweise in Spezialfunktionen.<\\/p>\",\"l18n_diffsource\":null},\"newRecord\":{\"bodytext\":\"<p><strong>Wir suchen ausgebildete Fachkr\\u00e4fte, Quereinsteiger:innen und Lernende.<\\/strong><\\/p>\\r\\n<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll \\u2013 genau das macht sie so wertvoll.<\\/p>\\r\\n<p>Wir unterst\\u00fctzen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und er\\u00f6ffnen ihnen die M\\u00f6glichkeit, Verantwortung zu \\u00fcbernehmen, beispielsweise in Spezialfunktionen.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$DAHkPTojXteTDPDMmAW1XrbMV8z4PGuN:7fa2c035f26826fe83eeecaaeddc4d40'),
(33,1785503682,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"lueg_benefits_tiles\":0,\"l18n_diffsource\":null},\"newRecord\":{\"lueg_benefits_tiles\":10,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_benefits_tiles\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:4d391f5ef79b8d5d10dffa8a07ca167d'),
(34,1785503682,2,'BE',2,0,1,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:1380d93aca08b14d7410b8aac97055d9'),
(35,1785503682,2,'BE',2,0,2,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:f16c1939204e3f8a6b67a49b7521c33f'),
(36,1785503682,2,'BE',2,0,3,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:0c785c1cb42d424e2608d25e0a182d66'),
(37,1785503682,2,'BE',2,0,4,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:22482fded5cb2c1071b802cad4406b07'),
(38,1785503682,2,'BE',2,0,5,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:1f457869a01262deca1e13521dcdaf7c'),
(39,1785503682,2,'BE',2,0,6,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:89a116999daef93a1e986c713f9accde'),
(40,1785503682,2,'BE',2,0,7,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:fe3fe818b96053da0676e791e6593721'),
(41,1785503682,2,'BE',2,0,8,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:ce032405553aefd28279d08ba416ec8a'),
(42,1785503682,2,'BE',2,0,9,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:69eb67fcaa1c5c687d66be5ebf4a03c2'),
(43,1785503682,2,'BE',2,0,10,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:d8122aa04961ffca814bacd78fc21345'),
(44,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(45,1785509276,1,'BE',2,0,24,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"standort weier\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1785509276,\"t3ver_stage\":0,\"tstamp\":1785509276,\"uid\":24}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:ec378d8e96f494986de35c9be84dff5c'),
(46,1785509276,1,'BE',2,0,25,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"standort sumiswald\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1785509276,\"t3ver_stage\":0,\"tstamp\":1785509276,\"uid\":25}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:5ce305fb03b44e2e5ced3360656e263a'),
(47,1785509276,2,'BE',2,0,22,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:d6a5725e5b31cdd97b9c53c992e81850'),
(48,1785509276,2,'BE',2,0,23,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:a4b81cbb471961a3c12b21861b94f4e1'),
(49,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(50,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(51,1785509276,4,'BE',2,0,20,'sys_file_reference',NULL,0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:97d0d1c7a42cd9603b2010379c1e4e4d'),
(52,1785509276,4,'BE',2,0,21,'sys_file_reference',NULL,0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:bd8e6a36b477d61e04d92cfd10d00f96'),
(53,1785509279,2,'BE',2,0,24,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$tf1hLUF1l6g184HEEW-NPOU015vLTpXq:ec378d8e96f494986de35c9be84dff5c'),
(54,1785509279,2,'BE',2,0,25,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$tf1hLUF1l6g184HEEW-NPOU015vLTpXq:5ce305fb03b44e2e5ced3360656e263a'),
(55,1785509487,1,'BE',2,0,26,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Marktgasse 5 3454 \",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":26}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:2190384e72cbe31d01b0259338cca742'),
(56,1785509487,1,'BE',2,0,27,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Standort Affoltern\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":27}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:dd318efa0f8b108e87c8725b284b77c4'),
(57,1785509487,1,'BE',2,0,28,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Standort Hasle\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":28}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(58,1785509487,4,'BE',2,0,25,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:5ce305fb03b44e2e5ced3360656e263a'),
(59,1785509487,4,'BE',2,0,22,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:d6a5725e5b31cdd97b9c53c992e81850'),
(60,1785509487,4,'BE',2,0,23,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:a4b81cbb471961a3c12b21861b94f4e1'),
(61,1785509547,2,'BE',2,0,26,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:2190384e72cbe31d01b0259338cca742'),
(62,1785509547,2,'BE',2,0,27,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:dd318efa0f8b108e87c8725b284b77c4'),
(63,1785509547,2,'BE',2,0,28,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(64,1785745609,1,'BE',2,0,8,'pages','{\"doktype\":\"254\",\"slug\":\"\\/jobs\",\"module\":\"\",\"hidden\":\"1\",\"categories\":\"0\",\"pid\":1,\"sorting\":1792,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Jobs\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785745609,\"t3ver_stage\":0,\"tstamp\":1785745609,\"uid\":8}',0,'0400$VMj9lL-3_N02g0JlyA8fhmEou_f4qHzv:595375f2fb9f014e091eb08fbc51ec88'),
(65,1785745614,2,'BE',2,0,8,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$goyiRAGSdjUFe3kVjcPdE5B5b_on0z4E:595375f2fb9f014e091eb08fbc51ec88'),
(66,1785746374,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Stelle\",\"lueg_stellen_stellen\":0,\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Jobs\",\"lueg_stellen_stellen\":5,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_stellen_stellen\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:c0db6803ab1ec5f70c36e2a72187867b'),
(67,1785746374,2,'BE',2,0,1,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:b330bba1cd3902f0e799c8f23a1700fa'),
(68,1785746374,2,'BE',2,0,2,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:c7846154fda727c6c75c4b7dbafc59ac'),
(69,1785746374,2,'BE',2,0,3,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:66ed292c32bfd38ce1ebd8ee0d9c9984'),
(70,1785746374,2,'BE',2,0,4,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:f7b484da3c22b6a5ed577823c3bc4d1b'),
(71,1785746374,2,'BE',2,0,5,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:6007030b80c45b2c4ddd3d4b63624cfd'),
(72,1785746396,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Jobs\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>\\u00fcsi freie Jobs\"}}',0,'0400$Y7thAEEN4CM7FTqZ1Yxq3GkHT7AOZG0I:c0db6803ab1ec5f70c36e2a72187867b'),
(73,1785746643,2,'BE',2,0,7,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Stelle\",\"pi_flexform\":null,\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>\\u00fcsi freie Stelle\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$i8642ZKN0JbZ_Pz0TAFEFRyaT1kfEjk3:ea41b626baac59a1fe0716bc344af5d9'),
(74,1785746680,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 wo mir si\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>wo mir si\"}}',0,'0400$sn8_vylnc9ZhTV7NZ6NqyD-KdrUa4e98:c7626fc9bcba6f70beb6ebc085a400db'),
(75,1785746902,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 was mir dir biete\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>was mir dir biete\"}}',0,'0400$n8Va8ImOL2DvQBqIjh7Vxx4Of3CBn9YB:4d391f5ef79b8d5d10dffa8a07ca167d'),
(76,1785746910,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 mir bilde lernendi us\",\"lueg_ausbildung_items\":0,\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>mir bilde lernendi us\",\"lueg_ausbildung_items\":3,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_ausbildung_items\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:b92300cfb5d1d3645c9cb212a7f56c1f'),
(77,1785746910,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:686d480187e1617721c3b1bb09978817'),
(78,1785746910,2,'BE',2,0,2,'lueg_ausbildung_items','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:729ffd98535f26f433ff7532650dd9e6'),
(79,1785746910,2,'BE',2,0,3,'lueg_ausbildung_items','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:c24a30159f7e49e143b807c1b78676e8'),
(80,1785747276,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 <br>mir bilde lernendi us\"},\"newRecord\":{\"header\":\"Lueg \\u2013 mir bilde<br> lernendi us\"}}',0,'0400$tZFjQMLVZ0ipkwvely-_niCKo5V7BMaJ:b92300cfb5d1d3645c9cb212a7f56c1f'),
(81,1785747294,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 mir bilde<br> lernendi us\"},\"newRecord\":{\"header\":\"Lueg \\u2013 mir biude <br> Lernendi us\"}}',0,'0400$dCxJm3qolwUWKfjwV-sS01vU9pkGwAfa:b92300cfb5d1d3645c9cb212a7f56c1f'),
(82,1785747720,1,'BE',2,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/datenschutz\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1408,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Datenschutz\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\",\"crdate\":1785747720,\"t3ver_stage\":0,\"tstamp\":1785747720,\"uid\":9}',0,'0400$cAZayLR5Mjfe_OKvEVl94PK7049dOzaF:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(83,1785747723,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$bu5LP0Q5TBDAIgk5ok_gqTHLz_N663q6:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(84,1785747726,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$cbwymNzqMbUl4K7lL3zXlXIsf6hoyHF2:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(85,1785748012,1,'BE',2,0,9,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":9,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<h2>1. Verantwortlicher im Sinne des schweizerischen Bundesgesetzes \\u00fcber den Datenschutz (DSG) f\\u00fcr die hier beschriebenen Datenbearbeitungen ist:<\\/h2>\\r\\n<p>SPITEX Region Lueg AG R\\u00fcegsaustrasse 8 3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p>Unser Datenschutzberater ist: impunix AG \\u2013 Datenschutz Full-Service Lagerhausstrasse 18, CH-8400 Winterthur privacy@impunix.ch www.impunix.ch<\\/p>\\r\\n<p>Bei Fragen oder Anliegen zum Datenschutz und zur Aus\\u00fcbung Ihrer Rechte wenden Sie sich bitte an diese Stelle.<\\/p>\\r\\n<h2>2. Zweck der Bearbeitung im Rahmen unserer Dienstleistungen und Angebote<\\/h2>\\r\\n<p>Wir beschaffen und bearbeiten die Personendaten, die wir im Rahmen unserer Gesch\\u00e4ftst\\u00e4tigkeit insbesondere mit Klienten, Angeh\\u00f6rige, Besuchern, Interessenten, Bewerbern, Gesch\\u00e4fts-partnern sowie weiteren beteiligten Personen erhalten oder die beim Betrieb unserer Website erhoben werden. Im letzten Kapitel ist eine \\u00dcbersicht \\u00fcber die verwendeten Kategorien von Per-sonendaten. Sollten Sie uns Informationen \\u00fcber andere Personen \\u00fcbermitteln, vergewissern Sie sich bitte, dass diese Personen vorher informiert wurden und dass die angegebenen Daten korrekt sind. Die erhobenen Personendaten werden zur Erbringung unserer Dienstleistungen und Angebote verwendet. Dies umfasst insbesondere die Betreuung und Behandlung von Menschen aller Al-tersgruppen (ab 16. Jahren) mit vor\\u00fcbergehend reduzierten physischen und psychischen Kr\\u00e4f-ten, Menschen mit einer chronischen Erkrankung oder Einschr\\u00e4nkung, Betagte und gebrechliche Menschen, zu Hause in der gewohnten Umgebung. Zudem k\\u00f6nnen externe Dienstleister zur Erbringung dieser Leistungen eingesetzt werden. Weitere Informationen zu den Datenbearbei-tungen und deren Zwecken finden Sie in den folgenden Kapiteln.<\\/p>\\r\\n<h3>2.1 Kontaktaufnahme und Kommunikation<\\/h3>\\r\\n<p>Wir bearbeiten Ihre Daten zur Bearbeitung von Anfragen \\u00fcber das Kontaktformular, zur Bereit-stellung von Informationen \\u00fcber unsere Dienstleistungen sowie zur Vereinbarung von Terminen und Beratungen.<\\/p>\\r\\n<h3>2.2 Klientenaufnahme (inkl. Anamnese)<\\/h3>\\r\\n<p>Bei der Klientenaufnahme erheben und speichern wir Ihre Stammdaten sowie Ihre medizinische Vorgeschichte. Dies umfasst Informationen wie Name, Adresse, Geburtsdatum, Kontaktinfor-mationen und relevante Gesundheitsdaten. Diese Daten sind notwendig, um eine individuelle Behandlung planen zu k\\u00f6nnen.<\\/p>\\r\\n<h3>2.3 Klientenversorgung und medizinische Dienstleistungen<\\/h3>\\r\\n<p>Wir bearbeiten Ihre Gesundheitsdaten, um diagnostische Untersuchungen und therapeutische Behandlungen durchzuf\\u00fchren. Dies beinhaltet die Nutzung medizinischer Technologien und Me-thoden. Ihre Daten werden f\\u00fcr folgende Punkte genutzt:<\\/p>\\r\\n<ul><li data-list-item-id=\\\"ec3ce18193255f5fde3ba54460d453b52\\\">Abkl\\u00e4rung des Pflegebedarfs<\\/li><li data-list-item-id=\\\"e0ad57aa9c0e13d9f23246c5e1995cf5c\\\">Beratung zu Angeboten<\\/li><li data-list-item-id=\\\"e4bb93e37680c861b448047346e592126\\\">Hilfe bei der K\\u00f6rperpflege<\\/li><li data-list-item-id=\\\"e12976d41ff5c4a54cfb440edf1045884\\\">Hilfe bei der Mobilisation (Aufstehen und zu Bett gehen)<\\/li><li data-list-item-id=\\\"ef6b9fcaca1b8d5423af23702e1f94266\\\">Vorbereiten und Verabreichen von Medikamenten<\\/li><li data-list-item-id=\\\"ed915f50a459dde5f50980cfa70cefe15\\\">Medizinische Kontrollen wie Blutzucker und Blutdruck messen etc.<\\/li><li data-list-item-id=\\\"ecd19447a354f66f10f59e7371aba99dd\\\">Schmerzbehandlung<\\/li><li data-list-item-id=\\\"ed2cb2f0f3921196d168d2a2162124621\\\">Pflege von Wunden<\\/li><li data-list-item-id=\\\"e4f783386e772e11b268f4e4ab9a115b1\\\">Begleitung von Sterbenden (palliative Care)<\\/li><li data-list-item-id=\\\"e38b4572e7769e9d625e5dfed1d2b314e\\\">Psychiatrische Pflegeleistungen<\\/li><\\/ul>\\r\\n<h3>2.4 Beratungs- und Informationsveranstaltungen<\\/h3>\\r\\n<p>Wir nutzen Ihre Daten, vertraulich und anonym, f\\u00fcr interne Weiterbilungszwecke.2.5 Notfallver-sorgung Ihre Daten werden bearbeitet, um Notf\\u00e4lle w\\u00e4hrend der regul\\u00e4ren \\u00d6ffnungszeiten zu behandeln und um in solchen F\\u00e4llen weitere organisatorische Massnahmen zu treffen.<\\/p>\\r\\n<h3>2.5 F\\u00fchrung und Verwaltung der Klientendossiers<\\/h3>\\r\\n<p>Die Verwaltung Ihrer Klientendossiers umfasst die Erfassung und Speicherung von Anamnese, Diagnose, Befunden sowie der Dokumentation Ihrer Betreuung. Zudem beinhalten die Dossiers Korrespondenzen, Rechnungen, Terminplanungen und relevante Fotos, die zur l\\u00fcckenlosen Dokumentation der medizinischen Geschichte notwendig sind.<\\/p>\\r\\n<h3>2.6 Verwaltung der Daten zur Abrechnung<\\/h3>\\r\\n<p>Zur Abrechnung unserer Leistungen verwalten wir Ihre Stamm- und Betreuungsdaten. Dies um-fasst die Kommunikation mit Sozialversicherungen, Krankenkassen und Unfallversicherungen sowie zur Einholung und Verwaltung der Kostengutsprache, gelegentlich den Austausch mit Beh\\u00f6rden.<\\/p>\\r\\n<h3>2.7 Lieferantenmanagement<\\/h3>\\r\\n<p>Im Rahmen unserer Gesch\\u00e4ftsbeziehung mit unseren Partnern oder Lieferanten erhalten wir ihre beruflichen Kontaktdaten, die wir in unseren Systemen speichern k\\u00f6nnen. Dazu k\\u00f6nnen auch Ihre Interessen oder Pr\\u00e4ferenzen geh\\u00f6ren, um eine pers\\u00f6nliche Gesch\\u00e4ftsbeziehung zu pflegen.<\\/p>\\r\\n<h3>2.8 Websites und Online-Angebote<\\/h3>\\r\\n<p>Zur Erbringung unserer Dienstleistungen und zur Vermarktung unserer Angebote nutzen wir Websites und andere Online-Angebote. Wenn Sie auf unsere Website zugreifen, erheben wir Nutzungsdaten. Weitere Informationen zur Website finden Sie im entsprechenden Kapitel.<\\/p>\\r\\n<h3>2.9 Printmedien<\\/h3>\\r\\n<p>Wir versenden teilweise personalisierte Printmedien, wof\\u00fcr ihre Kontaktdaten oder berufliche Kontaktdaten bearbeitet werden. F\\u00fcr den Versand von Printmedien behalten wir uns vor, mit Dritten zusammenzuarbeiten und Ihre Kontaktdaten zu diesem Zweck weiterzugeben.<\\/p>\\r\\n<h3>2.10 Stellenbewerbung<\\/h3>\\r\\n<p>Um Ihre Eignung f\\u00fcr ein Arbeitsverh\\u00e4ltnis festzustellen, bearbeiten wir die Personendaten, die wir von Ihnen im Rahmen des Bewerbungsverfahrens erhalten haben. Dazu k\\u00f6nnen auch Straf-register- und Betreibungsausz\\u00fcge oder \\u00e4hnliche Dokumente geh\\u00f6ren. Wenn Sie Referenzen angegeben haben, k\\u00f6nnen wir bei diesen Referenzen Ausk\\u00fcnfte \\u00fcber Sie einholen. Sie haben das Recht zu erfahren, was uns mitgeteilt wurde. Tests, die der objektiven Feststellung der Eignung f\\u00fcr die betreffende Stelle dienen, k\\u00f6nnen Teil des Bewerbungsverfah-rens sein. Soweit es um die Feststellung der Eignung als F\\u00fchrungskraft geht, kann sich der Test auch auf Ihre Pers\\u00f6nlichkeit beziehen. Sollte sich aus den eingereichten Unterlagen noch kein vollst\\u00e4ndiges und verl\\u00e4ssliches Bild ergeben, erlauben wir uns, \\u00f6ffentlich zug\\u00e4ngliche Quellen, die zur Kl\\u00e4rung der konkreten berufli-chen Eignung geeignet sind, wie Xing oder LinkedIn, aber auch ganz allgemein Google, f\\u00fcr die Recherche zu nutzen. Die Recherche in privaten Netzwerken wie Facebook oder Instagram ist f\\u00fcr uns nicht relevant. Sofern objektive Gr\\u00fcnde in Ihrer Person vorliegen, die Sie f\\u00fcr das entsprechende Arbeitsver-h\\u00e4ltnis einschr\\u00e4nken oder disqualifizieren, sind Sie verpflichtet, uns diese offen zu legen. Dies kann auch eine Untersuchung Ihres Gesundheitszustandes beinhalten. Die Auskunft an uns er-folgt im gesetzlichen Rahmen<\\/p>\\r\\n<h2>3. Website, Social Media und Cookie-Hinweise<\\/h2>\\r\\n<p>Die Datenschutzerkl\\u00e4rung gilt f\\u00fcr alle betriebenen Websites, inklusive:<\\/p>\\r\\n<p>luegjobs.ch<\\/p>\\r\\n<p>\\u00dcber die Websites werden Nutzungsdaten erfasst und automatisch in sogenannten Server-Log-Dateien gespeichert, die Ihr Browser automatisch an uns \\u00fcbermittelt. Diese Daten k\\u00f6nnen von uns nicht bestimmten Personen zugeordnet werden. Eine Zusammenf\\u00fchrung dieser Daten mit anderen Datenquellen wird nicht vorgenommen. Wir behalten uns jedoch vor, diese Daten nach-tr\\u00e4glich zu pr\\u00fcfen, wenn wir konkrete Anhaltspunkte f\\u00fcr eine rechtswidrige Nutzung der Websites erhalten. Aus Sicherheitsgr\\u00fcnden und zum Schutz der \\u00fcbertragenen vertraulichen Inhalte, wie z.B. Anfra-gen, die Sie an uns als Website-Betreiber senden, wird auf den Websites eine SSL\\/TLS-Verschl\\u00fcsselung eingesetzt. Die Websites k\\u00f6nnen Links zu anderen Websites enthalten, die sich unserer Kontrolle entziehen und daher nicht von dieser Datenschutzerkl\\u00e4rung abgedeckt werden. Wenn Sie diese Links nutzen und auf andere Websites zugreifen, kann es sein, dass die Betreiber dieser Websites Informationen \\u00fcber Sie sammeln.<\\/p>\\r\\n<h3>3.1 Nutzung des Kontaktformulars<\\/h3>\\r\\n<p>Auf unserer Website steht ein Kontaktformular f\\u00fcr Fragen, Anliegen oder Informationen zur Verf\\u00fcgung. Ihre Personendaten werden bearbeitet, um Ihre Anfrage zu bearbeiten und Ihnen eine qualifizierte Antwort bereitzustellen. Dies umfasst die Erfassung und Speicherung Ihrer Kontaktdaten sowie der relevanten medizinischen Informationen, die Sie uns \\u00fcber das Kontaktfor-mular \\u00fcbermitteln.<\\/p>\\r\\n<h3>3.2 Social Media inklusive Plugins und Pixel<\\/h3>\\r\\n<p>Wir betreiben Pr\\u00e4senzen auf sozialen Netzwerken und anderen Plattformen, die von Dritten betrieben werden, und bearbeiten in diesem Zusammenhang Daten \\u00fcber Sie. Sie k\\u00f6nnen uns \\u00fcber diese Plattformen kontaktieren und wir erhalten von diesen Plattformen Daten wie z.B. Statistiken. Die Anbieter der Plattformen k\\u00f6nnen Ihre Nutzung analysieren und die Daten \\u00fcber Sie f\\u00fcr eigene Zwecke wie Marketing und Marktforschung verwenden. Die Anbieter der Plattformen handeln hierbei als eigenst\\u00e4ndige verantwortliche Stelle. Weiter k\\u00f6nnen wir auf unseren Webseiten auch sogenannte Plugins oder Pixel von sozialen Netzwerken wie Facebook, X ehemals Twitter, LinkedIn, Pinterest oder Instagram verwenden. Die Plugins sind f\\u00fcr Sie jeweils erkennbar. Sind sie aktiviert, k\\u00f6nnen die Betreiber der jeweiligen sozialen Netzwerke registrieren, dass Sie unsere Website besuchen. Bei der Verwendung von Pixel-Technologien werden auf unserer Website entsprechende Codes implementiert, die eine \\u00dcbermittlung Ihrer Nutzungsdaten erm\\u00f6glichen. Diese dienen der Reichweitenmessung unserer Social-Media-Kampagnen. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen. Die meisten dieser Anbieter befinden sich ausserhalb der Schweiz. Weitere Informationen zur Daten\\u00fcbermittlung ins Ausland entnehmen Sie dem entsprechenden Kapitel.<\\/p>\\r\\n<h3>3.3 WhatsApp oder andere Messenger-Apps<\\/h3>\\r\\n<p>Wir nutzen WhatsApp aktiv als Kommunikationsmittel und erm\\u00f6glichen Ihnen die Kontaktaufnahme \\u00fcber diesen Dienst. Bitte beachten Sie, dass bei der Nutzung von WhatsApp in der Re-gel das Adressbuch freigegeben wird und damit Personendaten an die WhatsApp Inc.&nbsp;in die USA \\u00fcbermittelt werden. Wir weisen darauf hin, dass die USA vom Bundesrat als Land ohne angemessenen Datenschutz eingestuft wurde. Weitere Informationen dar\\u00fcber, wie und zu wel-chem Zweck WhatsApp Ihre Daten bearbeitet, finden Sie in der Datenschutzerkl\\u00e4rung von WhatsApp.<\\/p>\\r\\n<h3>3.4 Permanente Cookies oder sonstige Tracking-Technologien<\\/h3>\\r\\n<p>Auf unserer Website verwenden wir in der Regel Cookies und \\u00e4hnliche Technologien, um Ihren Browser oder Ihr Ger\\u00e4t zu identifizieren. Ein Cookie ist eine kleine Datei, die beim Besuch unse-rer Website vom verwendeten Webbrowser automatisch an Ihren Computer gesendet oder auf Ihrem Computer oder Mobilger\\u00e4t gespeichert wird. Wenn Sie diese Website erneut besuchen, k\\u00f6nnen wir Sie wiedererkennen, auch wenn wir nicht wissen, wer Sie sind. Neben Cookies, die nur w\\u00e4hrend einer Sitzung verwendet und nach dem Besuch der Website gel\\u00f6scht werden (\\u201cSession Cookies\\u201d), k\\u00f6nnen Cookies auch verwendet werden, um Benutzereinstellungen und andere Informationen f\\u00fcr einen bestimmten Zeitraum zu speichern (\\u201cpermanente Cookies\\u201d). Sie k\\u00f6nnen Ihren Browser jedoch so einstellen, dass er Cookies ablehnt, nur f\\u00fcr eine Sitzung spei-chert oder andernfalls vorzeitig l\\u00f6scht. Die meisten Browser sind so eingestellt, dass sie Coo-kies akzeptieren. Wir verwenden permanente Cookies, um Benutzereinstellungen zu speichern (z.B. Sprache, Auto-Login), um besser zu verstehen, wie Sie unsere Angebote und Inhalte nut-zen, und um Ihnen auf Sie zugeschnittene Angebote und Werbung anzeigen zu k\\u00f6nnen (was auch auf Websites anderer Unternehmen der Fall sein kann). Einige Cookies werden von uns gesetzt, andere von Vertragspartnern, mit denen wir zusammenarbeiten. Wenn Sie Cookies blockieren, kann es sein, dass einige Funktionen (z.B. Sprachauswahl, Warenkorb, Bestellvor-gang) nicht mehr funktionieren. Wenn Sie dies nicht w\\u00fcnschen, m\\u00fcssen Sie Ihren Browser bzw. Ihr E-Mail-Programm entsprechend einstellen<\\/p>\\r\\n<h4>3.4.1 Google Fonts oder andere Web-Fonts<\\/h4>\\r\\n<p>Diese Website verwendet sogenannte Fonts von Google oder anderen Anbietern, um eine ein-heitliche Darstellung von Schriften zu gew\\u00e4hrleisten. Beim Aufruf der Seite l\\u00e4dt Ihr Browser die ben\\u00f6tigten Fonts in den Browser-Cache, um die Texte und Schriften korrekt darzustellen. Um Ihre Privatsph\\u00e4re zu sch\\u00fctzen, haben wir die Fonts soweit m\\u00f6glich auf unserem eigenen Webs-erver installiert, so dass Ihre IP-Adresse beim Laden der Fonts nicht an andere Diensteanbieter weitergegeben wird. Bitte beachten Sie jedoch, dass bei der Nutzung bestimmter Dienste, wie z.B. Maps, Captcha oder Bootstrap, m\\u00f6glicherweise Fonts von diesen Dienstleistern verwendet werden. Falls Ihr Browser keine externen Schriften unterst\\u00fctzt, wird automatisch eine Stan-dardschrift Ihres Computers verwendet. Weitere Informationen zu Google Fonts und deren Da-tenschutzbestimmungen finden Sie auf der Website von Google oder des jeweiligen Anbieters.<\\/p>\\r\\n<h4>3.4.2 Google Photos, Youtube oder andere Bild- und Streamingdienste<\\/h4>\\r\\n<p>Auf dieser Website sind Funktionen des Google-Dienstes Photos und YouTube oder anderer Streaming-Dienste integriert. Diese verwenden wir, um Photos oder Videos auf unserer Website einzubinden. Die Plugins sind f\\u00fcr Sie erkennbar. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen.<\\/p>\\r\\n<h4>3.4.3 Heyflow<\\/h4>\\r\\n<p>F\\u00fcr unsere Bewerbungs Experience setzen wir den Dienst Heyflow der Heyflow GmbH, Deutschland (EU), ein. Dabei werden die von Ihnen eingegebenen Angaben sowie Nutzungs und Ger\\u00e4tedaten (z. B. IP Adresse, Zeitstempel, Interaktionen, Browser\\/OS, Cookies\\/Local Storage) zur Entgegennahme, Pr\\u00fcfung und Abwicklung Ihrer Bewerbung bearbeitet. Heyflow bearbeitet diese Personendaten als unser Auftragsbearbeiter. Weitere Informationen zu Heyflow und deren Datenschutzbestimmungen finden Sie auf der Website von Heyflow.<\\/p>\\r\\n<h2>4. Herkunft von Personendaten<\\/h2>\\r\\n<p>Die Daten, die wir bearbeiten, stammen in den meisten F\\u00e4llen von Ihnen selbst, z.B. im Zusam-menhang mit der Erbringung unserer Dienstleistungen, der Nutzung unserer Website oder der Kommunikation mit uns. Wenn Sie mit uns Vertr\\u00e4ge abschliessen oder unsere Dienstleistungen in Anspruch nehmen wollen, m\\u00fcssen Sie uns bestimmte Daten bekannt geben. Dies gilt auch f\\u00fcr die Nutzung unserer Website. Dar\\u00fcber hinaus sind Sie zur Bekanntgabe von Daten verpflich-tet, um gesetzliche Verpflichtungen zu erf\\u00fcllen. Ansonsten steht es Ihnen frei, ob Sie uns Daten \\u00fcber sich mitteilen. Wir k\\u00f6nnen Daten auch von Dritten erhalten, insbesondere von unseren externen Dienstleistern oder Vertragspartnern, von Finanzdienstleistern und Versicherungen. Dar\\u00fcber hinaus k\\u00f6nnen wir Daten aus \\u00f6ffentlich zug\\u00e4nglichen Quellen wie Internetseiten, Unternehmensregistern, Grundb\\u00fc-chern, Handelsregistern, Auskunfteien, Adressh\\u00e4ndlern, Verb\\u00e4nden, Telefonb\\u00fcchern, Inter-netanalysediensten erhalten.<\\/p>\\r\\n<h2>5. Datenweitergabe und Daten\\u00fcbermittlung ins Ausland<\\/h2>\\r\\n<p>Im Rahmen unserer gesch\\u00e4ftlichen Aktivit\\u00e4ten und gem\\u00e4ss den genannten Zwecken besteht die M\\u00f6glichkeit, dass wir Informationen mit Dritten teilen, insbesondere mit folgenden Kategorien von Empf\\u00e4ngern:<\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb655ceac612723df820daa2c0d7f6f7f\\\">Fachspezialisten: Wir arbeiten mit \\u00c4rztinnen und \\u00c4rzten zusammen, mit denen teilweise auch Daten ausgetauscht werden;<\\/li><li data-list-item-id=\\\"e8335efa95f4c68819e9cd99c861262f9\\\">Dienstleister: Wir arbeiten mit Dienstleistern zusammen, die Daten in unserem Auftrag oder in gemeinsamer Verantwortlichkeit bearbeiten, wie zum Beispiel Hausarztpraxen, Apotheken, Anbieter von Praxissoftware, Marketing-Agenturen oder IT-Dienstleister, sonstige Lieferanten, Gesch\\u00e4ftspartner;<\\/li><li data-list-item-id=\\\"e93cbdcaf077a67fcf0d38211148f2d63\\\">Beh\\u00f6rden: Wir k\\u00f6nnen Daten auch an Beh\\u00f6rden im In- (und Ausland), Amtsstellen oder Gerichte bekanntgeben, wenn wir dazu rechtlich verpflichtet sind;<\\/li><li data-list-item-id=\\\"e3b0f3783dd6cc9a0b387c0ea42cdd65c\\\">Finanzdienstleister und Versicherungen: Im Zusammenhang mit Bonit\\u00e4ts- und Versi-cherungsleistungen arbeiten wir mit Auskunfteien, Banken, Versicherungen zusammen;<\\/li><li data-list-item-id=\\\"ec17b00d9c96652226b206d8e30b071cb\\\">Andere Dritte: Alle anderen Dritten, mit denen wir zur Erf\\u00fcllung der genannten Zwecke zusammenarbeiten. Dies k\\u00f6nnen beispielsweise Medien, die \\u00d6ffentlichkeit, einschliess-lich Besuchern von Websites, Mitbewerbern, Branchenorganisationen, Verb\\u00e4nde, Organisationen und weitere Gremien sein. Zus\\u00e4tzlich k\\u00f6nnen es auch Parteien im Zusam-menhang mit einer Unternehmenstransaktion wie z. B. einer Fusion, einem Verkauf von Verm\\u00f6genswerten oder Anteilen, einer Restrukturierung, einer Finanzierung, einem Kon-trollwechsel oder der \\u00dcbernahme des gesamten oder eines Teils unseres Unternehmens sein.<\\/li><\\/ul>\\r\\n<p>Diese Kategorien von Empf\\u00e4ngern k\\u00f6nnen Dritte einbeziehen, denen Personendaten zug\\u00e4nglich gemacht werden. Dienstleister und bestimmte Vertragspartner, die in unserem Auftrag t\\u00e4tig sind, k\\u00f6nnen wir vertraglich verpflichten, die Daten nicht f\\u00fcr eigene Zwecke zu verwenden. An-dere Dritte wie Finanzdienstleister, Versicherungen oder Beh\\u00f6rden verwenden die Daten f\\u00fcr eigene Zwecke, z.B. zur Erf\\u00fcllung gesetzlicher Vorgaben, weshalb wir diese Bearbeitungen nicht einschr\\u00e4nken k\\u00f6nnen. Wir bearbeiten Ihre Personendaten vorwiegend in der Schweiz. Die Personendaten k\\u00f6nnen aber auch an Empf\\u00e4nger im Ausland bekannt gegeben werden z.B. in die USA. Dar\\u00fcber hinaus k\\u00f6n-nen die Daten in weitere Staaten des Europ\\u00e4ischen Wirtschaftsraumes \\u00fcbermittelt werden. Durch die heutige globale Vernetzung und aufgrund von international t\\u00e4tigen Konzernen ist es zudem m\\u00f6glich, dass Daten \\u00fcberall auf der Welt bearbeitet werden k\\u00f6nnen. Befindet sich ein Empf\\u00e4nger in einem Land ohne angemessenes gesetzliches Datenschutzniveau, werden wir unseren Lieferanten oder Partner, den Empf\\u00e4nger vertraglich zur Einhaltung des anwendbaren Datenschutzniveaus verpflichten, soweit er nicht bereits einem gesetzlich anerkannten Regel-werk zur Sicherstellung des Datenschutzes unterliegt und wir uns nicht auf eine Ausnahmebe-stimmung berufen k\\u00f6nnen.<\\/p>\\r\\n<h2>6. Dauer der Aufbewahrung von Personendaten<\\/h2>\\r\\n<p>Wir bearbeiten und speichern Ihre Personendaten so lange, wie es f\\u00fcr die Erf\\u00fcllung unserer vertraglichen und gesetzlichen Pflichten oder sonst die mit der Bearbeitung verfolgten Zwecke erforderlich ist, d.h. also zum Beispiel f\\u00fcr die Dauer der gesamten Klientenbeziehung sowie dar\\u00fcber hinaus gem\\u00e4ss den gesetzlichen Aufbewahrungs- und Dokumentationspflichten. Dabei ist es m\\u00f6glich, dass Personendaten f\\u00fcr die Zeit aufbewahrt werden, in der Anspr\\u00fcche gegen unser Unternehmen geltend gemacht werden k\\u00f6nnen und soweit wir anderweitig gesetzlich dazu verpflichtet sind oder berechtigte Gesch\\u00e4ftsinteressen dies erfordern (z.B. f\\u00fcr Beweis- und Do-kumentationszwecke).<\\/p>\\r\\n<h2>7. Datensicherheit<\\/h2>\\r\\n<p>Wir treffen angemessene technische und organisatorische Sicherheitsvorkehrungen zum Schutz Ihrer Personendaten. Wir ber\\u00fccksichtigen dabei den Stand der Technik, das Risiko der Bearbei-tung, die Investitionskosten und orientieren uns neben dem Schweizer Datenschutzgesetz an der Datenschutzverordnung. Die Massnahmen sollen dazu dienen Datenschutzverletzungen, wie beispielsweise dem unberechtigten Zugriff und Missbrauch der Daten, zu verhindern. Die Auf-tragsbearbeiter, an die wir Daten weitergeben weisen wir ebenfalls an angemessene technische und organisatorische Sicherheitsvorkehrungen zu treffen. Kontaktaufnahme per E-Mail Die Kommunikation mittels E-Mail ist in der Regel nicht verschl\\u00fcsselt. Werden jedoch beson-ders sch\\u00fctzenswerte Daten ausgetauscht versenden wir diese verschl\\u00fcsselt mittels HIN. Es besteht die M\\u00f6glichkeit, dass Daten verloren gehen oder von Dritten abgefangen und\\/oder manipuliert werden k\\u00f6nnen, um zum Beispiel damit die Echtheit vorzut\\u00e4uschen. Wir treffen ge-eignete technische und organisatorische Sicherheitsmassnahmen, um dies innerhalb des Sys-tems zu verhindern. Dennoch kann die Vertraulichkeit von Daten bei der \\u00dcbertragung jeglicher Daten per E-Mail nicht gew\\u00e4hrleistet werden. Dieser Hinweis gilt insbesondere in Bezug auf die \\u00dcbertragung von besonders sch\\u00fctzenswerten Personendaten, \\u00fcbermitteln Sie uns diese nicht per E-Mail, sondern kontaktieren Sie uns vorg\\u00e4ngig, um einen sicheren Kanal zu vereinbaren. Externe Zugriffsger\\u00e4te (PC, Smartphone etc. von Endnutzern) und Teile der zwischen dem Ab-sender und Empf\\u00e4nger an der \\u00dcbermittlung beteiligten Infrastruktur befinden sich ausserhalb des von uns kontrollierbaren Bereichs. Wir haften nicht f\\u00fcr Konsequenzen und Sch\\u00e4den, die sich aus dem elektronischen Informationsaustausch und insbesondere aus einer missbr\\u00e4uchli-chen Verwendung des E-Mail-Systems ergeben k\\u00f6nnen. Wir behalten uns vor uns, f\\u00fcr jeglichen vors\\u00e4tzlichen Schaden, der uns aus dem Gesch\\u00e4ftsverkehr mit der betroffenen Person \\u00fcber den elektronischen Informationsaustausch entsteht, schadlos zu halten. Weiter behalten wir uns vor, im Einzelfall nicht per E-Mail zu antworten oder f\\u00fcr die per E-Mail erhaltene Auftragsertei-lung oder Information zus\\u00e4tzlich eine andere Form zu verlangen wie z.B. \\u00fcber ein Formular mit Unterschrift.<\\/p>\\r\\n<h2>8. Pr\\u00e4ferenzen und automatisierte Einzelentscheidungen<\\/h2>\\r\\n<p>Zur Begr\\u00fcndung und Durchf\\u00fchrung der Gesch\\u00e4ftsbeziehung und auch sonst nutzen wir grund-s\\u00e4tzlich keine vollautomatisierte automatische Entscheidungsfindung. Sollten wir solche Verfah-ren in Einzelf\\u00e4llen einsetzen, werden wir Sie hier\\u00fcber gesondert informieren, sofern dies gesetz-lich vorgegeben ist und Sie \\u00fcber die damit zusammenh\\u00e4ngenden Rechte aufkl\\u00e4ren.<\\/p>\\r\\n<h2>9. Rechte der betroffenen Personen<\\/h2>\\r\\n<p>Als betroffene Person haben Sie im Zusammenhang mit der Datenbearbeitung die gesetzlich vorgesehenen Rechte. Sie haben insbesondere das Recht, Auskunft \\u00fcber Ihre gespeicherten Personendaten zu verlangen. Ebenso k\\u00f6nnen Sie eine Berichtigung, Erg\\u00e4nzung, Sperrung oder L\\u00f6schung Ihrer Personendaten verlangen. Des Weiteren steht es Ihnen frei, der Verwendung Ihrer Daten zu Marketingzwecken zu widersprechen. Ihre Einwilligung k\\u00f6nnen Sie jederzeit mit Wirkung f\\u00fcr die Zukunft widerrufen. Zus\\u00e4tzlich haben Sie das Recht, die \\u00dcbertragung Ihrer Da-ten an andere Verantwortliche zu verlangen. Wir weisen jedoch darauf hin, dass wir uns das Recht vorbehalten, gesetzliche Einschr\\u00e4nkung-gen geltend zu machen, etwa wenn wir zur Aufbewahrung oder Bearbeitung bestimmter Daten verpflichtet sind, ein berechtigtes Interesse daran haben oder die Daten zur Geltendmachung von Rechtsanspr\\u00fcchen ben\\u00f6tigen. An die Stelle der L\\u00f6schung tritt die Sperrung, sofern rechtli-che Hindernisse der L\\u00f6schung entgegenstehen. Bitte beachten Sie, dass die Aus\\u00fcbung dieser Rechte mit vertraglichen Vereinbarungen in Konflikt stehen und dies Konsequenzen wie z.B. eine vorzeitige Vertragsaufl\\u00f6sung oder Kostenfolgen nach sich ziehen kann. Wir werden Sie in einem solchen Fall vorab informieren, sofern dies nicht bereits vertraglich geregelt ist. Die Aus\\u00fcbung dieser Rechte setzt in der Regel voraus, dass Sie Ihre Identit\\u00e4t eindeutig nach-weisen (z. B. durch Vorlage einer Kopie Ihres Identit\\u00e4tsdokuments, wenn Ihre Identit\\u00e4t sonst nicht eindeutig ist oder nicht \\u00fcberpr\\u00fcft werden kann). Zur Geltendmachung Ihrer Rechte k\\u00f6nnen Sie sich an den in Kapitel 1 genannten Datenschutzberater wenden. Jede betroffene Person hat zudem das Recht, ihre Anspr\\u00fcche gerichtlich geltend zu machen oder sich bei der zust\\u00e4ndigen Datenschutzbeh\\u00f6rde zu beschweren. Zust\\u00e4ndige Datenschutzbe-h\\u00f6rde in der Schweiz ist der Eidgen\\u00f6ssische Datenschutz- und \\u00d6ffentlichkeitsbeauftragte (https:\\/\\/www.edoeb.admin.ch).<\\/p>\\r\\n<h2>10. \\u00c4nderungen dieser Datenschutzerkl\\u00e4rung<\\/h2>\\r\\n<p>Wir k\\u00f6nnen diese Datenschutzerkl\\u00e4rung jederzeit ohne vorherige Ank\\u00fcndigung \\u00e4ndern. Diese Datenschutzerkl\\u00e4rung ist nicht Teil eines Vertrages mit Ihnen. Es gilt grunds\\u00e4tzlich die jeweils aktuelle Fassung, die auf unserer Website ver\\u00f6ffentlicht ist.<\\/p>\\r\\n<h2>11. Urheberrecht und Lizenz<\\/h2>\\r\\n<p>Diese Datenschutzerkl\\u00e4rung wurde im Rahmen des Datenschutz Service von der impunix AG erstellt. Bei Fragen oder Anmerkungen d\\u00fcrfen Sie uns gerne \\u00fcber die Kontaktdaten in Kapitel 1 kontaktieren. Der Gebrauch dieser Datenschutzerkl\\u00e4rung ist ausschliesslich Kunden unseres Datenschutz Full-Service vorbehalten.<\\/p>\\r\\n<h2>12. Kategorien von Personendaten<\\/h2>\\r\\n<p>Je nach Gesch\\u00e4ftsvorfall bearbeiten wir eine oder mehrere der nachfolgenden Kategorien von Personendaten in der unten aufgelisteten Tabelle.<\\/p>\\r\\n<ul><li data-list-item-id=\\\"e00bc9d0bb0b155afa665fecf408793d4\\\">Stammdaten: Daten f\\u00fcr die Zuordnung, Behandlung und Abrechnung, wie Name, Ge-burtsdatum, Adresse, Versicherungsnummer, Klientennummer und Kontaktdaten, etc.;<\\/li><li data-list-item-id=\\\"e752925bcac1946f526f48263269de94a\\\">Bonit\\u00e4ts- und Bankdaten: Lohn, Wohnkosten, frei verf\\u00fcgbares Einkommen, Zahlungs-verhalten, Bilanzen, Daten von Auskunfteien, Score-Werte, Verm\\u00f6gensverh\\u00e4ltnisse, Kon-toverbindung, Kreditkartennummer, etc.;<\\/li><li data-list-item-id=\\\"e220a6a22f5b0fb4d2cad41e8e2604a99\\\">Gesundheitliche und medizinische Daten: Medizinische Beurteilungen, Arztzeugnisse, Diagnosen, Behandlungsverl\\u00e4ufe, Therapiepl\\u00e4ne, Ergebnisse von Untersuchungen und Laborberichten, etc.;<\\/li><li data-list-item-id=\\\"e7d947e383df5c177d3b495d1e1f39ca8\\\">Identit\\u00e4tsangaben: Daten zur Feststellung Ihrer Identit\\u00e4t, z.B. ID, etc.<\\/li><li data-list-item-id=\\\"e8231f2a04bb9589a825826ab997ff5ef\\\">Interessen und Pr\\u00e4ferenzen: Von Ihnen bereitgestellte oder erfasste Informationen \\u00fcber Ihre Interessenbereiche, z. B. die f\\u00fcr Sie interessanten Produkte, Hobbies und weitere pers\\u00f6nliche Pr\\u00e4ferenzen.;<\\/li><li data-list-item-id=\\\"ed012a16dbce9e498bbf2acc5efa31deb\\\">Kontaktdaten: Name, Adresse, Telefonnummer, E-Mail-Adresse;<\\/li><li data-list-item-id=\\\"e8700f8c2ada0c0a8a70315dd3ed8ea7b\\\">Kontaktdaten erweitert: Daten zum Ehegatten oder Kindern, Familienstand, Portraitfoto, Ehrenamt, Berufsbezeichnung, beruflicher Werdegang, Betriebszugeh\\u00f6rigkeit, Aufgaben, T\\u00e4tigkeiten, Qualifikationen, Bewertungen \\/ Beurteilungen, Zertifikate, Geburtsdatum etc.;<\\/li><li data-list-item-id=\\\"eb384bfae041adfe11890f99116a499a3\\\">Kontaktdaten beruflich: Name, Vorname, Anrede, Anschrift, E-Mail-Adresse, Telefon-nummer, Mobiltelefonnummer, Arbeitgeber, Funktion, Abteilung, Zust\\u00e4ndigkeiten, etc.;<\\/li><li data-list-item-id=\\\"ee2da6756679841591128e315c225aa20\\\">Nutzungsdaten der Website: Die IP-Adresse, Art und Version des Browsers, verwende-tes Betriebssystem und Ger\\u00e4tetyp, Referrer URL (die vorherige Website, von der aus Sie auf unsere Seite gelangt sind), den Internet-Service-Provider, Hostname des zugreifen-den Computers, Zeitpunkt der Serveranfrage, etc. Sie geben uns auch Informationen dar\\u00fcber, wie Sie die Website nutzen. Die Datenbearbeitung bei der Nutzung der Website und der App einschliesslich des Trackings mit Cookies erl\\u00e4utern wir in den Hinweisen zur Website.;<\\/li><li data-list-item-id=\\\"e5ee60508830bda8563031d5478c4dc57\\\">Technische Daten: Daten zu technischen Gegebenheiten der Systeme, wie Konfiguratio-nen, IP-Adressen, Seriennummern, Produktinformationen, Lizenzen, Dokumentationen, etc.<\\/li><li data-list-item-id=\\\"ee007410a2f398958134d7f9e58bb702c\\\">Vertragsdaten: Daten zur Gesch\\u00e4ftsbeziehung, Kundennummer, Angebote und gekaufte Produkte, Dienstleistungen oder Services (inkl. Online-Services, Datum Vertrag, Kauf-preis, Sonderw\\u00fcnsche, Garantien, Kulanz, etc.;<\\/li><li data-list-item-id=\\\"e9fad143dbbb98fa2ad39ce43d201c792\\\">Zugangsdaten: Zugangsdaten zur Authentifizierung in Systemen.<\\/li><\\/ul>\",\"linkToTop\":\"0\",\"editlock\":\"0\",\"rowDescription\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\",\"crdate\":1785748012,\"t3ver_stage\":0,\"tstamp\":1785748012,\"uid\":9}',0,'0400$bWlmv5t-KNLhV0aAjLMujzc9gQvmuA3T:367f4f227870d8e2a11496a182574aa3'),
(86,1785748214,3,'BE',2,0,7,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1785747362,\"sorting\":1290},\"newData\":{\"tstamp\":1785748214,\"sorting\":384,\"pid\":1}}',0,'0400$ubWgs6E56i5kPOkWH5MutBp3dvIaL14K:ea41b626baac59a1fe0716bc344af5d9'),
(87,1785748214,2,'BE',2,0,7,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$Pa9BRZ61NyWx6YpxXQ7wml68vMNfO2O5:ea41b626baac59a1fe0716bc344af5d9'),
(88,1785748229,3,'BE',2,0,7,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1785748214,\"sorting\":384},\"newData\":{\"tstamp\":1785748229,\"sorting\":640,\"pid\":1}}',0,'0400$bguX9TibbQM_i5dK4rh0PfBM4foHMzEY:ea41b626baac59a1fe0716bc344af5d9'),
(89,1785748737,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p><ul><li>Abgeschlossene obligatorische Schulzeit<\\/li><li>Einf\\u00fchlungsverm\\u00f6gen und Freude an der Kommunikation<\\/li><li>Aufmerksamkeit und Sorgfalt<\\/li><li>Verantwortungsbewusstsein<\\/li><\\/ul><p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p><ul><li>Mindestens 22 Jahre alt<\\/li><li>Mindestens 2 Jahre zu 60 Prozent im Berufsfeld Pflege gearbeitet<\\/li><li>Gute Deutschkenntnisse<\\/li><\\/ul>\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$vMAuEalg3m5MziQebhJjNMTAKxfp8cNk:686d480187e1617721c3b1bb09978817'),
(90,1785748980,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\"},\"newRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p>Weitere Informationen zur Ausbildung findest du auf der Plattform Gesundheitsberufe Kanton Bern und unter FaGe-Ausbildung bei der Spitex<\\/p>\"}}',0,'0400$L77wC4VtiNC-FKTdyNyTUOYtraphGSR8:686d480187e1617721c3b1bb09978817'),
(91,1785748987,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p>Weitere Informationen zur Ausbildung findest du auf der Plattform Gesundheitsberufe Kanton Bern und unter FaGe-Ausbildung bei der Spitex<\\/p>\"},\"newRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p class=\\\"text-small\\\">Weitere Informationen zur Ausbildung findest du auf der Plattform Gesundheitsberufe Kanton Bern und unter FaGe-Ausbildung bei der Spitex<\\/p>\"}}',0,'0400$-6vuRd2IAscoy4B51lfFS7ktvXPU5gTG:686d480187e1617721c3b1bb09978817'),
(92,1785749306,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p class=\\\"text-small\\\">Weitere Informationen zur Ausbildung findest du auf der Plattform Gesundheitsberufe Kanton Bern und unter FaGe-Ausbildung bei der Spitex<\\/p>\"},\"newRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<br>&nbsp;<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p class=\\\"text-small\\\">Weitere Informationen zur Ausbildung findest du auf der Plattform Gesundheitsberufe Kanton Bern und unter FaGe-Ausbildung bei der Spitex<\\/p>\"}}',0,'0400$2MGqBFDa2yKF0CvBu2Mjs1YJIn3nvDEq:686d480187e1617721c3b1bb09978817'),
(93,1785749855,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<br>&nbsp;<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p class=\\\"text-small\\\">Weitere Informationen zur Ausbildung findest du auf der Plattform Gesundheitsberufe Kanton Bern und unter FaGe-Ausbildung bei der Spitex<\\/p>\"},\"newRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<br>&nbsp;<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\\r\\n\\r\\n<p class=\\\"text-small\\\">Weitere Informationen zur Ausbildung findest du auf der Plattform <a href=\\\"https:\\/\\/gesundheitsberufe-bern.ch\\/\\\" target=\\\"_blank\\\">Gesundheitsberufe Kanton<\\/a> Bern und unter <a href=\\\"https:\\/\\/www.spitexbe.ch\\/de\\/ausbildung\\/fachfrau-fachmann-gesundheit-efz-fage\\\" target=\\\"_blank\\\">FaGe-Ausbildung<\\/a> bei der Spitex<\\/p>\"}}',0,'0400$GAYai4ggK4OPivuKo8lpiaaVcS4-bzO1:686d480187e1617721c3b1bb09978817'),
(94,1785750024,2,'BE',2,0,2,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Pflege \\u2013 mein Beruf?<\\/strong><\\/p><p>Wenn du gerne mit und f\\u00fcr Menschen arbeitest, k\\u00f6nnte ein Pflegeberuf genau das Richtige f\\u00fcr dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah.<\\/p>\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"content\":\"<p><strong>Pflege \\u2013 mein Beruf?<\\/strong><\\/p>\\r\\n<p>Wenn du gerne mit und f\\u00fcr Menschen arbeitest, k\\u00f6nnte ein Pflegeberuf genau das Richtige f\\u00fcr dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah. So findest du rasch heraus, ob ein Pflegeberuf der richtige Weg f\\u00fcr dich ist.<\\/p>\\r\\n<p><strong>Anmeldung<\\/strong><\\/p>\\r\\n<p>Die Anmeldung f\\u00fcr ein Berufswahlpraktikum l\\u00e4uft \\u00fcber das Internetportal Gesundheitsberufe Kanton Bern. Nach der Anmeldung nimmt die Spitex Region Lueg mit dir Kontakt auf und organisiert gemeinsam mit dir das Berufswahlpraktikum.<\\/p>\\r\\n<p><br \\/>Link zu <a href=\\\"https:\\/\\/myoda.gesundheitsberufe-bern.ch\\/de\\/\\\" target=\\\"_blank\\\">myoda<\\/a><br \\/><a href=\\\"https:\\/\\/gesundheitsberufe-bern.ch\\/schnuppern-praktika\\/myoda-erklaert\\\" target=\\\"_blank\\\">Anleitung zu myoda<\\/a><\\/p>\\r\\n\\r\\n\\r\\n\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$h9cBm4i7GmaIggSyOuMErTEnaBKM7vtz:729ffd98535f26f433ff7532650dd9e6'),
(95,1785750024,2,'BE',2,0,3,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p>Wir unterst\\u00fctzen dich bei deiner fachlichen und pers\\u00f6nlichen Weiterentwicklung \\u2013 mit internen Angeboten und externen Kursen.<\\/p>\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"content\":\"<p>Bei uns wirst du gezielt gef\\u00f6rdert: Wir unterst\\u00fctzen dich in deiner pers\\u00f6nlichen Entwicklung und planen deinen Weg gemeinsam mit dir. Zudem bieten wir jedes Jahr Ausbildungspl\\u00e4tze auf HF Stufe \\u2013 zusmmen mit dem Berner Bildungszentrum Pflege und XUND. Ausgebildete Berufsbildner:innen und Bildungsverantwortliche begleiten dich eng, damit du die Spitex Arbeit wirklich kennenlernst und deine Praktikumsziele erreichst.<\\/p>\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$h9cBm4i7GmaIggSyOuMErTEnaBKM7vtz:c24a30159f7e49e143b807c1b78676e8'),
(96,1785750055,2,'BE',2,0,2,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Pflege \\u2013 mein Beruf?<\\/strong><\\/p>\\r\\n<p>Wenn du gerne mit und f\\u00fcr Menschen arbeitest, k\\u00f6nnte ein Pflegeberuf genau das Richtige f\\u00fcr dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah. So findest du rasch heraus, ob ein Pflegeberuf der richtige Weg f\\u00fcr dich ist.<\\/p>\\r\\n<p><strong>Anmeldung<\\/strong><\\/p>\\r\\n<p>Die Anmeldung f\\u00fcr ein Berufswahlpraktikum l\\u00e4uft \\u00fcber das Internetportal Gesundheitsberufe Kanton Bern. Nach der Anmeldung nimmt die Spitex Region Lueg mit dir Kontakt auf und organisiert gemeinsam mit dir das Berufswahlpraktikum.<\\/p>\\r\\n<p><br \\/>Link zu <a href=\\\"https:\\/\\/myoda.gesundheitsberufe-bern.ch\\/de\\/\\\" target=\\\"_blank\\\">myoda<\\/a><br \\/><a href=\\\"https:\\/\\/gesundheitsberufe-bern.ch\\/schnuppern-praktika\\/myoda-erklaert\\\" target=\\\"_blank\\\">Anleitung zu myoda<\\/a><\\/p>\\r\\n\\r\\n\\r\\n\"},\"newRecord\":{\"content\":\"<p><strong>Pflege \\u2013 mein Beruf?<\\/strong><\\/p>\\r\\n<p>Wenn du gerne mit und f\\u00fcr Menschen arbeitest, k\\u00f6nnte ein Pflegeberuf genau das Richtige f\\u00fcr dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah. So findest du rasch heraus, ob ein Pflegeberuf der richtige Weg f\\u00fcr dich ist.<\\/p>\\r\\n<p><strong>Anmeldung<\\/strong><\\/p>\\r\\n<p>Die Anmeldung f\\u00fcr ein Berufswahlpraktikum l\\u00e4uft \\u00fcber das Internetportal Gesundheitsberufe Kanton Bern. Nach der Anmeldung nimmt die Spitex Region Lueg mit dir Kontakt auf und organisiert gemeinsam mit dir das Berufswahlpraktikum.<\\/p>\\r\\n<p><br \\/>Link zu <a href=\\\"https:\\/\\/myoda.gesundheitsberufe-bern.ch\\/de\\/\\\" target=\\\"_blank\\\">myoda<\\/a><br \\/><a href=\\\"https:\\/\\/gesundheitsberufe-bern.ch\\/schnuppern-praktika\\/myoda-erklaert\\\" target=\\\"_blank\\\">Anleitung zu myoda<\\/a><\\/p>\"}}',0,'0400$2KdZ886gXbg-dUf8ig8fUNBBiTETOb-e:729ffd98535f26f433ff7532650dd9e6'),
(97,1785750302,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"slug\":\"\\/freie\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"slug\":\"\\/freie-stellen\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$jbWRBZzSPmLfXMIJ_S4c1tGzBYjKUj1n:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(98,1785759538,2,'BE',2,0,7,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 <br>\\u00fcsi freie Stelle\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>\\u00dcsi freie Jobs\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$O_bBpFEiSsOwbfPbcvkVe2o-VzUGk63O:ea41b626baac59a1fe0716bc344af5d9'),
(99,1785847064,2,'BE',2,0,1,'tx_powermail_domain_model_page','{\"oldRecord\":{\"title\":\"Bewerbung\",\"l10n_diffsource\":null},\"newRecord\":{\"title\":\"Jetzt ganz einfach Kontakt aufnehmen und direkt bewerben\",\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fields\\\":\\\"\\\",\\\"form\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:815cca2cf067a5fe97906554dd6c4ed0'),
(100,1785847064,2,'BE',2,0,1,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:ed5eb58d03ba4d3d71a179b4d8b4a71a'),
(101,1785847064,2,'BE',2,0,2,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:b81fa3248eb0979894ffb18e8664f4bc'),
(102,1785847064,2,'BE',2,0,3,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:a8d7ff9f004bc4385d27c077c840ab4a'),
(103,1785847064,2,'BE',2,0,4,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:80f063665beebd0450888f3fa2497ab9'),
(104,1785847064,2,'BE',2,0,5,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:8e79b3fad92007430c6158853517bb53'),
(105,1785847064,2,'BE',2,0,6,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:2eac15cec105d1e4e874b103ce4be2d2'),
(106,1785847064,2,'BE',2,0,7,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4q17Awpam0WG0bB2CF-DbqItlumsKwab:1f7b8887d1c0ca099ea5f83be1173d10'),
(107,1785847079,2,'BE',2,0,1,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"multiselect\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\"}\"}}',0,'0400$4utds0rQO-F9vm-qStTF_hQAvM2D0nsc:ed5eb58d03ba4d3d71a179b4d8b4a71a'),
(108,1785847125,3,'BE',2,0,11,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1785769130,\"sorting\":1300},\"newData\":{\"tstamp\":1785847125,\"sorting\":1152,\"pid\":1}}',0,'0400$0r_1MsgBDOnLH7nxial8kyUQmnisThW6:7a14c618500ae24604910dfdd2f8ff12'),
(109,1785847125,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":null},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$yoO-Er2SC1iTv-V8sX8pvSjyXmWMUy43:7a14c618500ae24604910dfdd2f8ff12'),
(110,1785847146,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 u chum zu \\u00fcs\",\"fe_group\":\"0\",\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>u chum zu \\u00fcs\",\"fe_group\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_bewerben_steps\\\":\\\"\\\",\\\"lueg_bewerben_steps_heading\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$a8zRfHsIG8oNmXgtmNXULTotz0H_PqqU:7a14c618500ae24604910dfdd2f8ff12'),
(111,1785847146,2,'BE',2,0,1,'lueg_bewerben_steps','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$a8zRfHsIG8oNmXgtmNXULTotz0H_PqqU:024869e980cf542d6452ca99de6825a6'),
(112,1785847146,2,'BE',2,0,2,'lueg_bewerben_steps','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$a8zRfHsIG8oNmXgtmNXULTotz0H_PqqU:22a988f4bee4cbc91b54cc370869c9ba'),
(113,1785847146,2,'BE',2,0,3,'lueg_bewerben_steps','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$a8zRfHsIG8oNmXgtmNXULTotz0H_PqqU:84c441aea90cf98bbe843cb4ac63a455'),
(114,1785847146,2,'BE',2,0,4,'lueg_bewerben_steps','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$a8zRfHsIG8oNmXgtmNXULTotz0H_PqqU:8fc5801f419cd453f63ffa78b78eb292'),
(115,1785848054,1,'BE',2,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/impressum\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1472,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Impressum\",\"sys_language_uid\":0,\"crdate\":1785848054,\"t3ver_stage\":0,\"tstamp\":1785848054,\"uid\":10}',0,'0400$GuFiNIzl33qisFcFBCTKRGlJWqjKT4z3:e904af5a60392ab3165f5849f5877e45'),
(116,1785848056,2,'BE',2,0,10,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$NSNZIR4pn_8OUC7BCsccItHqLRIhbDJx:e904af5a60392ab3165f5849f5877e45'),
(117,1785848059,2,'BE',2,0,10,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$vNIUgFoue7c44vsE8WeUlcGz_RPeuUvf:e904af5a60392ab3165f5849f5877e45'),
(118,1785848537,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Textseite\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$-M1msc63xc9YosthqoxQB27t_ZJitvIW:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(119,1785848549,2,'BE',2,0,10,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Textseite\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$VkJ0y_7Hyg19CP1p1dbbMcgoMJNreTFF:e904af5a60392ab3165f5849f5877e45'),
(120,1785849330,1,'BE',2,0,12,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Spitex Region Lueg<br \\/>Gesch\\u00e4ftsstelle<br \\/>R\\u00fcegsaustrasse 8<br \\/>Postfach<br \\/>3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p><a href=\\\"tel:+41344605000\\\">034 460 50 00<\\/a><br \\/><a href=\\\"https:\\/\\/www.spitexlueg.ch\\/de\\/impressum\\/#wEmpty\\\">nfsptxlgch<\\/a><\\/p>\\r\\n<p><strong>Vertretungsberechtigte Person<\\/strong><br \\/>Andreas B\\u00fctikofer, Gesch\\u00e4ftsleiter<\\/p>\\r\\n<p><strong>Handelsregister-Eintrag<\\/strong><br \\/>Eingetragener Firmenname: Spitex Region Lueg<br \\/>Handelsregister Nr: CHE-114.295.948<\\/p>\\r\\n<p><strong>Mehrwertsteuer-Nummer<\\/strong><br \\/>CHE-114.295.948<\\/p>\\r\\n<p>Konzept &amp; Design &amp; Programmierung<\\/p>\\r\\n<p><a href=\\\"https:\\/\\/studiothompfister.com\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener\\\">Studio Thom Pfister<\\/a><br \\/>&nbsp;<\\/p>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1785849330,\"t3ver_stage\":0,\"tstamp\":1785849330,\"uid\":12}',0,'0400$Tz5snYHenLrsU2ceJPgcBL5CWAu7FS75:b13bbccfb8e2fc277be02db62485ced6'),
(121,1785849352,2,'BE',2,0,12,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Spitex Region Lueg<br \\/>Gesch\\u00e4ftsstelle<br \\/>R\\u00fcegsaustrasse 8<br \\/>Postfach<br \\/>3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p><a href=\\\"tel:+41344605000\\\">034 460 50 00<\\/a><br \\/><a href=\\\"https:\\/\\/www.spitexlueg.ch\\/de\\/impressum\\/#wEmpty\\\">nfsptxlgch<\\/a><\\/p>\\r\\n<p><strong>Vertretungsberechtigte Person<\\/strong><br \\/>Andreas B\\u00fctikofer, Gesch\\u00e4ftsleiter<\\/p>\\r\\n<p><strong>Handelsregister-Eintrag<\\/strong><br \\/>Eingetragener Firmenname: Spitex Region Lueg<br \\/>Handelsregister Nr: CHE-114.295.948<\\/p>\\r\\n<p><strong>Mehrwertsteuer-Nummer<\\/strong><br \\/>CHE-114.295.948<\\/p>\\r\\n<p>Konzept &amp; Design &amp; Programmierung<\\/p>\\r\\n<p><a href=\\\"https:\\/\\/studiothompfister.com\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener\\\">Studio Thom Pfister<\\/a><br \\/>&nbsp;<\\/p>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<p>Spitex Region Lueg<br \\/>Gesch\\u00e4ftsstelle<br \\/>R\\u00fcegsaustrasse 8<br \\/>Postfach<br \\/>3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p><a href=\\\"tel:+41344605000\\\">034 460 50 00<\\/a><br \\/><a href=\\\"https:\\/\\/www.spitexlueg.ch\\/de\\/impressum\\/#wEmpty\\\">nfsptxlgch<\\/a><\\/p>\\r\\n<p><strong>Vertretungsberechtigte Person<\\/strong><br \\/>Andreas B\\u00fctikofer, Gesch\\u00e4ftsleiter<\\/p>\\r\\n<p><strong>Handelsregister-Eintrag<\\/strong><br \\/>Eingetragener Firmenname: Spitex Region Lueg<br \\/>Handelsregister Nr: CHE-114.295.948<\\/p>\\r\\n<p><strong>Mehrwertsteuer-Nummer<\\/strong><br \\/>CHE-114.295.948<\\/p>\\r\\n<p><br \\/>Konzept &amp; Design &amp; Programmierung<br \\/><a href=\\\"https:\\/\\/studiothompfister.com\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener\\\">Studio Thom Pfister<\\/a><br \\/>&nbsp;<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$DH_JLet8sCzE0iLIel_94hEEnLrUajiy:b13bbccfb8e2fc277be02db62485ced6'),
(122,1785849408,2,'BE',2,0,12,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p>Spitex Region Lueg<br \\/>Gesch\\u00e4ftsstelle<br \\/>R\\u00fcegsaustrasse 8<br \\/>Postfach<br \\/>3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p><a href=\\\"tel:+41344605000\\\">034 460 50 00<\\/a><br \\/><a href=\\\"https:\\/\\/www.spitexlueg.ch\\/de\\/impressum\\/#wEmpty\\\">nfsptxlgch<\\/a><\\/p>\\r\\n<p><strong>Vertretungsberechtigte Person<\\/strong><br \\/>Andreas B\\u00fctikofer, Gesch\\u00e4ftsleiter<\\/p>\\r\\n<p><strong>Handelsregister-Eintrag<\\/strong><br \\/>Eingetragener Firmenname: Spitex Region Lueg<br \\/>Handelsregister Nr: CHE-114.295.948<\\/p>\\r\\n<p><strong>Mehrwertsteuer-Nummer<\\/strong><br \\/>CHE-114.295.948<\\/p>\\r\\n<p><br \\/>Konzept &amp; Design &amp; Programmierung<br \\/><a href=\\\"https:\\/\\/studiothompfister.com\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener\\\">Studio Thom Pfister<\\/a><br \\/>&nbsp;<\\/p>\"},\"newRecord\":{\"bodytext\":\"<p>Spitex Region Lueg<br \\/>Gesch\\u00e4ftsstelle<br \\/>R\\u00fcegsaustrasse 8<br \\/>Postfach<br \\/>3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p><a href=\\\"tel:+41344605000\\\">034 460 50 00<\\/a><br \\/><a href=\\\"mailto:info@spitexlueg.ch\\\">info@spitexlueg.ch<\\/a><\\/p>\\r\\n<p><strong>Vertretungsberechtigte Person<\\/strong><br \\/>Andreas B\\u00fctikofer, Gesch\\u00e4ftsleiter<\\/p>\\r\\n<p><strong>Handelsregister-Eintrag<\\/strong><br \\/>Eingetragener Firmenname: Spitex Region Lueg<br \\/>Handelsregister Nr: CHE-114.295.948<\\/p>\\r\\n<p><strong>Mehrwertsteuer-Nummer<\\/strong><br \\/>CHE-114.295.948<\\/p>\\r\\n<p><br \\/>Konzept &amp; Design &amp; Programmierung<br \\/><a href=\\\"https:\\/\\/studiothompfister.com\\/\\\" target=\\\"_blank\\\" rel=\\\"noopener\\\">Studio Thom Pfister<\\/a><br \\/>&nbsp;<\\/p>\"}}',0,'0400$zzsS8bvPqLLMe52hHFtoMLZC5RFqEEqS:b13bbccfb8e2fc277be02db62485ced6'),
(123,1785911435,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"title\":\"Standorte Spitex Region Lueg\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Unsere Standorte\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"}}',0,'0400$7ZbACom2WA5AdqYfA9I83asRE9ImR7x5:c75354c439a48dbde16b03ac553a080d'),
(124,1785911440,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"title\":\"Unsere Standorte\"},\"newRecord\":{\"title\":\"Standorte\"}}',0,'0400$iyq6mmr6zj8c9ZE_WPi92wOc9Xm1S3Jg:c75354c439a48dbde16b03ac553a080d'),
(125,1785911456,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"slug\":\"\\/standorte-spitex-region-lueg\",\"url\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"slug\":\"\\/standorte\",\"url\":\"\\/#standorte\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"}}',0,'0400$hOOlyAjlouCsokBq7433thMNiK0CXQUf:c75354c439a48dbde16b03ac553a080d'),
(126,1785911530,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"title\":\"Standorte\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Standorte Test\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"}}',0,'0400$I9jpfMHOVNC2nmtGUiuv-dHJbQ-LMbkV:c75354c439a48dbde16b03ac553a080d'),
(127,1785911536,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"}}',0,'0400$Zb9bSABC4VrECXO-_xah3yPqlA4mV37q:c75354c439a48dbde16b03ac553a080d'),
(128,1785911683,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"subtitle\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"},\"newRecord\":{\"subtitle\":\"Chum zu \\u00fcs<br>ids Team\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$-TeGWkb1mZYivhgeYZ6Ff-5RvCWKd9Yq:e175f7045d7ccbfb26ffcf279422c2e5'),
(129,1785911683,2,'BE',2,0,3,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$-TeGWkb1mZYivhgeYZ6Ff-5RvCWKd9Yq:d2c609347a4764200256b39b9425159a'),
(130,1785911698,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 mir biude <br> Lernendi us\",\"fe_group\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_ausbildung_items\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>mir biude Lernendi us\",\"fe_group\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_ausbildung_items\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$B1Q8L407V1GgJOmA6BMJpp-mksBwAONp:b92300cfb5d1d3645c9cb212a7f56c1f'),
(131,1785911698,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$B1Q8L407V1GgJOmA6BMJpp-mksBwAONp:686d480187e1617721c3b1bb09978817'),
(132,1785911698,2,'BE',2,0,2,'lueg_ausbildung_items','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$B1Q8L407V1GgJOmA6BMJpp-mksBwAONp:729ffd98535f26f433ff7532650dd9e6'),
(133,1785911698,2,'BE',2,0,3,'lueg_ausbildung_items','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$B1Q8L407V1GgJOmA6BMJpp-mksBwAONp:c24a30159f7e49e143b807c1b78676e8'),
(134,1785913205,2,'BE',2,0,2,'pages','{\"oldRecord\":{\"url\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"url\":\"#podcasts\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"}}',0,'0400$tXTqrbYzgaH3JsHjCsNw8VYQz2zbSFeN:f11830df10b4b0bca2db34810c2241b3'),
(135,1785913211,2,'BE',2,0,4,'pages','{\"oldRecord\":{\"url\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"url\":\"#benefits\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"}}',0,'0400$J-gWPX_lD5W3rPD26oISMScoYagFw2ol:412add0b3eb6ec8f1cb6710aea92e21e'),
(136,1785913218,2,'BE',2,0,5,'pages','{\"oldRecord\":{\"url\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"url\":\"#bewerben\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"}}',0,'0400$Cgv9RFSv0OQJLzRcFhDfv6_I02uPCQgL:7ef5a4e3e11db8ac3fea4d7a75468161'),
(137,1785913596,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"title\":\"Standorte Test\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"url\\\":\\\"\\\"}\"},\"newRecord\":{\"title\":\"Standorte\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\"}\"}}',0,'0400$pr1z6DLuDSXOuYQ-hcr25msWQRZkpbIo:c75354c439a48dbde16b03ac553a080d'),
(138,1785914429,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"title\":\"Standorte\"},\"newRecord\":{\"title\":\"Standorte e\"}}',0,'0400$oxK-P7Z_He6tFaSPaQN1rFOexEDyYDir:c75354c439a48dbde16b03ac553a080d'),
(139,1785915294,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"title\":\"Standorte e\"},\"newRecord\":{\"title\":\"Standorte\"}}',0,'0400$n2HCL4W0g4nHld6ayKejmyd9fYva59y1:c75354c439a48dbde16b03ac553a080d'),
(140,1785916332,1,'BE',2,0,11,'pages','{\"doktype\":\"254\",\"slug\":\"\\/kontaktformular\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1664,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Kontaktformular\",\"sys_language_uid\":0,\"crdate\":1785916332,\"t3ver_stage\":0,\"tstamp\":1785916332,\"uid\":11}',0,'0400$vLF8i2Omg_Muab2Odx-n61h4M3AKk0rO:51bca2bcf14079cc366c99de31802400'),
(141,1785916334,2,'BE',2,0,11,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$E68H1X8pISN9dmVhXoNzJZ0UwP2h0B5s:51bca2bcf14079cc366c99de31802400'),
(142,1785916473,1,'BE',2,0,12,'pages','{\"doktype\":\"1\",\"slug\":\"\\/danke-fuer-deine-bewerbung\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":1504,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Danke f\\u00fcr Deine Bewerbung\",\"sys_language_uid\":0,\"crdate\":1785916473,\"t3ver_stage\":0,\"tstamp\":1785916473,\"uid\":12}',0,'0400$JXRm9WLYE_dOhkGED6ogUbHQWUcvAubW:d6f57183d4ec29f4a568a174f36b861b'),
(143,1785916476,1,'BE',2,0,13,'tt_content','{\"CType\":\"powermail_pi1\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":11,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\">Spitex Region Lueg<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\">personal@spitexlueg.ch<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\">Nachricht \\u00fcber das Kontaktformular<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Guten Tag&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;\\u00dcber das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht.&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;Die \\u00fcbermittelten Angaben finden Sie nachfolgend:&lt;\\/p&gt;\\n&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1785916476,\"t3ver_stage\":0,\"tstamp\":1785916476,\"uid\":13}',0,'0400$8BjEdNFpLdJ_p-obM-eplaLdkvmcFq2_:aa58d78b4f5fe95c0d2d1cb36d041737'),
(144,1785916485,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\">Spitex Region Lueg<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\">personal@spitexlueg.ch<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\">Nachricht \\u00fcber das Kontaktformular<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Guten Tag&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;\\u00dcber das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht.&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;Die \\u00fcbermittelten Angaben finden Sie nachfolgend:&lt;\\/p&gt;\\n&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\">Spitex Region Lueg<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\">personal@spitexlueg.ch<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\">Nachricht \\u00fcber das Kontaktformular<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Guten Tag&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;\\u00dcber das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht.&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;Die \\u00fcbermittelten Angaben finden Sie nachfolgend:&lt;\\/p&gt;\\n&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\">t3:\\/\\/page?uid=12<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$6072imsyrOVxYS3OT-K41LlNX3ZfR5bM:aa58d78b4f5fe95c0d2d1cb36d041737'),
(145,1785916489,2,'BE',2,0,12,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$AMjHmyWOZW91qiNsJvHZ5th3yAHUH9Ry:d6f57183d4ec29f4a568a174f36b861b'),
(146,1785916492,2,'BE',2,0,12,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$i2L_oAYzxM7XfhrORJYzufl6cJgqTII-:d6f57183d4ec29f4a568a174f36b861b'),
(147,1785916500,2,'BE',2,0,12,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__Textseite\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$wGbTx7xa147gF3icAbvQFghJFsPgp368:d6f57183d4ec29f4a568a174f36b861b'),
(148,1785916515,1,'BE',2,0,29,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":12,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1785916515,\"t3ver_stage\":0,\"tstamp\":1785916515,\"uid\":29}',0,'0400$sBdKDdjMT_gKWZD4q1HC0QhbinncQ4rt:b242d4aecdf71ef1fd418f92b6b759e2'),
(149,1785916632,1,'BE',2,0,30,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"danke\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"showinpreview\":\"0\",\"pid\":12,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"34\",\"sys_language_uid\":0,\"crdate\":1785916632,\"t3ver_stage\":0,\"tstamp\":1785916632,\"uid\":30}',0,'0400$Lylp5SMDtWwJ0z5vunltdfvxU_KSGwH0:8567b700a7babdbf06fe14b610c41b11'),
(150,1785916632,4,'BE',2,0,29,'sys_file_reference',NULL,0,'0400$Lylp5SMDtWwJ0z5vunltdfvxU_KSGwH0:b242d4aecdf71ef1fd418f92b6b759e2'),
(151,1785916848,1,'BE',2,0,14,'tt_content','{\"CType\":\"text\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":12,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<h2>Vielen Dank f\\u00fcr deine Bewerbung!&nbsp;<\\/h2>\\r\\n<p><br \\/>Wir haben deine Angaben erfolgreich erhalten und werden uns so bald wie m\\u00f6glich bei dir melden.<\\/p>\\r\\n<p>Ihr Spitex Region Lueg<\\/p>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1785916848,\"t3ver_stage\":0,\"tstamp\":1785916848,\"uid\":14}',0,'0400$EzUNPSRaXqVWMAdESaorN6muyORwMCSY:338e104baa774eacaec42da729015b5f'),
(152,1785917229,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\">Spitex Region Lueg<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\">personal@spitexlueg.ch<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\">Nachricht \\u00fcber das Kontaktformular<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Guten Tag&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;\\u00dcber das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht.&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;Die \\u00fcbermittelten Angaben finden Sie nachfolgend:&lt;\\/p&gt;\\n&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\">t3:\\/\\/page?uid=12<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\">Spitex Region Lueg<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\">dani@studiothompfister.com<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\">Nachricht \\u00fcber das Kontaktformular<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;Guten Tag&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;\\u00dcber das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht.&amp;nbsp;&lt;\\/p&gt;\\n&lt;p&gt;Die \\u00fcbermittelten Angaben finden Sie nachfolgend:&lt;\\/p&gt;\\n&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\">t3:\\/\\/page?uid=12<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$JIxXX38mPW8jrwuNxDYoi-9GJH6vtTzP:aa58d78b4f5fe95c0d2d1cb36d041737'),
(153,1785917276,2,'BE',2,0,14,'tt_content','{\"oldRecord\":{\"bodytext\":\"<h2>Vielen Dank f\\u00fcr deine Bewerbung!&nbsp;<\\/h2>\\r\\n<p><br \\/>Wir haben deine Angaben erfolgreich erhalten und werden uns so bald wie m\\u00f6glich bei dir melden.<\\/p>\\r\\n<p>Ihr Spitex Region Lueg<\\/p>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<h2>Vielen Dank f\\u00fcr deine Bewerbung!&nbsp;<\\/h2>\\r\\n<p><br \\/>Wir haben deine Angaben erfolgreich erhalten und werden uns so bald wie m\\u00f6glich bei Dir melden.<\\/p>\\r\\n<p>Ihr Spitex Region Lueg<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$oVF74QZn1-EUUWyD0KfgQpe5BUCO4K6A:338e104baa774eacaec42da729015b5f');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(96,2,1785917276,'tt_content',14,12,'studio_lg',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=705 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1785485820,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL,0),
(2,1785486315,2,1,0,'',0,0,'Personal settings changed',254,'default','172.18.0.6','',-1,0,'',0,'','info',NULL,NULL,0),
(3,1785490037,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"SPITEX_SCHUH-77_2.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(4,1785490041,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":1,\"history\":\"1\"}',0,0,'',0,'','info',NULL,NULL,0),
(5,1785490041,2,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(6,1785490041,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL,0),
(7,1785490063,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(8,1785490085,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'table_local\' in \'INSERT INTO\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 63',5,'php','','',-1,0,'',0,'','error',NULL,NULL,0),
(9,1785490101,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(10,1785490283,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(11,1785491536,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(12,1785491537,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Layouts/Default.html, line 11 at character 2. Error: The ViewHelper \"<vite:asset>\" could not be resolved.\nBased on your spelling, the system would load the class \"Praetorius\\ViteAssetCollector\\ViewHelpers\\AssetViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <vite:asset entry=\"EXT:site_package/Resources/Private/Frontend/main.js\"/> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.6','',-1,0,'',0,'','error',NULL,NULL,0),
(13,1785491538,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Layouts/Default.html, line 11 at character 2. Error: The ViewHelper \"<vite:asset>\" could not be resolved.\nBased on your spelling, the system would load the class \"Praetorius\\ViteAssetCollector\\ViewHelpers\\AssetViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <vite:asset entry=\"EXT:site_package/Resources/Private/Frontend/main.js\"/> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.6','',-1,0,'',0,'','error',NULL,NULL,0),
(14,1785491602,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(15,1785491657,2,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(16,1785491662,2,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"history\":\"5\"}',1,0,'',0,'','info',NULL,NULL,0),
(17,1785491690,2,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(18,1785491694,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"history\":\"7\"}',1,0,'',0,'','info',NULL,NULL,0),
(19,1785491709,2,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(20,1785491735,2,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(21,1785491741,2,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"history\":\"10\"}',1,0,'',0,'','info',NULL,NULL,0),
(22,1785491743,2,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"history\":\"11\"}',1,0,'',0,'','info',NULL,NULL,0),
(23,1785491929,2,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(24,1785491933,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"history\":\"13\"}',1,0,'',0,'','info',NULL,NULL,0),
(25,1785491942,2,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(26,1785491945,2,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":7,\"history\":\"15\"}',1,0,'',0,'','info',NULL,NULL,0),
(27,1785492158,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(28,1785492970,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(29,1785492999,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(30,1785493028,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(31,1785496913,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(32,1785498371,2,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"16\"}',1,0,'',0,'','info',NULL,NULL,0),
(33,1785498371,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"17\"}',1,0,'',0,'','info',NULL,NULL,0),
(34,1785498371,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"18\"}',1,0,'',0,'','info',NULL,NULL,0),
(35,1785498403,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(36,1785498504,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Homepage\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(37,1785498514,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"podcasts\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(38,1785498521,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"test.jpg\",\"destination\":\"\\/user_upload\\/podcasts\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(39,1785498532,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"19\"}',1,0,'',0,'','info',NULL,NULL,0),
(40,1785498532,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"20\"}',1,0,'',0,'','info',NULL,NULL,0),
(41,1785498532,2,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(42,1785498532,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"22\"}',1,0,'',0,'','info',NULL,NULL,0),
(43,1785498532,2,3,5,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(44,1785498691,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Bildschirmfoto 2026-07-31 um 13.51.25.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(45,1785498693,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"24\"}',1,0,'',0,'','info',NULL,NULL,0),
(46,1785498693,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"25\"}',1,0,'',0,'','info',NULL,NULL,0),
(47,1785498693,2,2,8,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":8,\"history\":\"26\"}',1,0,'',0,'','info',NULL,NULL,0),
(48,1785498693,2,2,6,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":6,\"history\":\"27\"}',1,0,'',0,'','info',NULL,NULL,0),
(49,1785498693,2,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(50,1785498693,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"29\"}',1,0,'',0,'','info',NULL,NULL,0),
(51,1785498693,2,3,7,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(52,1785498866,2,2,9,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":9,\"history\":\"31\"}',1,0,'',0,'','info',NULL,NULL,0),
(53,1785498869,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(54,1785499009,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(55,1785499018,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(56,1785499594,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(57,1785500631,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(58,1785501115,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(59,1785502132,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"32\"}',1,0,'',0,'','info',NULL,NULL,0),
(60,1785502135,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(61,1785503682,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"33\"}',1,0,'',0,'','info',NULL,NULL,0),
(62,1785503682,2,2,1,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":1,\"history\":\"34\"}',1,0,'',0,'','info',NULL,NULL,0),
(63,1785503682,2,2,2,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":2,\"history\":\"35\"}',1,0,'',0,'','info',NULL,NULL,0),
(64,1785503682,2,2,3,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":3,\"history\":\"36\"}',1,0,'',0,'','info',NULL,NULL,0),
(65,1785503682,2,2,4,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":4,\"history\":\"37\"}',1,0,'',0,'','info',NULL,NULL,0),
(66,1785503682,2,2,5,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":5,\"history\":\"38\"}',1,0,'',0,'','info',NULL,NULL,0),
(67,1785503682,2,2,6,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":6,\"history\":\"39\"}',1,0,'',0,'','info',NULL,NULL,0),
(68,1785503682,2,2,7,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":7,\"history\":\"40\"}',1,0,'',0,'','info',NULL,NULL,0),
(69,1785503682,2,2,8,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":8,\"history\":\"41\"}',1,0,'',0,'','info',NULL,NULL,0),
(70,1785503682,2,2,9,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":9,\"history\":\"42\"}',1,0,'',0,'','info',NULL,NULL,0),
(71,1785503682,2,2,10,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":10,\"history\":\"43\"}',1,0,'',0,'','info',NULL,NULL,0),
(72,1785509214,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"standort-weier.jpg\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(73,1785509265,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(74,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"44\"}',1,0,'',0,'','info',NULL,NULL,0),
(75,1785509276,2,1,24,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(76,1785509276,2,1,25,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(77,1785509276,2,2,22,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":22,\"history\":\"47\"}',1,0,'',0,'','info',NULL,NULL,0),
(78,1785509276,2,2,23,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":23,\"history\":\"48\"}',1,0,'',0,'','info',NULL,NULL,0),
(79,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"49\"}',1,0,'',0,'','info',NULL,NULL,0),
(80,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"50\"}',1,0,'',0,'','info',NULL,NULL,0),
(81,1785509276,2,3,20,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(82,1785509276,2,3,21,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(83,1785509279,2,2,24,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":24,\"history\":\"53\"}',1,0,'',0,'','info',NULL,NULL,0),
(84,1785509279,2,2,25,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"history\":\"54\"}',1,0,'',0,'','info',NULL,NULL,0),
(85,1785509423,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Frontbild_SR_2.webp\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(86,1785509465,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(87,1785509487,2,1,26,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":26,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(88,1785509487,2,1,27,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":27,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(89,1785509487,2,1,28,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":28,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(90,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(91,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(92,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(93,1785509487,2,3,25,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(94,1785509487,2,3,22,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(95,1785509487,2,3,23,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(96,1785509547,2,2,26,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":26,\"history\":\"61\"}',1,0,'',0,'','info',NULL,NULL,0),
(97,1785509547,2,2,27,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":27,\"history\":\"62\"}',1,0,'',0,'','info',NULL,NULL,0),
(98,1785509547,2,2,28,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":28,\"history\":\"63\"}',1,0,'',0,'','info',NULL,NULL,0),
(99,1785509549,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(100,1785740600,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL,0),
(101,1785740613,2,6,0,'',0,1,'File or directory \"{identifier}\" already exists',2,'file','172.18.0.5','{\"identifier\":\"Icons\"}',-1,0,'',0,'','info',NULL,NULL,0),
(102,1785742992,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"icons OK\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(103,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"TEAM-EVENTS.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(104,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Chat.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(105,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Fitness.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(106,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Mobilitaet.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(107,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"MITGESTALTUNG.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(108,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Pin.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(109,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Familie.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(110,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Grippe.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(111,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"win a collegue.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(112,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Ausbildung.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(113,1785743102,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(114,1785745609,2,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(115,1785745614,2,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"history\":\"65\"}',1,0,'',0,'','info',NULL,NULL,0),
(116,1785746317,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(117,1785746374,2,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"66\"}',1,0,'',0,'','info',NULL,NULL,0),
(118,1785746374,2,2,1,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":1,\"history\":\"67\"}',1,0,'',0,'','info',NULL,NULL,0),
(119,1785746374,2,2,2,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":2,\"history\":\"68\"}',1,0,'',0,'','info',NULL,NULL,0),
(120,1785746374,2,2,3,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":3,\"history\":\"69\"}',1,0,'',0,'','info',NULL,NULL,0),
(121,1785746374,2,2,4,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":4,\"history\":\"70\"}',1,0,'',0,'','info',NULL,NULL,0),
(122,1785746374,2,2,5,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":5,\"history\":\"71\"}',1,0,'',0,'','info',NULL,NULL,0),
(123,1785746396,2,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"72\"}',1,0,'',0,'','info',NULL,NULL,0),
(124,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(125,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(126,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(127,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(128,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(129,1785746643,2,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"73\"}',1,0,'',0,'','info',NULL,NULL,0),
(130,1785746680,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"74\"}',1,0,'',0,'','info',NULL,NULL,0),
(131,1785746881,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(132,1785746902,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"75\"}',1,0,'',0,'','info',NULL,NULL,0),
(133,1785746910,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"76\"}',1,0,'',0,'','info',NULL,NULL,0),
(134,1785746910,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"77\"}',1,0,'',0,'','info',NULL,NULL,0),
(135,1785746910,2,2,2,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":2,\"history\":\"78\"}',1,0,'',0,'','info',NULL,NULL,0),
(136,1785746910,2,2,3,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":3,\"history\":\"79\"}',1,0,'',0,'','info',NULL,NULL,0),
(137,1785747276,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"80\"}',1,0,'',0,'','info',NULL,NULL,0),
(138,1785747294,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"81\"}',1,0,'',0,'','info',NULL,NULL,0),
(139,1785747529,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(140,1785747720,2,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(141,1785747723,2,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"83\"}',1,0,'',0,'','info',NULL,NULL,0),
(142,1785747726,2,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"84\"}',1,0,'',0,'','info',NULL,NULL,0),
(143,1785747994,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(144,1785748012,2,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"pid\":9}',9,0,'',0,'','info',NULL,NULL,0),
(145,1785748080,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(146,1785748214,2,4,7,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(147,1785748214,2,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"87\"}',1,0,'',0,'','info',NULL,NULL,0),
(148,1785748229,2,4,7,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(149,1785748737,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"89\"}',1,0,'',0,'','info',NULL,NULL,0),
(150,1785748980,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"90\"}',1,0,'',0,'','info',NULL,NULL,0),
(151,1785748987,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"91\"}',1,0,'',0,'','info',NULL,NULL,0),
(152,1785749306,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"92\"}',1,0,'',0,'','info',NULL,NULL,0),
(153,1785749855,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"93\"}',1,0,'',0,'','info',NULL,NULL,0),
(154,1785750024,2,2,2,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":2,\"history\":\"94\"}',1,0,'',0,'','info',NULL,NULL,0),
(155,1785750024,2,2,3,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":3,\"history\":\"95\"}',1,0,'',0,'','info',NULL,NULL,0),
(156,1785750055,2,2,2,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":2,\"history\":\"96\"}',1,0,'',0,'','info',NULL,NULL,0),
(157,1785750097,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(158,1785750302,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"97\"}',1,0,'',0,'','info',NULL,NULL,0),
(159,1785750305,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(160,1785750608,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(161,1785759538,2,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"98\"}',1,0,'',0,'','info',NULL,NULL,0),
(162,1785760186,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"lueg\"]',-1,0,'',0,'','info',NULL,NULL,0),
(163,1785760329,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(164,1785767702,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','172.18.0.5','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL,0),
(165,1785769132,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(166,1785769142,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(167,1785769143,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(168,1785769143,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(169,1785769185,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(170,1785769185,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(171,1785769192,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(172,1785769272,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(173,1785769272,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Serialization of \'Closure\' is not allowed | Exception thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/ContentObject/UserInternalContentObject.php in line 37. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(174,1785769293,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(175,1785769294,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(176,1785769371,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1273753083: Cannot cast object of type \"TYPO3\\CMS\\ContentBlocks\\DataProcessing\\ContentBlockData\" to string. | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/SyntaxTree/AbstractNode.php in line 69. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(177,1785769382,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Object of class TYPO3\\CMS\\ContentBlocks\\DataProcessing\\ContentBlockData could not be converted to string | Error thrown in file /var/www/html/var/cache/code/fluid_template/Default_action_Default_4e500cb5a1983043.php in line 240. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(178,1785769382,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Object of class TYPO3\\CMS\\ContentBlocks\\DataProcessing\\ContentBlockData could not be converted to string | Error thrown in file /var/www/html/var/cache/code/fluid_template/Default_action_Default_4e500cb5a1983043.php in line 240. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(179,1785769382,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Object of class TYPO3\\CMS\\ContentBlocks\\DataProcessing\\ContentBlockData could not be converted to string | Error thrown in file /var/www/html/var/cache/code/fluid_template/Default_action_Default_4e500cb5a1983043.php in line 240. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(180,1785769500,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(181,1785769500,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(182,1785769545,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(183,1785769546,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(184,1785769550,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(185,1785769553,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(186,1785769553,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(187,1785769561,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(188,1785769581,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(189,1785769582,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: TYPO3\\CMS\\Extbase\\Persistence\\Generic\\PersistenceManager::getObjectByIdentifier(): Argument #1 ($identifier) must be of type string|int, array given, called in /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Repository.php on line 185 | TypeError thrown in file /var/www/html/vendor/typo3/cms-extbase/Classes/Persistence/Generic/PersistenceManager.php in line 105. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(190,1785769674,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(191,1785769674,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(192,1785769730,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(193,1785769737,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(194,1785769752,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(195,1785769760,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(196,1785769766,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(197,1785769958,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(198,1785769964,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(199,1785769965,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(200,1785770036,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(201,1785770060,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(202,1785770060,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(203,1785770107,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(204,1785770107,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(205,1785770240,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(206,1785770254,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(207,1785770254,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(208,1785770254,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(209,1785770254,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(210,1785770255,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(211,1785770260,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(212,1785770300,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(213,1785770334,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(214,1785770379,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"lueg\"]',-1,0,'',0,'','info',NULL,NULL,0),
(215,1785770380,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(216,1785770381,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(217,1785770384,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(218,1785770385,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(219,1785770405,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"lueg\"]',-1,0,'',0,'','info',NULL,NULL,0),
(220,1785770409,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(221,1785770410,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(222,1785770432,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"lueg\"]',-1,0,'',0,'','info',NULL,NULL,0),
(223,1785770433,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(224,1785770443,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(225,1785770485,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(226,1785770485,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(227,1785770485,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(228,1785770485,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(229,1785770485,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(230,1785771174,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(231,1785771182,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(232,1785771340,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(233,1785771345,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(234,1785771368,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(235,1785771368,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(236,1785771416,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(237,1785771514,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(238,1785771738,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(239,1785771753,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(240,1785825852,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(241,1785844270,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(242,1785844289,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(243,1785844592,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(244,1785844592,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(245,1785844618,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(246,1785844623,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(247,1785844634,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','172.18.0.5','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL,0),
(248,1785844637,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(249,1785844638,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(250,1785844718,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(251,1785844718,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(252,1785844719,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(253,1785844719,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(254,1785844719,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(255,1785844719,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(256,1785844720,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(257,1785846624,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(258,1785846710,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(259,1785846713,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(260,1785846737,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(261,1785846837,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(262,1785846946,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(263,1785846947,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(264,1785846948,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(265,1785846961,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(266,1785846997,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(267,1785847008,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(268,1785847009,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(269,1785847064,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":\"99\"}',7,0,'',0,'','info',NULL,NULL,0),
(270,1785847064,2,2,1,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":1,\"history\":\"100\"}',7,0,'',0,'','info',NULL,NULL,0),
(271,1785847064,2,2,2,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":2,\"history\":\"101\"}',7,0,'',0,'','info',NULL,NULL,0),
(272,1785847064,2,2,3,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":3,\"history\":\"102\"}',7,0,'',0,'','info',NULL,NULL,0),
(273,1785847064,2,2,4,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":4,\"history\":\"103\"}',7,0,'',0,'','info',NULL,NULL,0),
(274,1785847064,2,2,5,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":5,\"history\":\"104\"}',7,0,'',0,'','info',NULL,NULL,0),
(275,1785847064,2,2,6,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":6,\"history\":\"105\"}',7,0,'',0,'','info',NULL,NULL,0),
(276,1785847064,2,2,7,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":7,\"history\":\"106\"}',7,0,'',0,'','info',NULL,NULL,0),
(277,1785847065,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(278,1785847066,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(279,1785847069,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(280,1785847079,2,2,1,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":1,\"history\":\"107\"}',7,0,'',0,'','info',NULL,NULL,0),
(281,1785847080,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(282,1785847099,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(283,1785847125,2,4,11,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(284,1785847125,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"109\"}',1,0,'',0,'','info',NULL,NULL,0),
(285,1785847126,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(286,1785847136,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(287,1785847146,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"110\"}',1,0,'',0,'','info',NULL,NULL,0),
(288,1785847146,2,2,1,'lueg_bewerben_steps',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_bewerben_steps\",\"uid\":1,\"history\":\"111\"}',1,0,'',0,'','info',NULL,NULL,0),
(289,1785847146,2,2,2,'lueg_bewerben_steps',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_bewerben_steps\",\"uid\":2,\"history\":\"112\"}',1,0,'',0,'','info',NULL,NULL,0),
(290,1785847146,2,2,3,'lueg_bewerben_steps',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_bewerben_steps\",\"uid\":3,\"history\":\"113\"}',1,0,'',0,'','info',NULL,NULL,0),
(291,1785847146,2,2,4,'lueg_bewerben_steps',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_bewerben_steps\",\"uid\":4,\"history\":\"114\"}',1,0,'',0,'','info',NULL,NULL,0),
(292,1785847147,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(293,1785847166,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(294,1785847317,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(295,1785847422,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(296,1785847423,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(297,1785847436,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(298,1785847514,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(299,1785847514,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(300,1785847517,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(301,1785847519,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(302,1785847520,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(303,1785847550,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(304,1785847555,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(305,1785847560,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(306,1785847583,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(307,1785847593,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(308,1785847612,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(309,1785847616,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(310,1785847668,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(311,1785847692,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(312,1785847703,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(313,1785847704,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(314,1785847731,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(315,1785847732,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(316,1785847754,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(317,1785847755,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(318,1785847756,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(319,1785847774,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(320,1785847800,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(321,1785847801,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(322,1785847806,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(323,1785847809,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(324,1785847822,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(325,1785847829,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(326,1785847853,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(327,1785847854,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(328,1785847940,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(329,1785847956,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(330,1785847956,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(331,1785847958,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(332,1785847960,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(333,1785847966,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(334,1785847974,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(335,1785847993,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(336,1785848000,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(337,1785848054,2,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(338,1785848056,2,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"116\"}',1,0,'',0,'','info',NULL,NULL,0),
(339,1785848059,2,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"117\"}',1,0,'',0,'','info',NULL,NULL,0),
(340,1785848078,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(341,1785848125,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(342,1785848492,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(343,1785848494,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(344,1785848537,2,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"118\"}',1,0,'',0,'','info',NULL,NULL,0),
(345,1785848549,2,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"119\"}',1,0,'',0,'','info',NULL,NULL,0),
(346,1785849330,2,1,12,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"pid\":10}',10,0,'',0,'','info',NULL,NULL,0),
(347,1785849352,2,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":\"121\"}',10,0,'',0,'','info',NULL,NULL,0),
(348,1785849408,2,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":\"122\"}',10,0,'',0,'','info',NULL,NULL,0),
(349,1785849674,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(350,1785849697,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(351,1785849710,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(352,1785849722,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(353,1785849727,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(354,1785849761,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(355,1785849765,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(356,1785849768,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(357,1785849769,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(358,1785849802,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(359,1785849803,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(360,1785849805,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(361,1785849811,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(362,1785849819,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(363,1785849824,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(364,1785849829,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(365,1785849830,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(366,1785849874,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(367,1785849906,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(368,1785849907,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(369,1785849910,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(370,1785849911,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(371,1785849935,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(372,1785849936,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(373,1785849940,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(374,1785850048,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(375,1785850150,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(376,1785850156,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(377,1785850158,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(378,1785850308,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(379,1785850312,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(380,1785850314,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(381,1785850647,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(382,1785850678,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(383,1785850692,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(384,1785850693,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(385,1785850706,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(386,1785850714,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(387,1785850738,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(388,1785850740,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(389,1785850779,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(390,1785850780,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(391,1785850791,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(392,1785850791,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(393,1785850799,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(394,1785850802,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(395,1785850912,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(396,1785850950,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(397,1785850963,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(398,1785850968,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(399,1785850977,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(400,1785851129,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(401,1785851129,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(402,1785851229,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(403,1785851229,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(404,1785851245,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(405,1785851245,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(406,1785851905,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(407,1785851907,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(408,1785851954,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(409,1785851955,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(410,1785851957,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(411,1785851982,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(412,1785852029,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(413,1785852034,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(414,1785852036,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(415,1785852127,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(416,1785852171,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(417,1785852216,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(418,1785852284,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(419,1785852345,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(420,1785852396,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(421,1785852421,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(422,1785852427,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(423,1785852483,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(424,1785852553,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(425,1785852559,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(426,1785852567,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(427,1785852588,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(428,1785852632,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(429,1785852711,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(430,1785852714,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(431,1785852918,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(432,1785852963,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(433,1785852968,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(434,1785852969,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(435,1785853004,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(436,1785853026,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(437,1785853059,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(438,1785853060,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(439,1785853116,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(440,1785853116,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(441,1785853130,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(442,1785853131,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(443,1785853132,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(444,1785853144,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(445,1785853147,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(446,1785853148,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(447,1785853165,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(448,1785853183,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(449,1785853218,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(450,1785853223,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(451,1785853224,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(452,1785853226,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(453,1785853238,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(454,1785853249,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(455,1785853253,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(456,1785853274,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(457,1785853275,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(458,1785853285,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(459,1785853286,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(460,1785853295,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(461,1785853327,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(462,1785853335,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(463,1785853453,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(464,1785853462,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(465,1785853536,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(466,1785853563,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(467,1785853604,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(468,1785853608,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(469,1785853778,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(470,1785853781,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(471,1785858204,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(472,1785858213,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(473,1785858358,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(474,1785858368,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(475,1785858397,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(476,1785911271,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(477,1785911422,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','172.18.0.5','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL,0),
(478,1785911435,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"123\"}',1,0,'',0,'','info',NULL,NULL,0),
(479,1785911440,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"124\"}',1,0,'',0,'','info',NULL,NULL,0),
(480,1785911456,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"125\"}',1,0,'',0,'','info',NULL,NULL,0),
(481,1785911459,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(482,1785911460,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(483,1785911463,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(484,1785911464,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(485,1785911468,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(486,1785911476,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(487,1785911478,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(488,1785911530,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"126\"}',1,0,'',0,'','info',NULL,NULL,0),
(489,1785911536,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"127\"}',1,0,'',0,'','info',NULL,NULL,0),
(490,1785911662,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(491,1785911683,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"128\"}',0,0,'',0,'','info',NULL,NULL,0),
(492,1785911683,2,2,3,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"history\":\"129\"}',0,0,'',0,'','info',NULL,NULL,0),
(493,1785911698,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"130\"}',1,0,'',0,'','info',NULL,NULL,0),
(494,1785911698,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"131\"}',1,0,'',0,'','info',NULL,NULL,0),
(495,1785911698,2,2,2,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":2,\"history\":\"132\"}',1,0,'',0,'','info',NULL,NULL,0),
(496,1785911698,2,2,3,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":3,\"history\":\"133\"}',1,0,'',0,'','info',NULL,NULL,0),
(497,1785911699,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(498,1785911703,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(499,1785911704,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(500,1785911726,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(501,1785911747,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(502,1785911807,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(503,1785911847,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(504,1785911923,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(505,1785911951,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(506,1785911975,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(507,1785911976,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(508,1785911981,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(509,1785911982,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(510,1785912001,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(511,1785912001,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(512,1785912009,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(513,1785912010,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(514,1785912052,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(515,1785912052,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(516,1785912061,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(517,1785912091,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(518,1785912092,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(519,1785912096,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(520,1785912098,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(521,1785912099,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(522,1785912101,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(523,1785912112,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(524,1785912113,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(525,1785912113,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(526,1785912113,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(527,1785912113,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(528,1785912113,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(529,1785912114,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(530,1785912141,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(531,1785912178,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(532,1785912178,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(533,1785912191,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(534,1785912192,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1478806566: MenuProcessor Configuration contains invalid Arguments: sectionIndex. | InvalidArgumentException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/DataProcessing/MenuProcessor.php in line 291. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(535,1785912236,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(536,1785912237,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(537,1785912239,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(538,1785912274,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(539,1785912292,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(540,1785912322,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(541,1785912325,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(542,1785912444,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(543,1785912467,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(544,1785912505,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(545,1785912513,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(546,1785912722,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(547,1785912726,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(548,1785912733,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(549,1785912899,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(550,1785912903,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(551,1785912904,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template partial_Header_4c76f44d14a664c5, line 83 at character 22. Error: The ViewHelper \"<f:debu>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\DebuViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <f:debu> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 131. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL,0),
(552,1785912912,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(553,1785912947,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(554,1785912948,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(555,1785912952,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(556,1785912953,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(557,1785913022,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(558,1785913034,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(559,1785913177,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(560,1785913178,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(561,1785913183,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(562,1785913187,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(563,1785913188,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(564,1785913205,2,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"134\"}',1,0,'',0,'','info',NULL,NULL,0),
(565,1785913211,2,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"history\":\"135\"}',1,0,'',0,'','info',NULL,NULL,0),
(566,1785913218,2,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"136\"}',1,0,'',0,'','info',NULL,NULL,0),
(567,1785913219,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(568,1785913220,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(569,1785913281,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(570,1785913510,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(571,1785913515,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(572,1785913542,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(573,1785913544,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(574,1785913563,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(575,1785913564,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(576,1785913568,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(577,1785913575,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(578,1785913582,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(579,1785913596,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"137\"}',1,0,'',0,'','info',NULL,NULL,0),
(580,1785913598,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(581,1785913655,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(582,1785913811,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(583,1785913831,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(584,1785913840,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(585,1785913842,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(586,1785913861,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(587,1785913882,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(588,1785913890,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(589,1785913900,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(590,1785913907,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(591,1785913910,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(592,1785913910,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(593,1785913918,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(594,1785913977,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(595,1785914052,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(596,1785914053,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(597,1785914060,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(598,1785914097,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(599,1785914100,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(600,1785914109,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(601,1785914110,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(602,1785914111,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(603,1785914118,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(604,1785914119,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(605,1785914132,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(606,1785914136,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(607,1785914137,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(608,1785914151,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(609,1785914200,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(610,1785914212,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(611,1785914224,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(612,1785914240,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(613,1785914256,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(614,1785914308,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(615,1785914335,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(616,1785914347,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(617,1785914376,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(618,1785914376,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(619,1785914377,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(620,1785914379,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(621,1785914399,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(622,1785914419,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(623,1785914421,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(624,1785914429,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"138\"}',1,0,'',0,'','info',NULL,NULL,0),
(625,1785914431,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(626,1785914432,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(627,1785914466,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(628,1785914467,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(629,1785914470,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(630,1785914471,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(631,1785914856,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(632,1785914918,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(633,1785914928,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(634,1785914970,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(635,1785914971,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(636,1785915000,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(637,1785915050,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(638,1785915080,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(639,1785915081,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(640,1785915095,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(641,1785915097,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(642,1785915112,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(643,1785915287,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(644,1785915294,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"139\"}',1,0,'',0,'','info',NULL,NULL,0),
(645,1785915369,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(646,1785915374,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(647,1785915381,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(648,1785915398,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(649,1785915415,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(650,1785915415,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(651,1785915571,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(652,1785915577,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(653,1785915584,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(654,1785915589,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(655,1785915688,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(656,1785915703,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(657,1785915818,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(658,1785915880,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(659,1785915936,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(660,1785916008,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(661,1785916025,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(662,1785916028,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(663,1785916032,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(664,1785916034,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(665,1785916036,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(666,1785916056,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(667,1785916070,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(668,1785916118,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(669,1785916145,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(670,1785916185,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(671,1785916223,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(672,1785916230,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(673,1785916332,2,1,11,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":11,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(674,1785916334,2,2,11,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":11,\"history\":\"141\"}',1,0,'',0,'','info',NULL,NULL,0),
(675,1785916473,2,1,12,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"pid\":1}',1,0,'',0,'','info',NULL,NULL,0),
(676,1785916476,2,1,13,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"pid\":11}',11,0,'',0,'','info',NULL,NULL,0),
(677,1785916485,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"144\"}',11,0,'',0,'','info',NULL,NULL,0),
(678,1785916489,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":\"145\"}',1,0,'',0,'','info',NULL,NULL,0),
(679,1785916492,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":\"146\"}',1,0,'',0,'','info',NULL,NULL,0),
(680,1785916500,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":\"147\"}',1,0,'',0,'','info',NULL,NULL,0),
(681,1785916515,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(682,1785916515,2,1,29,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":29,\"pid\":12}',12,0,'',0,'','info',NULL,NULL,0),
(683,1785916515,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(684,1785916517,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(685,1785916628,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"danke.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL,0),
(686,1785916632,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(687,1785916632,2,1,30,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":30,\"pid\":12}',12,0,'',0,'','info',NULL,NULL,0),
(688,1785916632,2,2,12,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":12,\"history\":0}',1,0,'',0,'','info',NULL,NULL,0),
(689,1785916632,2,3,29,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":29,\"pid\":12}',12,0,'',0,'','info',NULL,NULL,0),
(690,1785916848,2,1,14,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":14,\"pid\":12}',12,0,'',0,'','info',NULL,NULL,0),
(691,1785916912,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(692,1785917009,2,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(693,1785917011,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(694,1785917011,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(695,1785917019,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(696,1785917028,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(697,1785917028,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(698,1785917039,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(699,1785917054,0,0,0,'',0,2,'Core: Error handler (FE): PHP Warning: Undefined array key \"confirmation\" in /var/www/html/vendor/in2code/powermail/Classes/Controller/FormController.php line 112',5,'php','172.18.0.5','',-1,0,'',0,'','warning',NULL,NULL,0),
(700,1785917195,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(701,1785917229,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"152\"}',11,0,'',0,'','info',NULL,NULL,0),
(702,1785917231,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0),
(703,1785917276,2,2,14,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":14,\"history\":\"153\"}',12,0,'',0,'','info',NULL,NULL,0),
(704,1785917440,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL,0);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('0157c3fc784638c036e41226d1f21682','sys_file',29,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('032c9455240737904f045d3fb40ed1d2','sys_file',16,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('04019e35ed81914c89a8d6cbf97c60d2','sys_file_reference',30,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',34,'',0,0,2147483647,0,0,''),
('06ca32ac6eb0e64f5da705b5c35de5b7','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('07a8cafecf0b85c1a89c84ab57172544','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('10e7ac050b17195f9b3dca4e5adddad0','lueg_benefits_tiles',5,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('11932135c4507b44379379cdc397b2d5','tt_content',11,'lueg_bewerben_steps',0,0,2147483647,0,'','','',3,0,'lueg_bewerben_steps',4,'',0,0,2147483647,0,0,''),
('12436f0c9c5f822e95d1eac7447dbe47','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',1,0,'lueg_stellen_stellen',2,'',0,0,2147483647,0,0,''),
('12e4fdcaf3efaca0fcd28e564fd17690','tt_content',11,'lueg_bewerben_steps',0,0,2147483647,0,'','','',2,0,'lueg_bewerben_steps',3,'',0,0,2147483647,0,0,''),
('13e3f775f5fe55e34e6c3053fc81a294','sys_file',7,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',7,'',0,0,2147483647,0,0,''),
('1891e5b68039b20ea9ed0acf765648c4','sys_file',11,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('1bb57bc64cd75b6fc74edc570c5bf546','tx_powermail_domain_model_field',3,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('1c382bc93ac30b52eaf2ada5cc3ded1c','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',2,0,'lueg_benefits_tiles',3,'',0,0,2147483647,0,0,''),
('1cb75ad318b7c7770181c1361640dbee','tx_powermail_domain_model_field',6,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('1debe5f1ff14e3f1360d692113b41c1f','tt_content',2,'lueg_podcasts_episodes',0,0,2147483647,0,'','','',1,0,'lueg_podcasts_episodes',2,'',0,0,2147483647,0,0,''),
('21258650f973214ea36749d6f1e0e877','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_field',1,'',0,0,2147483647,0,0,''),
('21f973e8229670917d408e565c8c47c4','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('27b62ed56b876e5330b7b7d9eb55d72e','tt_content',5,'lueg_standorte_pin2_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',26,'',0,0,2147483647,0,0,''),
('2906231fdf5b506019bbc975da352cd3','tt_content',5,'lueg_standorte_pin4_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',28,'',0,0,2147483647,0,0,''),
('2932310b34b3604c71486e46f971e5e5','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',8,0,'lueg_benefits_tiles',9,'',0,0,2147483647,0,0,''),
('2e7772355450c1ca9600404b666a9f15','lueg_benefits_tiles',6,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',15,'',0,0,2147483647,0,0,''),
('31bcb916b23fca2191523336f3f8977b','lueg_benefits_tiles',1,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('340158331ec1edb4e312004cd6cd39be','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',3,0,'tx_powermail_domain_model_field',4,'',0,0,2147483647,0,0,''),
('34a346792c831418b0b2e95e4674867f','lueg_podcasts_episodes',2,'poster',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('36b055717ab3f8aa05172875ff149573','tt_content',12,'bodytext',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@spitexlueg.ch'),
('3ddbc4e8e65a096e119ea8ff8eb7f306','tx_powermail_domain_model_field',7,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('40775fbce9041f679e900ea104a92037','tt_content',11,'lueg_bewerben_steps',0,0,2147483647,0,'','','',0,0,'lueg_bewerben_steps',1,'',0,0,2147483647,0,0,''),
('41170785eb716bc6bf2dfd49e8b7880d','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',4,0,'lueg_benefits_tiles',5,'',0,0,2147483647,0,0,''),
('43c11b7c2d075b45c65be6b7b0d1a017','sys_file',23,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('48c9b53b5c4f85e504ab82e6fde40c97','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',4,0,'lueg_stellen_stellen',5,'',0,0,2147483647,0,0,''),
('49a1dca9b44dbc2f1878bcbdb69eaa56','sys_file',20,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',20,'',0,0,2147483647,0,0,''),
('531f57caee814017df3806a1886a5753','lueg_benefits_tiles',9,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('56336f58f29686eb54502ae7cf4e3728','sys_file',32,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('584487dceb88c30c8f4fdcef5662f571','lueg_benefits_tiles',4,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('59c7319c41b3f5fd154aab420e38af03','sys_file',15,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('5c5c708d6f72da78f5f0240ceccdb4d0','tx_powermail_domain_model_field',4,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('5eabf5fd76d603ac826d76f818a28377','tt_content',7,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('63394b2fc893d034b736bc059fc3097b','sys_file_reference',27,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('64f91d9385c66159e0535b5b94f95d8f','sys_file',25,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('656b2851ee7dddc375e1caf43969289a','sys_file',26,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('69982b2a98cbef53cc80295c48be6116','sys_file',17,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6a94b41f5ae34b7bae0ec9070182ed92','sys_file',13,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6ad2b796fd0cbcb166cca5093b699511','tx_powermail_domain_model_field',5,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('6bbb48189e40223a6f1b944a8c1e11a5','lueg_benefits_tiles',8,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',17,'',0,0,2147483647,0,0,''),
('6d5676d7f8a33ff4628e1a1b62a73130','tt_content',12,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@spitexlueg.ch'),
('70309932df13074e9719fed1f2f5a380','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',0,0,'lueg_benefits_tiles',1,'',0,0,2147483647,0,0,''),
('7281f532412e4dbd9963d2e9fa6af96d','tt_content',13,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.flexform.main.form/vDEF/','','',0,0,'tx_powermail_domain_model_form',1,'',0,0,2147483647,0,0,''),
('731a3e934d4284dc1337694ff2a2e91a','sys_file',22,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('74f89f508a8d8465607d030c6629dc92','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('75e554675bdff6fb7eb7fac50561d72d','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',3,0,'lueg_stellen_stellen',4,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('7ddeabd5bec17a9da953ae45845d3a2c','tt_content',5,'lueg_standorte_pin1_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',24,'',0,0,2147483647,0,0,''),
('7fa40541aaf322ad3877e351b6d4541d','lueg_benefits_tiles',10,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('80ffd427efd1ab09fe204d5356a348e3','sys_file',31,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('810777333f9c8ac6fb2e4554afe693a5','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',2,0,'lueg_stellen_stellen',3,'',0,0,2147483647,0,0,''),
('825aada1766f403b76e9adc3ff3908d2','tx_powermail_domain_model_field',1,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('85ce5f98e1d11d3a63413f8c25da17d8','sys_file',19,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('88c80057eb453b13de190fd8ad9a7f5d','sys_file',28,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('8c35623f6d2e812f184755b0e9da5f00','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',9,0,'lueg_benefits_tiles',10,'',0,0,2147483647,0,0,''),
('8d20646af662092f2ec1cf930987beb0','tx_powermail_domain_model_page',1,'form',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_form',1,'',0,0,2147483647,0,0,''),
('911e3ac73be2b6eda62728c9565cce71','tt_content',9,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'privacy@impunix.ch'),
('94ae29634a690fa96fe9fbcec4aa56f5','lueg_benefits_tiles',7,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('9582bb2310aa3295376e517d36d54791','tt_content',5,'lueg_standorte_pin3_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',27,'',0,0,2147483647,0,0,''),
('9752b282c0d432837f1bbed545654b32','lueg_podcasts_episodes',2,'mediafile',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('9c892dd54a2813a95c126ed46c1af1e7','sys_file',30,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('9f4f80f7417765a1fd405687474b2680','sys_file',18,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a21506ca9162f75c863170914a766564','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a71d156cbbc1fd0aea0e6f9e84024815','sys_file',14,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a7f01a3638670898c734e94169bb1838','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',7,0,'lueg_benefits_tiles',8,'',0,0,2147483647,0,0,''),
('a8ae560441da233771408a7e6b28c1b6','sys_file',20,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a8b4e24168e192fb3cc844f511bb2601','lueg_podcasts_episodes',1,'poster',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('aac3dd048e1283643c1695f07b1d20bb','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',4,0,'tx_powermail_domain_model_field',5,'',0,0,2147483647,0,0,''),
('ac116c952c32a114f34e17c7575c96e6','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',2,0,'tx_powermail_domain_model_field',3,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b52b3687ca0340b281d2f547cd5d35ea','sys_file_reference',28,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('b6960786bb0bcb010511a6440c1c4d90','sys_file',34,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ba40b368f96510ff2ffaec95e134ea75','lueg_benefits_tiles',2,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('bd871a48b5b62b0393e1bbfcd4306088','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',1,0,'lueg_benefits_tiles',2,'',0,0,2147483647,0,0,''),
('bdee36aee3aecbf9eb6a414e9ff6dafa','lueg_benefits_tiles',3,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('beb20200ef38ef9fe2c95d9cf78c942d','tt_content',11,'lueg_bewerben_steps',0,0,2147483647,0,'','','',1,0,'lueg_bewerben_steps',2,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('bef4c06bde2f3af98649fb668f472127','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',5,0,'lueg_benefits_tiles',6,'',0,0,2147483647,0,0,''),
('c2f9b2aa0e2662b2247f3cef3f69e9f3','tt_content',3,'lueg_ausbildung_items',0,0,2147483647,0,'','','',2,0,'lueg_ausbildung_items',3,'',0,0,2147483647,0,0,''),
('c47a797b1e46b346553bd44455bbef56','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',1,0,'tx_powermail_domain_model_field',2,'',0,0,2147483647,0,0,''),
('cc38ad8c255193f5cbeb15f85896b92e','tt_content',2,'lueg_podcasts_episodes',0,0,2147483647,0,'','','',0,0,'lueg_podcasts_episodes',1,'',0,0,2147483647,0,0,''),
('ccc76f735cb38dca39df162b0b627353','sys_file',12,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('cdc09a87669fbd6a56d55e751bb0d5cd','tt_content',13,'pi_flexform',0,0,2147483647,0,'thx/lDEF/settings.flexform.thx.redirect/vDEF/','typolink','811bfec1a4cc88f06650678f235151dd:0',0,0,'pages',12,'',0,0,2147483647,0,0,''),
('ce5d84aa39bed2c184ece9ab314fecc2','tx_powermail_domain_model_field',2,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('d0c4ea4dc1e362ca1743f431231528f9','pages',12,'media',0,0,2147483647,0,'','','',0,0,'sys_file_reference',30,'',0,0,2147483647,0,0,''),
('d13168be0bea9b8c9787d6ab86e5f654','tt_content',3,'lueg_ausbildung_items',0,0,2147483647,0,'','','',0,0,'lueg_ausbildung_items',1,'',0,0,2147483647,0,0,''),
('d67db873aebd3c6e2630c34cfa1a7f9a','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',0,0,'lueg_stellen_stellen',1,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('dab1afc2e3d19ecaa9f15b9368559a6b','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',3,0,'lueg_benefits_tiles',4,'',0,0,2147483647,0,0,''),
('db2015faae619ad98a32fd8044806f55','sys_file_reference',26,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('ddb0486620e0393165318a07cbbc4b8e','sys_file',21,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('e4af88b058a534b7664d8b65f3c075cc','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',6,0,'lueg_benefits_tiles',7,'',0,0,2147483647,0,0,''),
('e660a0426c3c9494add60c131e202199','sys_file',27,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('e929cbf4625a7dfcc8697279c8a382b7','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',5,0,'tx_powermail_domain_model_field',6,'',0,0,2147483647,0,0,''),
('e94a2ecd669824a1cb80959e7df9156d','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('eaa9218683f19d5bd2aff3f3bac7ebb3','tt_content',3,'lueg_ausbildung_items',0,0,2147483647,0,'','','',1,0,'lueg_ausbildung_items',2,'',0,0,2147483647,0,0,''),
('ecde69f475d893e4a7856a10e71c42b8','pages',1,'media',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('ef3229912bd844b089cd84d0b6e56d11','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',6,0,'tx_powermail_domain_model_field',7,'',0,0,2147483647,0,0,''),
('f0d49e18db70a622c6f1679c438f280b','sys_file_reference',24,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('f314d7d7160398937ff84f7b9d34bba8','sys_file',24,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f6062209d87aa82eace335f4ab0c7610','sys_file',10,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f878cf5ef918189e175dcf8358956cda','lueg_podcasts_episodes',1,'mediafile',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('fdf315ac4bfd5801907f3764383038da','tt_content',12,'bodytext',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+41344605000');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Scheduler\\Migration\\SchedulerDatabaseStorageMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','scheduler:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','lowlevel:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','site_package:ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','lueg/project:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','typo3/app:ext_tables_static+adt.sql','s:0:\"\";'),
(42,'core','formProtectionSessionToken:2','s:64:\"26bea2265ccdf5b3dc2520c101e0710673600b44c37dcf41ccc9a0ca4fd43ab0\";'),
(43,'extensionDataImport','content_blocks:ext_tables_static+adt.sql','s:0:\"\";'),
(44,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";'),
(45,'extensionDataImport','typo3/cms-core/ext_tables_static+adt.sql','s:0:\"\";'),
(46,'extensionDataImport','typo3/cms-scheduler/ext_tables_static+adt.sql','s:0:\"\";'),
(47,'extensionDataImport','typo3/cms-extbase/ext_tables_static+adt.sql','s:0:\"\";'),
(48,'extensionDataImport','typo3/cms-fluid/ext_tables_static+adt.sql','s:0:\"\";'),
(49,'extensionDataImport','typo3/cms-install/ext_tables_static+adt.sql','s:0:\"\";'),
(50,'extensionDataImport','typo3/cms-backend/ext_tables_static+adt.sql','s:0:\"\";'),
(51,'extensionDataImport','typo3/cms-frontend/ext_tables_static+adt.sql','s:0:\"\";'),
(52,'extensionDataImport','typo3/cms-dashboard/ext_tables_static+adt.sql','s:0:\"\";'),
(53,'extensionDataImport','typo3/cms-filelist/ext_tables_static+adt.sql','s:0:\"\";'),
(54,'extensionDataImport','typo3/cms-impexp/ext_tables_static+adt.sql','s:0:\"\";'),
(55,'extensionDataImport','typo3/cms-lowlevel/ext_tables_static+adt.sql','s:0:\"\";'),
(56,'extensionDataImport','typo3/cms-form/ext_tables_static+adt.sql','s:0:\"\";'),
(57,'extensionDataImport','typo3/cms-fluid-styled-content/ext_tables_static+adt.sql','s:0:\"\";'),
(58,'extensionDataImport','typo3/cms-seo/ext_tables_static+adt.sql','s:0:\"\";'),
(59,'extensionDataImport','typo3/cms-reactions/ext_tables_static+adt.sql','s:0:\"\";'),
(60,'extensionDataImport','typo3/cms-recycler/ext_tables_static+adt.sql','s:0:\"\";'),
(61,'extensionDataImport','typo3/cms-setup/ext_tables_static+adt.sql','s:0:\"\";'),
(62,'extensionDataImport','typo3/cms-rte-ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),
(63,'extensionDataImport','typo3/cms-sys-note/ext_tables_static+adt.sql','s:0:\"\";'),
(64,'extensionDataImport','typo3/cms-webhooks/ext_tables_static+adt.sql','s:0:\"\";'),
(65,'extensionDataImport','typo3/cms-belog/ext_tables_static+adt.sql','s:0:\"\";'),
(66,'extensionDataImport','typo3/cms-beuser/ext_tables_static+adt.sql','s:0:\"\";'),
(67,'extensionDataImport','typo3/cms-felogin/ext_tables_static+adt.sql','s:0:\"\";'),
(68,'extensionDataImport','typo3/cms-info/ext_tables_static+adt.sql','s:0:\"\";'),
(69,'extensionDataImport','typo3/cms-tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),
(70,'extensionDataImport','typo3/cms-viewpage/ext_tables_static+adt.sql','s:0:\"\";'),
(71,'extensionDataImport','georgringer/news/ext_tables_static+adt.sql','s:0:\"\";'),
(72,'extensionDataImport','contentblocks/content-blocks/ext_tables_static+adt.sql','s:0:\"\";'),
(73,'extensionDataImport','lueg/site-package/ext_tables_static+adt.sql','s:0:\"\";'),
(74,'extensionDataImport','les_static+adt.sql','s:0:\"\";'),
(75,'extensionDataImport','in2code/powermail/ext_tables_static+adt.sql','s:0:\"\";'),
(76,'languagePacks','de-content_blocks','i:1785850732;'),
(77,'languagePacks','de-site_package','i:1785850732;'),
(78,'languagePacks','de','i:1785850732;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` varchar(36) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_podcasts_episodes` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_ausbildung_items` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_benefits_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin1_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin1_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin1_address` longtext DEFAULT NULL,
  `lueg_standorte_pin1_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin2_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin2_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin2_address` longtext DEFAULT NULL,
  `lueg_standorte_pin2_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin3_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin3_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin3_address` longtext DEFAULT NULL,
  `lueg_standorte_pin3_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin4_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin4_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin4_address` longtext DEFAULT NULL,
  `lueg_standorte_pin4_link` text NOT NULL DEFAULT '',
  `lueg_stellen_stellen` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `lueg_bewerben_steps_heading` varchar(255) NOT NULL DEFAULT '',
  `lueg_bewerben_steps` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_bewerben_form` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1785502132,1785493511,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_headline_text',0,0,'','',0,'Lueg – dini Zuekunft, bir Spitex Region Lueg',0,'','','','<p><strong>Wir suchen ausgebildete Fachkräfte, Quereinsteiger:innen und Lernende.</strong></p>\r\n<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll – genau das macht sie so wertvoll.</p>\r\n<p>Wir unterstützen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und eröffnen ihnen die Möglichkeit, Verantwortung zu übernehmen, beispielsweise in Spezialfunktionen.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(2,1,1785498371,1785497882,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_podcasts_episodes\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_podcasts',0,0,'','',0,'Lueg – u los ine',0,'','','','<p>In dieser Podcast-Serie erzählen unsere Mitarbeitenden aus ihrem Alltag in der ambulanten Pflege – ehrlich, persönlich und mit Geschichten, die zeigen, warum genau du hier richtig bist.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(3,1,1785911698,1785502894,0,0,0,0,'',768,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_ausbildung_items\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_ausbildung',0,0,'','',0,'Lueg – <br>mir biude Lernendi us',0,'','','','<p>Die Arbeit mit Menschen gibt dir echten Sinn. Damit unsere Klientinnen und Klienten jederzeit top betreut sind, bildet die Spitex Region Lueg Fachfrauen und Fachmänner Gesundheit (FaGe) aus. Bei uns wirst du Schritt für Schritt begleitet – individuell, persönlich und immer auf deinem Weg.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,3,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(4,1,1785746902,1785503461,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_benefits_tiles\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_benefits',0,0,'','',0,'Lueg – <br>was mir dir biete',0,'','','','<p>Wir sind ein moderner, innovativer Arbeitgeber mit guter Infrastruktur, zeitgemässen Arbeitsmitteln und Offenheit für neue Methoden. Wir kommunizieren auf Augenhöhe und leben eine offene, wertschätzende Teamkultur.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,10,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(5,1,1785746680,1785507434,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_standorte_pin1_address\":\"\",\"lueg_standorte_pin1_image\":\"\",\"lueg_standorte_pin1_link\":\"\",\"lueg_standorte_pin1_title\":\"\",\"lueg_standorte_pin2_address\":\"\",\"lueg_standorte_pin2_image\":\"\",\"lueg_standorte_pin2_link\":\"\",\"lueg_standorte_pin2_title\":\"\",\"lueg_standorte_pin3_address\":\"\",\"lueg_standorte_pin3_image\":\"\",\"lueg_standorte_pin3_link\":\"\",\"lueg_standorte_pin3_title\":\"\",\"lueg_standorte_pin4_address\":\"\",\"lueg_standorte_pin4_image\":\"\",\"lueg_standorte_pin4_link\":\"\",\"lueg_standorte_pin4_title\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_standorte',0,0,'','',0,'Lueg – <br>wo mir si',0,'','','','<p>Das Einzugsgebiet der Spitex Region Lueg umfasst 11 Gemeinden mit insgesamt 23’000 Einwohnerinnen und Einwohnern. Dank vier Standorten ist die Organisation in der Mitte des Emmentals präsent und bestens mit den Bedürfnissen der Bevölkerung vertraut.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,1,'Standort Weier','Huttwilwestrasse 1\r\n3462 Weier i.E','https://www.google.com/maps?q=Huttwilwestrasse+1+3462+Weier',1,'Standort Sumiswald','Marktgasse 5\r\n3454 Sumiswald','https://www.google.com/maps?q=Marktgasse+5+3454+Sumiswald',1,'Standort Affoltern','Dorfstrasse 12\r\n3416 Affoltern i.E.','https://www.google.com/maps?q=Dorfstrasse+12+3416+Affoltern',1,'Standort Hasle','Bahnhofstrasse 3\r\n3415 Hasle b.B.','https://www.google.com/maps?q=Bahnhofstrasse+3+3415+Hasle',0,0,'','',0,0),
(6,1,1785746473,1785745312,1,0,0,0,'0',1290,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_stellen_stellen\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_stellen',0,0,'','',0,'Lueg – <br>üsi freie Jobs',0,'','','','<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll. Finde hier die Stelle, die zu dir passt.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',5,0,'','',0,0),
(7,1,1785759538,1785746473,0,0,0,0,'0',640,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'news_pi1',0,0,'','',0,'Lueg – <br>Üsi freie Jobs',100,'','','','<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll. Finde hier die Stelle, die zu dir passt.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(8,3,1785750947,1785746473,0,0,0,0,'0',10,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'news_newsdetail',0,0,'','',0,'Freie Stelle',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\"></language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(9,9,1785748012,1785748012,0,0,0,0,'0',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',0,'','','','<h2>1. Verantwortlicher im Sinne des schweizerischen Bundesgesetzes über den Datenschutz (DSG) für die hier beschriebenen Datenbearbeitungen ist:</h2>\r\n<p>SPITEX Region Lueg AG Rüegsaustrasse 8 3415 Hasle-Rüegsau</p>\r\n<p>Unser Datenschutzberater ist: impunix AG – Datenschutz Full-Service Lagerhausstrasse 18, CH-8400 Winterthur privacy@impunix.ch www.impunix.ch</p>\r\n<p>Bei Fragen oder Anliegen zum Datenschutz und zur Ausübung Ihrer Rechte wenden Sie sich bitte an diese Stelle.</p>\r\n<h2>2. Zweck der Bearbeitung im Rahmen unserer Dienstleistungen und Angebote</h2>\r\n<p>Wir beschaffen und bearbeiten die Personendaten, die wir im Rahmen unserer Geschäftstätigkeit insbesondere mit Klienten, Angehörige, Besuchern, Interessenten, Bewerbern, Geschäfts-partnern sowie weiteren beteiligten Personen erhalten oder die beim Betrieb unserer Website erhoben werden. Im letzten Kapitel ist eine Übersicht über die verwendeten Kategorien von Per-sonendaten. Sollten Sie uns Informationen über andere Personen übermitteln, vergewissern Sie sich bitte, dass diese Personen vorher informiert wurden und dass die angegebenen Daten korrekt sind. Die erhobenen Personendaten werden zur Erbringung unserer Dienstleistungen und Angebote verwendet. Dies umfasst insbesondere die Betreuung und Behandlung von Menschen aller Al-tersgruppen (ab 16. Jahren) mit vorübergehend reduzierten physischen und psychischen Kräf-ten, Menschen mit einer chronischen Erkrankung oder Einschränkung, Betagte und gebrechliche Menschen, zu Hause in der gewohnten Umgebung. Zudem können externe Dienstleister zur Erbringung dieser Leistungen eingesetzt werden. Weitere Informationen zu den Datenbearbei-tungen und deren Zwecken finden Sie in den folgenden Kapiteln.</p>\r\n<h3>2.1 Kontaktaufnahme und Kommunikation</h3>\r\n<p>Wir bearbeiten Ihre Daten zur Bearbeitung von Anfragen über das Kontaktformular, zur Bereit-stellung von Informationen über unsere Dienstleistungen sowie zur Vereinbarung von Terminen und Beratungen.</p>\r\n<h3>2.2 Klientenaufnahme (inkl. Anamnese)</h3>\r\n<p>Bei der Klientenaufnahme erheben und speichern wir Ihre Stammdaten sowie Ihre medizinische Vorgeschichte. Dies umfasst Informationen wie Name, Adresse, Geburtsdatum, Kontaktinfor-mationen und relevante Gesundheitsdaten. Diese Daten sind notwendig, um eine individuelle Behandlung planen zu können.</p>\r\n<h3>2.3 Klientenversorgung und medizinische Dienstleistungen</h3>\r\n<p>Wir bearbeiten Ihre Gesundheitsdaten, um diagnostische Untersuchungen und therapeutische Behandlungen durchzuführen. Dies beinhaltet die Nutzung medizinischer Technologien und Me-thoden. Ihre Daten werden für folgende Punkte genutzt:</p>\r\n<ul><li data-list-item-id=\"ec3ce18193255f5fde3ba54460d453b52\">Abklärung des Pflegebedarfs</li><li data-list-item-id=\"e0ad57aa9c0e13d9f23246c5e1995cf5c\">Beratung zu Angeboten</li><li data-list-item-id=\"e4bb93e37680c861b448047346e592126\">Hilfe bei der Körperpflege</li><li data-list-item-id=\"e12976d41ff5c4a54cfb440edf1045884\">Hilfe bei der Mobilisation (Aufstehen und zu Bett gehen)</li><li data-list-item-id=\"ef6b9fcaca1b8d5423af23702e1f94266\">Vorbereiten und Verabreichen von Medikamenten</li><li data-list-item-id=\"ed915f50a459dde5f50980cfa70cefe15\">Medizinische Kontrollen wie Blutzucker und Blutdruck messen etc.</li><li data-list-item-id=\"ecd19447a354f66f10f59e7371aba99dd\">Schmerzbehandlung</li><li data-list-item-id=\"ed2cb2f0f3921196d168d2a2162124621\">Pflege von Wunden</li><li data-list-item-id=\"e4f783386e772e11b268f4e4ab9a115b1\">Begleitung von Sterbenden (palliative Care)</li><li data-list-item-id=\"e38b4572e7769e9d625e5dfed1d2b314e\">Psychiatrische Pflegeleistungen</li></ul>\r\n<h3>2.4 Beratungs- und Informationsveranstaltungen</h3>\r\n<p>Wir nutzen Ihre Daten, vertraulich und anonym, für interne Weiterbilungszwecke.2.5 Notfallver-sorgung Ihre Daten werden bearbeitet, um Notfälle während der regulären Öffnungszeiten zu behandeln und um in solchen Fällen weitere organisatorische Massnahmen zu treffen.</p>\r\n<h3>2.5 Führung und Verwaltung der Klientendossiers</h3>\r\n<p>Die Verwaltung Ihrer Klientendossiers umfasst die Erfassung und Speicherung von Anamnese, Diagnose, Befunden sowie der Dokumentation Ihrer Betreuung. Zudem beinhalten die Dossiers Korrespondenzen, Rechnungen, Terminplanungen und relevante Fotos, die zur lückenlosen Dokumentation der medizinischen Geschichte notwendig sind.</p>\r\n<h3>2.6 Verwaltung der Daten zur Abrechnung</h3>\r\n<p>Zur Abrechnung unserer Leistungen verwalten wir Ihre Stamm- und Betreuungsdaten. Dies um-fasst die Kommunikation mit Sozialversicherungen, Krankenkassen und Unfallversicherungen sowie zur Einholung und Verwaltung der Kostengutsprache, gelegentlich den Austausch mit Behörden.</p>\r\n<h3>2.7 Lieferantenmanagement</h3>\r\n<p>Im Rahmen unserer Geschäftsbeziehung mit unseren Partnern oder Lieferanten erhalten wir ihre beruflichen Kontaktdaten, die wir in unseren Systemen speichern können. Dazu können auch Ihre Interessen oder Präferenzen gehören, um eine persönliche Geschäftsbeziehung zu pflegen.</p>\r\n<h3>2.8 Websites und Online-Angebote</h3>\r\n<p>Zur Erbringung unserer Dienstleistungen und zur Vermarktung unserer Angebote nutzen wir Websites und andere Online-Angebote. Wenn Sie auf unsere Website zugreifen, erheben wir Nutzungsdaten. Weitere Informationen zur Website finden Sie im entsprechenden Kapitel.</p>\r\n<h3>2.9 Printmedien</h3>\r\n<p>Wir versenden teilweise personalisierte Printmedien, wofür ihre Kontaktdaten oder berufliche Kontaktdaten bearbeitet werden. Für den Versand von Printmedien behalten wir uns vor, mit Dritten zusammenzuarbeiten und Ihre Kontaktdaten zu diesem Zweck weiterzugeben.</p>\r\n<h3>2.10 Stellenbewerbung</h3>\r\n<p>Um Ihre Eignung für ein Arbeitsverhältnis festzustellen, bearbeiten wir die Personendaten, die wir von Ihnen im Rahmen des Bewerbungsverfahrens erhalten haben. Dazu können auch Straf-register- und Betreibungsauszüge oder ähnliche Dokumente gehören. Wenn Sie Referenzen angegeben haben, können wir bei diesen Referenzen Auskünfte über Sie einholen. Sie haben das Recht zu erfahren, was uns mitgeteilt wurde. Tests, die der objektiven Feststellung der Eignung für die betreffende Stelle dienen, können Teil des Bewerbungsverfah-rens sein. Soweit es um die Feststellung der Eignung als Führungskraft geht, kann sich der Test auch auf Ihre Persönlichkeit beziehen. Sollte sich aus den eingereichten Unterlagen noch kein vollständiges und verlässliches Bild ergeben, erlauben wir uns, öffentlich zugängliche Quellen, die zur Klärung der konkreten berufli-chen Eignung geeignet sind, wie Xing oder LinkedIn, aber auch ganz allgemein Google, für die Recherche zu nutzen. Die Recherche in privaten Netzwerken wie Facebook oder Instagram ist für uns nicht relevant. Sofern objektive Gründe in Ihrer Person vorliegen, die Sie für das entsprechende Arbeitsver-hältnis einschränken oder disqualifizieren, sind Sie verpflichtet, uns diese offen zu legen. Dies kann auch eine Untersuchung Ihres Gesundheitszustandes beinhalten. Die Auskunft an uns er-folgt im gesetzlichen Rahmen</p>\r\n<h2>3. Website, Social Media und Cookie-Hinweise</h2>\r\n<p>Die Datenschutzerklärung gilt für alle betriebenen Websites, inklusive:</p>\r\n<p>luegjobs.ch</p>\r\n<p>Über die Websites werden Nutzungsdaten erfasst und automatisch in sogenannten Server-Log-Dateien gespeichert, die Ihr Browser automatisch an uns übermittelt. Diese Daten können von uns nicht bestimmten Personen zugeordnet werden. Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen. Wir behalten uns jedoch vor, diese Daten nach-träglich zu prüfen, wenn wir konkrete Anhaltspunkte für eine rechtswidrige Nutzung der Websites erhalten. Aus Sicherheitsgründen und zum Schutz der übertragenen vertraulichen Inhalte, wie z.B. Anfra-gen, die Sie an uns als Website-Betreiber senden, wird auf den Websites eine SSL/TLS-Verschlüsselung eingesetzt. Die Websites können Links zu anderen Websites enthalten, die sich unserer Kontrolle entziehen und daher nicht von dieser Datenschutzerklärung abgedeckt werden. Wenn Sie diese Links nutzen und auf andere Websites zugreifen, kann es sein, dass die Betreiber dieser Websites Informationen über Sie sammeln.</p>\r\n<h3>3.1 Nutzung des Kontaktformulars</h3>\r\n<p>Auf unserer Website steht ein Kontaktformular für Fragen, Anliegen oder Informationen zur Verfügung. Ihre Personendaten werden bearbeitet, um Ihre Anfrage zu bearbeiten und Ihnen eine qualifizierte Antwort bereitzustellen. Dies umfasst die Erfassung und Speicherung Ihrer Kontaktdaten sowie der relevanten medizinischen Informationen, die Sie uns über das Kontaktfor-mular übermitteln.</p>\r\n<h3>3.2 Social Media inklusive Plugins und Pixel</h3>\r\n<p>Wir betreiben Präsenzen auf sozialen Netzwerken und anderen Plattformen, die von Dritten betrieben werden, und bearbeiten in diesem Zusammenhang Daten über Sie. Sie können uns über diese Plattformen kontaktieren und wir erhalten von diesen Plattformen Daten wie z.B. Statistiken. Die Anbieter der Plattformen können Ihre Nutzung analysieren und die Daten über Sie für eigene Zwecke wie Marketing und Marktforschung verwenden. Die Anbieter der Plattformen handeln hierbei als eigenständige verantwortliche Stelle. Weiter können wir auf unseren Webseiten auch sogenannte Plugins oder Pixel von sozialen Netzwerken wie Facebook, X ehemals Twitter, LinkedIn, Pinterest oder Instagram verwenden. Die Plugins sind für Sie jeweils erkennbar. Sind sie aktiviert, können die Betreiber der jeweiligen sozialen Netzwerke registrieren, dass Sie unsere Website besuchen. Bei der Verwendung von Pixel-Technologien werden auf unserer Website entsprechende Codes implementiert, die eine Übermittlung Ihrer Nutzungsdaten ermöglichen. Diese dienen der Reichweitenmessung unserer Social-Media-Kampagnen. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen. Die meisten dieser Anbieter befinden sich ausserhalb der Schweiz. Weitere Informationen zur Datenübermittlung ins Ausland entnehmen Sie dem entsprechenden Kapitel.</p>\r\n<h3>3.3 WhatsApp oder andere Messenger-Apps</h3>\r\n<p>Wir nutzen WhatsApp aktiv als Kommunikationsmittel und ermöglichen Ihnen die Kontaktaufnahme über diesen Dienst. Bitte beachten Sie, dass bei der Nutzung von WhatsApp in der Re-gel das Adressbuch freigegeben wird und damit Personendaten an die WhatsApp Inc.&nbsp;in die USA übermittelt werden. Wir weisen darauf hin, dass die USA vom Bundesrat als Land ohne angemessenen Datenschutz eingestuft wurde. Weitere Informationen darüber, wie und zu wel-chem Zweck WhatsApp Ihre Daten bearbeitet, finden Sie in der Datenschutzerklärung von WhatsApp.</p>\r\n<h3>3.4 Permanente Cookies oder sonstige Tracking-Technologien</h3>\r\n<p>Auf unserer Website verwenden wir in der Regel Cookies und ähnliche Technologien, um Ihren Browser oder Ihr Gerät zu identifizieren. Ein Cookie ist eine kleine Datei, die beim Besuch unse-rer Website vom verwendeten Webbrowser automatisch an Ihren Computer gesendet oder auf Ihrem Computer oder Mobilgerät gespeichert wird. Wenn Sie diese Website erneut besuchen, können wir Sie wiedererkennen, auch wenn wir nicht wissen, wer Sie sind. Neben Cookies, die nur während einer Sitzung verwendet und nach dem Besuch der Website gelöscht werden (“Session Cookies”), können Cookies auch verwendet werden, um Benutzereinstellungen und andere Informationen für einen bestimmten Zeitraum zu speichern (“permanente Cookies”). Sie können Ihren Browser jedoch so einstellen, dass er Cookies ablehnt, nur für eine Sitzung spei-chert oder andernfalls vorzeitig löscht. Die meisten Browser sind so eingestellt, dass sie Coo-kies akzeptieren. Wir verwenden permanente Cookies, um Benutzereinstellungen zu speichern (z.B. Sprache, Auto-Login), um besser zu verstehen, wie Sie unsere Angebote und Inhalte nut-zen, und um Ihnen auf Sie zugeschnittene Angebote und Werbung anzeigen zu können (was auch auf Websites anderer Unternehmen der Fall sein kann). Einige Cookies werden von uns gesetzt, andere von Vertragspartnern, mit denen wir zusammenarbeiten. Wenn Sie Cookies blockieren, kann es sein, dass einige Funktionen (z.B. Sprachauswahl, Warenkorb, Bestellvor-gang) nicht mehr funktionieren. Wenn Sie dies nicht wünschen, müssen Sie Ihren Browser bzw. Ihr E-Mail-Programm entsprechend einstellen</p>\r\n<h4>3.4.1 Google Fonts oder andere Web-Fonts</h4>\r\n<p>Diese Website verwendet sogenannte Fonts von Google oder anderen Anbietern, um eine ein-heitliche Darstellung von Schriften zu gewährleisten. Beim Aufruf der Seite lädt Ihr Browser die benötigten Fonts in den Browser-Cache, um die Texte und Schriften korrekt darzustellen. Um Ihre Privatsphäre zu schützen, haben wir die Fonts soweit möglich auf unserem eigenen Webs-erver installiert, so dass Ihre IP-Adresse beim Laden der Fonts nicht an andere Diensteanbieter weitergegeben wird. Bitte beachten Sie jedoch, dass bei der Nutzung bestimmter Dienste, wie z.B. Maps, Captcha oder Bootstrap, möglicherweise Fonts von diesen Dienstleistern verwendet werden. Falls Ihr Browser keine externen Schriften unterstützt, wird automatisch eine Stan-dardschrift Ihres Computers verwendet. Weitere Informationen zu Google Fonts und deren Da-tenschutzbestimmungen finden Sie auf der Website von Google oder des jeweiligen Anbieters.</p>\r\n<h4>3.4.2 Google Photos, Youtube oder andere Bild- und Streamingdienste</h4>\r\n<p>Auf dieser Website sind Funktionen des Google-Dienstes Photos und YouTube oder anderer Streaming-Dienste integriert. Diese verwenden wir, um Photos oder Videos auf unserer Website einzubinden. Die Plugins sind für Sie erkennbar. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen.</p>\r\n<h4>3.4.3 Heyflow</h4>\r\n<p>Für unsere Bewerbungs Experience setzen wir den Dienst Heyflow der Heyflow GmbH, Deutschland (EU), ein. Dabei werden die von Ihnen eingegebenen Angaben sowie Nutzungs und Gerätedaten (z. B. IP Adresse, Zeitstempel, Interaktionen, Browser/OS, Cookies/Local Storage) zur Entgegennahme, Prüfung und Abwicklung Ihrer Bewerbung bearbeitet. Heyflow bearbeitet diese Personendaten als unser Auftragsbearbeiter. Weitere Informationen zu Heyflow und deren Datenschutzbestimmungen finden Sie auf der Website von Heyflow.</p>\r\n<h2>4. Herkunft von Personendaten</h2>\r\n<p>Die Daten, die wir bearbeiten, stammen in den meisten Fällen von Ihnen selbst, z.B. im Zusam-menhang mit der Erbringung unserer Dienstleistungen, der Nutzung unserer Website oder der Kommunikation mit uns. Wenn Sie mit uns Verträge abschliessen oder unsere Dienstleistungen in Anspruch nehmen wollen, müssen Sie uns bestimmte Daten bekannt geben. Dies gilt auch für die Nutzung unserer Website. Darüber hinaus sind Sie zur Bekanntgabe von Daten verpflich-tet, um gesetzliche Verpflichtungen zu erfüllen. Ansonsten steht es Ihnen frei, ob Sie uns Daten über sich mitteilen. Wir können Daten auch von Dritten erhalten, insbesondere von unseren externen Dienstleistern oder Vertragspartnern, von Finanzdienstleistern und Versicherungen. Darüber hinaus können wir Daten aus öffentlich zugänglichen Quellen wie Internetseiten, Unternehmensregistern, Grundbü-chern, Handelsregistern, Auskunfteien, Adresshändlern, Verbänden, Telefonbüchern, Inter-netanalysediensten erhalten.</p>\r\n<h2>5. Datenweitergabe und Datenübermittlung ins Ausland</h2>\r\n<p>Im Rahmen unserer geschäftlichen Aktivitäten und gemäss den genannten Zwecken besteht die Möglichkeit, dass wir Informationen mit Dritten teilen, insbesondere mit folgenden Kategorien von Empfängern:</p>\r\n<ul><li data-list-item-id=\"eb655ceac612723df820daa2c0d7f6f7f\">Fachspezialisten: Wir arbeiten mit Ärztinnen und Ärzten zusammen, mit denen teilweise auch Daten ausgetauscht werden;</li><li data-list-item-id=\"e8335efa95f4c68819e9cd99c861262f9\">Dienstleister: Wir arbeiten mit Dienstleistern zusammen, die Daten in unserem Auftrag oder in gemeinsamer Verantwortlichkeit bearbeiten, wie zum Beispiel Hausarztpraxen, Apotheken, Anbieter von Praxissoftware, Marketing-Agenturen oder IT-Dienstleister, sonstige Lieferanten, Geschäftspartner;</li><li data-list-item-id=\"e93cbdcaf077a67fcf0d38211148f2d63\">Behörden: Wir können Daten auch an Behörden im In- (und Ausland), Amtsstellen oder Gerichte bekanntgeben, wenn wir dazu rechtlich verpflichtet sind;</li><li data-list-item-id=\"e3b0f3783dd6cc9a0b387c0ea42cdd65c\">Finanzdienstleister und Versicherungen: Im Zusammenhang mit Bonitäts- und Versi-cherungsleistungen arbeiten wir mit Auskunfteien, Banken, Versicherungen zusammen;</li><li data-list-item-id=\"ec17b00d9c96652226b206d8e30b071cb\">Andere Dritte: Alle anderen Dritten, mit denen wir zur Erfüllung der genannten Zwecke zusammenarbeiten. Dies können beispielsweise Medien, die Öffentlichkeit, einschliess-lich Besuchern von Websites, Mitbewerbern, Branchenorganisationen, Verbände, Organisationen und weitere Gremien sein. Zusätzlich können es auch Parteien im Zusam-menhang mit einer Unternehmenstransaktion wie z. B. einer Fusion, einem Verkauf von Vermögenswerten oder Anteilen, einer Restrukturierung, einer Finanzierung, einem Kon-trollwechsel oder der Übernahme des gesamten oder eines Teils unseres Unternehmens sein.</li></ul>\r\n<p>Diese Kategorien von Empfängern können Dritte einbeziehen, denen Personendaten zugänglich gemacht werden. Dienstleister und bestimmte Vertragspartner, die in unserem Auftrag tätig sind, können wir vertraglich verpflichten, die Daten nicht für eigene Zwecke zu verwenden. An-dere Dritte wie Finanzdienstleister, Versicherungen oder Behörden verwenden die Daten für eigene Zwecke, z.B. zur Erfüllung gesetzlicher Vorgaben, weshalb wir diese Bearbeitungen nicht einschränken können. Wir bearbeiten Ihre Personendaten vorwiegend in der Schweiz. Die Personendaten können aber auch an Empfänger im Ausland bekannt gegeben werden z.B. in die USA. Darüber hinaus kön-nen die Daten in weitere Staaten des Europäischen Wirtschaftsraumes übermittelt werden. Durch die heutige globale Vernetzung und aufgrund von international tätigen Konzernen ist es zudem möglich, dass Daten überall auf der Welt bearbeitet werden können. Befindet sich ein Empfänger in einem Land ohne angemessenes gesetzliches Datenschutzniveau, werden wir unseren Lieferanten oder Partner, den Empfänger vertraglich zur Einhaltung des anwendbaren Datenschutzniveaus verpflichten, soweit er nicht bereits einem gesetzlich anerkannten Regel-werk zur Sicherstellung des Datenschutzes unterliegt und wir uns nicht auf eine Ausnahmebe-stimmung berufen können.</p>\r\n<h2>6. Dauer der Aufbewahrung von Personendaten</h2>\r\n<p>Wir bearbeiten und speichern Ihre Personendaten so lange, wie es für die Erfüllung unserer vertraglichen und gesetzlichen Pflichten oder sonst die mit der Bearbeitung verfolgten Zwecke erforderlich ist, d.h. also zum Beispiel für die Dauer der gesamten Klientenbeziehung sowie darüber hinaus gemäss den gesetzlichen Aufbewahrungs- und Dokumentationspflichten. Dabei ist es möglich, dass Personendaten für die Zeit aufbewahrt werden, in der Ansprüche gegen unser Unternehmen geltend gemacht werden können und soweit wir anderweitig gesetzlich dazu verpflichtet sind oder berechtigte Geschäftsinteressen dies erfordern (z.B. für Beweis- und Do-kumentationszwecke).</p>\r\n<h2>7. Datensicherheit</h2>\r\n<p>Wir treffen angemessene technische und organisatorische Sicherheitsvorkehrungen zum Schutz Ihrer Personendaten. Wir berücksichtigen dabei den Stand der Technik, das Risiko der Bearbei-tung, die Investitionskosten und orientieren uns neben dem Schweizer Datenschutzgesetz an der Datenschutzverordnung. Die Massnahmen sollen dazu dienen Datenschutzverletzungen, wie beispielsweise dem unberechtigten Zugriff und Missbrauch der Daten, zu verhindern. Die Auf-tragsbearbeiter, an die wir Daten weitergeben weisen wir ebenfalls an angemessene technische und organisatorische Sicherheitsvorkehrungen zu treffen. Kontaktaufnahme per E-Mail Die Kommunikation mittels E-Mail ist in der Regel nicht verschlüsselt. Werden jedoch beson-ders schützenswerte Daten ausgetauscht versenden wir diese verschlüsselt mittels HIN. Es besteht die Möglichkeit, dass Daten verloren gehen oder von Dritten abgefangen und/oder manipuliert werden können, um zum Beispiel damit die Echtheit vorzutäuschen. Wir treffen ge-eignete technische und organisatorische Sicherheitsmassnahmen, um dies innerhalb des Sys-tems zu verhindern. Dennoch kann die Vertraulichkeit von Daten bei der Übertragung jeglicher Daten per E-Mail nicht gewährleistet werden. Dieser Hinweis gilt insbesondere in Bezug auf die Übertragung von besonders schützenswerten Personendaten, übermitteln Sie uns diese nicht per E-Mail, sondern kontaktieren Sie uns vorgängig, um einen sicheren Kanal zu vereinbaren. Externe Zugriffsgeräte (PC, Smartphone etc. von Endnutzern) und Teile der zwischen dem Ab-sender und Empfänger an der Übermittlung beteiligten Infrastruktur befinden sich ausserhalb des von uns kontrollierbaren Bereichs. Wir haften nicht für Konsequenzen und Schäden, die sich aus dem elektronischen Informationsaustausch und insbesondere aus einer missbräuchli-chen Verwendung des E-Mail-Systems ergeben können. Wir behalten uns vor uns, für jeglichen vorsätzlichen Schaden, der uns aus dem Geschäftsverkehr mit der betroffenen Person über den elektronischen Informationsaustausch entsteht, schadlos zu halten. Weiter behalten wir uns vor, im Einzelfall nicht per E-Mail zu antworten oder für die per E-Mail erhaltene Auftragsertei-lung oder Information zusätzlich eine andere Form zu verlangen wie z.B. über ein Formular mit Unterschrift.</p>\r\n<h2>8. Präferenzen und automatisierte Einzelentscheidungen</h2>\r\n<p>Zur Begründung und Durchführung der Geschäftsbeziehung und auch sonst nutzen wir grund-sätzlich keine vollautomatisierte automatische Entscheidungsfindung. Sollten wir solche Verfah-ren in Einzelfällen einsetzen, werden wir Sie hierüber gesondert informieren, sofern dies gesetz-lich vorgegeben ist und Sie über die damit zusammenhängenden Rechte aufklären.</p>\r\n<h2>9. Rechte der betroffenen Personen</h2>\r\n<p>Als betroffene Person haben Sie im Zusammenhang mit der Datenbearbeitung die gesetzlich vorgesehenen Rechte. Sie haben insbesondere das Recht, Auskunft über Ihre gespeicherten Personendaten zu verlangen. Ebenso können Sie eine Berichtigung, Ergänzung, Sperrung oder Löschung Ihrer Personendaten verlangen. Des Weiteren steht es Ihnen frei, der Verwendung Ihrer Daten zu Marketingzwecken zu widersprechen. Ihre Einwilligung können Sie jederzeit mit Wirkung für die Zukunft widerrufen. Zusätzlich haben Sie das Recht, die Übertragung Ihrer Da-ten an andere Verantwortliche zu verlangen. Wir weisen jedoch darauf hin, dass wir uns das Recht vorbehalten, gesetzliche Einschränkung-gen geltend zu machen, etwa wenn wir zur Aufbewahrung oder Bearbeitung bestimmter Daten verpflichtet sind, ein berechtigtes Interesse daran haben oder die Daten zur Geltendmachung von Rechtsansprüchen benötigen. An die Stelle der Löschung tritt die Sperrung, sofern rechtli-che Hindernisse der Löschung entgegenstehen. Bitte beachten Sie, dass die Ausübung dieser Rechte mit vertraglichen Vereinbarungen in Konflikt stehen und dies Konsequenzen wie z.B. eine vorzeitige Vertragsauflösung oder Kostenfolgen nach sich ziehen kann. Wir werden Sie in einem solchen Fall vorab informieren, sofern dies nicht bereits vertraglich geregelt ist. Die Ausübung dieser Rechte setzt in der Regel voraus, dass Sie Ihre Identität eindeutig nach-weisen (z. B. durch Vorlage einer Kopie Ihres Identitätsdokuments, wenn Ihre Identität sonst nicht eindeutig ist oder nicht überprüft werden kann). Zur Geltendmachung Ihrer Rechte können Sie sich an den in Kapitel 1 genannten Datenschutzberater wenden. Jede betroffene Person hat zudem das Recht, ihre Ansprüche gerichtlich geltend zu machen oder sich bei der zuständigen Datenschutzbehörde zu beschweren. Zuständige Datenschutzbe-hörde in der Schweiz ist der Eidgenössische Datenschutz- und Öffentlichkeitsbeauftragte (https://www.edoeb.admin.ch).</p>\r\n<h2>10. Änderungen dieser Datenschutzerklärung</h2>\r\n<p>Wir können diese Datenschutzerklärung jederzeit ohne vorherige Ankündigung ändern. Diese Datenschutzerklärung ist nicht Teil eines Vertrages mit Ihnen. Es gilt grundsätzlich die jeweils aktuelle Fassung, die auf unserer Website veröffentlicht ist.</p>\r\n<h2>11. Urheberrecht und Lizenz</h2>\r\n<p>Diese Datenschutzerklärung wurde im Rahmen des Datenschutz Service von der impunix AG erstellt. Bei Fragen oder Anmerkungen dürfen Sie uns gerne über die Kontaktdaten in Kapitel 1 kontaktieren. Der Gebrauch dieser Datenschutzerklärung ist ausschliesslich Kunden unseres Datenschutz Full-Service vorbehalten.</p>\r\n<h2>12. Kategorien von Personendaten</h2>\r\n<p>Je nach Geschäftsvorfall bearbeiten wir eine oder mehrere der nachfolgenden Kategorien von Personendaten in der unten aufgelisteten Tabelle.</p>\r\n<ul><li data-list-item-id=\"e00bc9d0bb0b155afa665fecf408793d4\">Stammdaten: Daten für die Zuordnung, Behandlung und Abrechnung, wie Name, Ge-burtsdatum, Adresse, Versicherungsnummer, Klientennummer und Kontaktdaten, etc.;</li><li data-list-item-id=\"e752925bcac1946f526f48263269de94a\">Bonitäts- und Bankdaten: Lohn, Wohnkosten, frei verfügbares Einkommen, Zahlungs-verhalten, Bilanzen, Daten von Auskunfteien, Score-Werte, Vermögensverhältnisse, Kon-toverbindung, Kreditkartennummer, etc.;</li><li data-list-item-id=\"e220a6a22f5b0fb4d2cad41e8e2604a99\">Gesundheitliche und medizinische Daten: Medizinische Beurteilungen, Arztzeugnisse, Diagnosen, Behandlungsverläufe, Therapiepläne, Ergebnisse von Untersuchungen und Laborberichten, etc.;</li><li data-list-item-id=\"e7d947e383df5c177d3b495d1e1f39ca8\">Identitätsangaben: Daten zur Feststellung Ihrer Identität, z.B. ID, etc.</li><li data-list-item-id=\"e8231f2a04bb9589a825826ab997ff5ef\">Interessen und Präferenzen: Von Ihnen bereitgestellte oder erfasste Informationen über Ihre Interessenbereiche, z. B. die für Sie interessanten Produkte, Hobbies und weitere persönliche Präferenzen.;</li><li data-list-item-id=\"ed012a16dbce9e498bbf2acc5efa31deb\">Kontaktdaten: Name, Adresse, Telefonnummer, E-Mail-Adresse;</li><li data-list-item-id=\"e8700f8c2ada0c0a8a70315dd3ed8ea7b\">Kontaktdaten erweitert: Daten zum Ehegatten oder Kindern, Familienstand, Portraitfoto, Ehrenamt, Berufsbezeichnung, beruflicher Werdegang, Betriebszugehörigkeit, Aufgaben, Tätigkeiten, Qualifikationen, Bewertungen / Beurteilungen, Zertifikate, Geburtsdatum etc.;</li><li data-list-item-id=\"eb384bfae041adfe11890f99116a499a3\">Kontaktdaten beruflich: Name, Vorname, Anrede, Anschrift, E-Mail-Adresse, Telefon-nummer, Mobiltelefonnummer, Arbeitgeber, Funktion, Abteilung, Zuständigkeiten, etc.;</li><li data-list-item-id=\"ee2da6756679841591128e315c225aa20\">Nutzungsdaten der Website: Die IP-Adresse, Art und Version des Browsers, verwende-tes Betriebssystem und Gerätetyp, Referrer URL (die vorherige Website, von der aus Sie auf unsere Seite gelangt sind), den Internet-Service-Provider, Hostname des zugreifen-den Computers, Zeitpunkt der Serveranfrage, etc. Sie geben uns auch Informationen darüber, wie Sie die Website nutzen. Die Datenbearbeitung bei der Nutzung der Website und der App einschliesslich des Trackings mit Cookies erläutern wir in den Hinweisen zur Website.;</li><li data-list-item-id=\"e5ee60508830bda8563031d5478c4dc57\">Technische Daten: Daten zu technischen Gegebenheiten der Systeme, wie Konfiguratio-nen, IP-Adressen, Seriennummern, Produktinformationen, Lizenzen, Dokumentationen, etc.</li><li data-list-item-id=\"ee007410a2f398958134d7f9e58bb702c\">Vertragsdaten: Daten zur Geschäftsbeziehung, Kundennummer, Angebote und gekaufte Produkte, Dienstleistungen oder Services (inkl. Online-Services, Datum Vertrag, Kauf-preis, Sonderwünsche, Garantien, Kulanz, etc.;</li><li data-list-item-id=\"e9fad143dbbb98fa2ad39ce43d201c792\">Zugangsdaten: Zugangsdaten zur Authentifizierung in Systemen.</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(10,1,1785768038,1785768038,1,0,0,0,'0',1295,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'powermail_pi1',0,0,'','',0,'',100,'','','',NULL,0,0,NULL,NULL,0,0,0,0,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\"><language index=\"lDEF\">\n            <field index=\"settings.flexform.main.form\"><value index=\"vDEF\">1</value></field>\n        </language></sheet>\n        <sheet index=\"receiver\"><language index=\"lDEF\">\n            <field index=\"settings.flexform.receiver.email\"><value index=\"vDEF\">personal@spitexlueg.ch</value></field>\n        </language></sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(11,1,1785847146,1785769130,0,0,0,0,'',1152,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_bewerben_steps\":\"\",\"lueg_bewerben_steps_heading\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_bewerben',0,0,'','',0,'Lueg – <br>u chum zu üs',100,'','','','<p>Einfach Formular ausfüllen – wir melden uns am nächsten Arbeitstag.</p>',0,0,NULL,NULL,0,0,0,0,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',0,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','Wie läuft der Bewerbungsprozess ab?',4,1),
(12,10,1785849408,1785849330,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',0,'','','','<p>Spitex Region Lueg<br />Geschäftsstelle<br />Rüegsaustrasse 8<br />Postfach<br />3415 Hasle-Rüegsau</p>\r\n<p><a href=\"tel:+41344605000\">034 460 50 00</a><br /><a href=\"mailto:info@spitexlueg.ch\">info@spitexlueg.ch</a></p>\r\n<p><strong>Vertretungsberechtigte Person</strong><br />Andreas Bütikofer, Geschäftsleiter</p>\r\n<p><strong>Handelsregister-Eintrag</strong><br />Eingetragener Firmenname: Spitex Region Lueg<br />Handelsregister Nr: CHE-114.295.948</p>\r\n<p><strong>Mehrwertsteuer-Nummer</strong><br />CHE-114.295.948</p>\r\n<p><br />Konzept &amp; Design &amp; Programmierung<br /><a href=\"https://studiothompfister.com/\" target=\"_blank\" rel=\"noopener\">Studio Thom Pfister</a><br />&nbsp;</p>',0,0,0,0,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(13,11,1785917229,1785916476,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'powermail_pi1',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.main.form\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.flexform.main.confirmation\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.optin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.moresteps\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.pid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"receiver\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.receiver.type\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.receiver.name\">\n                    <value index=\"vDEF\">Spitex Region Lueg</value>\n                </field>\n                <field index=\"settings.flexform.receiver.email\">\n                    <value index=\"vDEF\">dani@studiothompfister.com</value>\n                </field>\n                <field index=\"settings.flexform.receiver.subject\">\n                    <value index=\"vDEF\">Nachricht über das Kontaktformular</value>\n                </field>\n                <field index=\"settings.flexform.receiver.body\">\n                    <value index=\"vDEF\">&lt;p&gt;Guten Tag&amp;nbsp;&lt;/p&gt;\n&lt;p&gt;Über das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht.&amp;nbsp;&lt;/p&gt;\n&lt;p&gt;Die übermittelten Angaben finden Sie nachfolgend:&lt;/p&gt;\n&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"sender\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.sender.name\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.email\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.subject\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"thx\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.thx.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n                <field index=\"settings.flexform.thx.redirect\">\n                    <value index=\"vDEF\">t3://page?uid=12</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0),
(14,12,1785917276,1785916848,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',0,'','','','<h2>Vielen Dank für deine Bewerbung!&nbsp;</h2>\r\n<p><br />Wir haben deine Angaben erfolgreich erhalten und werden uns so bald wie möglich bei Dir melden.</p>\r\n<p>Ihr Spitex Region Lueg</p>',0,0,0,0,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0,'','',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Pflegefachperson FH, Bachelor of Science in Pflege, Schwerpunkt Psychiatrie 40 – 60%','Zur Erweiterung unseres Fachteams Psychiatrie in Hasle-Rüegsau b. Burgdorf suchen wir nach Vereinbarung.','<p>Arbeitsort: Spitex Region Lueg, Hasle-Rüegsau b. Burgdorf<br>Arbeitszeiten: Montag bis Freitag – flexibel während der Bürozeiten<br>Stellenantritt: nach Vereinbarung</p>\n<h3>Deine Aufgaben</h3><ul><li>Du coachst Mitarbeitende im Pflegeprozess und in komplexen Pflegesituationen (ca. 10%)</li><li>Du übernimmst Fallführung und Pflegeorganisation für Klientinnen und Klienten</li><li>Du entwickelst gemeinsam mit Teamleitung und Qualitätsmanagement den Fachbereich Psychiatrie evidenzbasiert weiter</li><li>Du führst interne Schulungen zu Fachthemen durch</li><li>Du engagierst dich in interdisziplinären Projekten und stärkst die multiprofessionelle Zusammenarbeit</li></ul>\n<h3>Dein Profil</h3><ul><li>Bachelor of Science in Pflege, Psychiatrie oder mehrjährige Facherfahrung mit ausgewiesenem Leistungsausweis</li><li>Spitex-Erfahrung oder mehrjährige Erfahrung in der psychiatrischen Pflege</li><li>Konstruktive Haltung mit ausgeprägter Lösungsorientierung und Innovationsfreude</li><li>Klare, empathische Kommunikation auf Augenhöhe</li><li>Führerausweis Kategorie B</li></ul>\n<h3>Was wir bieten</h3><ul><li>Geregelte Arbeitszeiten (Mo–Fr) und mindestens 25 Ferientage</li><li>Echte Wertschätzung: offener Teamaustausch, Gestaltungsspielraum, Mitbestimmung</li><li>Attraktive interne und externe Weiterbildungsmöglichkeiten</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>Sorgfältige Einführung und starke Teamunterstützung</li><li>Moderne Infrastruktur</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pflegefachperson-fh-psychiatrie-40-60',NULL,'',0.5,'',''),
(NULL,2,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Pflegeassistent/in oder Pflegehelfende SRK 40-50%','Für unseren Standort Weier i. E. suchen wir nach Vereinbarung.','<p>Arbeitsort: Weier i. E.<br>Stellenantritt: nach Vereinbarung</p>\n<h3>Ihre Aufgaben</h3><ul><li>Sie führen eine kompetente, bedarfsgerechte Grundpflege bei Klientinnen und Klienten in stabilen Situationen durch</li><li>Sie arbeiten selbständig und übernehmen Eigenverantwortung</li><li>Sie führen eine professionelle Pflegedokumentation</li></ul>\n<h3>Ihr Profil</h3><ul><li>Abgeschlossene Ausbildung als Pflegehelfende SRK oder Pflegeassistent/-in</li><li>Mindestens ein Jahr Berufserfahrung in der Pflege</li><li>Empathisch, einfühlsam und hilfsbereit</li><li>Führerausweis sowie eigenes Auto</li></ul>\n<h3>Ihre Vorteile</h3><ul><li>Kommunikation auf Augenhöhe</li><li>Vielfältige interne und externe Weiterbildungsmöglichkeiten</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>5 Wochen Ferien als Grundguthaben</li><li>Sorgfältige Einführung und starke Teamunterstützung</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch<br>SPITEX Region Lueg, Personalabteilung, Rüegsaustrasse 8, Postfach, 3415 Hasle-Rüegsau</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pflegeassistent-pflegehelfende-srk-40-50',NULL,'',0.5,'',''),
(NULL,3,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Fachfrau / Fachmann Gesundheit EFZ, mit / ohne Berufsbildner 50-80 %','Für unsere Standorte suchen wir ab sofort oder nach Vereinbarung.','<p>Stellenantritt: ab sofort oder nach Vereinbarung</p>\n<h3>Ihre Aufgaben</h3><ul><li>Sie stellen eine bedürfnisorientierte, bedarfs- und fachgerechte Pflege und Beratung unserer Klientinnen und Klienten zu Hause sicher</li><li>Sie übernehmen Mitverantwortung in der Fallführung als zweite Bezugsperson</li><li>Sie erfassen und dokumentieren Pflegeleistungen</li><li>Sie begleiten Lernende im Alltag</li></ul>\n<h3>Ihr Profil</h3><ul><li>Abgeschlossene Ausbildung als Fachfrau/Fachmann Gesundheit</li><li>Achtsamkeit, Engagement und Empathie für unsere Klientinnen und Klienten</li><li>Flexibilität in der Arbeitsorganisation</li><li>Führerausweis, gute Fahrpraxis und eigenes Auto</li></ul>\n<h3>Ihre Vorteile</h3><ul><li>Kommunikation auf Augenhöhe</li><li>Vielfältige interne und externe Weiterbildungsangebote</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>5 Wochen Ferien als Grundguthaben</li><li>Sorgfältige Einführung und starke Teamunterstützung</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch<br>SPITEX Region Lueg AG, Personal, Rüegsaustrasse 8, Postfach, 3415 Hasle-Rüegsau</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'fachfrau-fachmann-gesundheit-efz-50-80',NULL,'',0.5,'',''),
(NULL,4,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Dipl. Pflegefachperson HF 40-80%','Für unsere Standorte Hasle-Rüegsau, Sumiswald und Weier suchen wir ab sofort oder nach Vereinbarung.','<p>Standorte: Hasle-Rüegsau, Sumiswald und Weier<br>Stellenantritt: ab sofort oder nach Vereinbarung</p>\n<h3>Ihre Aufgaben</h3><ul><li>Sie übernehmen Verantwortung für fachliche Pflege, Betreuung und Beratung zu Hause</li><li>Sie beteiligen sich am Fallführungskonzept und tragen Mitverantwortung für den Pflegeprozess</li><li>Pflege nach Kinaesthetics-Grundsätzen</li><li>Klassifizierung der Pflegediagnostik auf Basis von NANDA</li><li>Förderliche interdisziplinäre Zusammenarbeit im Team und mit Ärztinnen und Ärzten</li></ul>\n<h3>Ihr Profil</h3><ul><li>Abgeschlossene Ausbildung zur/zum diplomierten Pflegefachperson</li><li>Achtsamkeit, Engagement und Empathie</li><li>Flexibilität in der Arbeitsorganisation</li><li>Führerausweis und gute Fahrpraxis</li></ul>\n<h3>Ihre Vorteile</h3><ul><li>Organisationskultur mit Teamgeist und Eigenverantwortung</li><li>Vielfältige interne und externe Weiterbildungsangebote</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>5 Wochen Ferien als Grundguthaben</li><li>Sorgfältige Einführung</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'dipl-pflegefachperson-hf-40-80',NULL,'',0.5,'',''),
(NULL,5,8,1785748739,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Lehrstelle als Fachfrau/Fachmann Gesundheit EFZ oder als FaGe E (verkürzte Ausbildung für Erwachsene)','Per 1. August 2027 bieten wir an unseren vier Standorten je eine Lehrstelle an.','<p>Stellenantritt: 1. August 2027 · vier Lehrstellen an vier Standorten</p>\n<h3>Warum Spitex?</h3><ul><li>Weil du mehr willst als einfach einen Job.</li><li>Menschen, unterwegs sein, Abwechslung – bei uns erlebst du jeden Tag etwas Besonderes.</li></ul>\n<h3>Drei Gründe für deine Lehre bei uns</h3><ul><li><strong>Abwechslung pur</strong> – kein Tag ist gleich, du bist selbstständig unterwegs und lernst viele Lebensgeschichten kennen.</li><li><strong>Sinnstiftende Arbeit</strong> – du hilfst Menschen, zu Hause gut zu leben.</li><li><strong>Top Ausbildung</strong> – wir begleiten dich persönlich und bereiten dich optimal auf den Berufsalltag vor.</li></ul>\n<h3>Das bist du</h3><ul><li>offen, interessiert und zuverlässig</li><li>gerne bei Menschen zu Hause</li><li>voller Neugier auf neue Erfahrungen und Begegnungen</li></ul>\n<h3>Das erwartet dich</h3><ul><li>eine praxisnahe und vielseitige Ausbildung</li><li>spannende Einblicke in Pflege, Betreuung und Gesundheit</li><li>ein motiviertes Team, das dich unterstützt</li><li>erfahrene und engagierte Berufsbildnerinnen</li></ul>\n<h3>Zusätzliche Voraussetzungen für FaGe E</h3><ul><li>Mind. 22. Altersjahr vollendet</li><li>2 Jahre Berufserfahrung im Berufsfeld Pflege und Betreuung (85% Anstellungsgrad inkl. 25% Schulanteil)</li><li>Vorbildung: EFZ-Abschluss, Matura, gleichwertiges Diplom oder ABU-Abschluss vor Ausbildungsbeginn</li></ul>\n<h3>Kontakt</h3><p>Anita Beer, Personalleitung · 034 460 50 00 · personal@spitexlueg.ch</p>',1785746122,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'lehrstelle-fage-efz-fage-e-2027',NULL,'',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_tag` VALUES
(NULL,1,8,0,0,1,0,0,0,0,NULL,NULL,0,0,0,0,'Lehrstelle','lehrstelle','',NULL,'',NULL);
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_powermail_domain_model_answer`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_answer` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `mail` int(10) unsigned NOT NULL DEFAULT 0,
  `value` text NOT NULL DEFAULT '',
  `value_type` int(10) unsigned NOT NULL DEFAULT 0,
  `field` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `mail` (`mail`),
  KEY `deleted` (`deleted`),
  KEY `hidden` (`hidden`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_answer`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_powermail_domain_model_answer` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_answer` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_answer` VALUES
(1,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,1,'Spontantbewerbung',0,1,''),
(2,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,1,'Daniel',0,2,''),
(3,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,1,'Hackiewicz',0,3,''),
(4,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,1,'0791999464',0,4,''),
(5,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,1,'dhackiewicz@gmail.com',0,5,''),
(6,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,1,'guten tag\r\nich hätte Interesse\r\nLG\r\nDani',0,6,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_answer` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_powermail_domain_model_field`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_field` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `page` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `settings` text NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `content_element` int(11) NOT NULL DEFAULT 0,
  `text` text NOT NULL DEFAULT '',
  `prefill_value` text NOT NULL DEFAULT '',
  `placeholder` text NOT NULL DEFAULT '',
  `placeholder_repeat` text NOT NULL DEFAULT '',
  `create_from_typoscript` text NOT NULL DEFAULT '',
  `validation` int(11) NOT NULL DEFAULT 0,
  `validation_configuration` varchar(255) NOT NULL DEFAULT '',
  `css` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `multiselect` smallint(5) unsigned NOT NULL DEFAULT 0,
  `datepicker_settings` varchar(255) NOT NULL DEFAULT '',
  `feuser_value` varchar(255) NOT NULL DEFAULT '',
  `sender_email` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sender_name` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mandatory` smallint(5) unsigned NOT NULL DEFAULT 0,
  `own_marker_select` smallint(5) unsigned NOT NULL DEFAULT 0,
  `marker` varchar(255) NOT NULL DEFAULT '',
  `mandatory_text` varchar(255) NOT NULL DEFAULT '',
  `autocomplete_token` varchar(20) NOT NULL DEFAULT '',
  `autocomplete_section` varchar(100) NOT NULL DEFAULT '',
  `autocomplete_type` varchar(8) NOT NULL DEFAULT '',
  `autocomplete_purpose` varchar(8) NOT NULL DEFAULT '',
  `auto_marker` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent_page` (`page`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_field`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_powermail_domain_model_field` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_field` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_field` VALUES
(1,7,1785847079,1785767961,0,0,0,0,1,0,0,NULL,0,'{\"autocomplete_token\":\"\",\"create_from_typoscript\":\"\",\"css\":\"\",\"description\":\"\",\"endtime\":\"\",\"feuser_value\":\"\",\"hidden\":\"\",\"mandatory\":\"\",\"marker\":\"\",\"multiselect\":\"\",\"own_marker_select\":\"\",\"sender_email\":\"\",\"sender_name\":\"\",\"settings\":\"\",\"starttime\":\"\",\"title\":\"\",\"type\":\"\"}',0,0,0,0,1,'Stelle','select','','',0,'','','','','lib.powermailStellen',0,'','','',0,'','',0,0,0,0,'stelle','','','','','',0,''),
(2,7,1785847079,1785767961,0,0,0,0,2,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Vorname','input','','',0,'','','','','',0,'','','',0,'','',0,1,1,0,'vorname','','','','','',0,''),
(3,7,1785847079,1785767961,0,0,0,0,3,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Name','input','','',0,'','','','','',0,'','','',0,'','',0,1,1,0,'name','','','','','',0,''),
(4,7,1785847079,1785767961,0,0,0,0,4,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Tel','input','','',0,'','','','','',0,'','','',0,'','',0,0,0,0,'tel','','','','','',0,''),
(5,7,1785847079,1785767961,0,0,0,0,5,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Email','input','','',0,'','','','','',0,'','','',0,'','',1,0,1,0,'email','','','','','',0,''),
(6,7,1785847079,1785767961,0,0,0,0,6,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Notiz','textarea','','',0,'','','','','',0,'','','',0,'','',0,0,0,0,'notiz','','','','','',0,''),
(7,7,1785847079,1785767961,0,0,0,0,7,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Jetzt abschicken','submit','','',0,'','','','','',0,'','','',0,'','',0,0,0,0,'submit','','','','','',0,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_field` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_powermail_domain_model_form`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_form` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `note` smallint(5) unsigned NOT NULL DEFAULT 0,
  `css` varchar(255) NOT NULL DEFAULT '',
  `pages` varchar(255) NOT NULL DEFAULT '',
  `autocomplete_token` varchar(3) NOT NULL DEFAULT '',
  `is_dummy_record` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_form`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_powermail_domain_model_form` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_form` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_form` VALUES
(1,7,1785767961,1785767961,0,0,0,0,0,0,NULL,0,NULL,0,0,0,0,'Bewerbung',0,'','1','',0,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_form` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_powermail_domain_model_mail`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_mail` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sender_name` varchar(255) NOT NULL DEFAULT '',
  `sender_mail` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `receiver_mail` varchar(1024) NOT NULL DEFAULT '',
  `body` text NOT NULL DEFAULT '',
  `feuser` int(11) NOT NULL DEFAULT 0,
  `sender_ip` tinytext NOT NULL DEFAULT '',
  `user_agent` text NOT NULL DEFAULT '',
  `time` int(11) NOT NULL DEFAULT 0,
  `form` int(11) NOT NULL DEFAULT 0,
  `answers` int(10) unsigned NOT NULL DEFAULT 0,
  `marketing_referer_domain` text NOT NULL DEFAULT '',
  `marketing_referer` text NOT NULL DEFAULT '',
  `marketing_country` text NOT NULL DEFAULT '',
  `marketing_mobile_device` smallint(5) unsigned NOT NULL DEFAULT 0,
  `marketing_frontend_language` int(11) NOT NULL DEFAULT 0,
  `marketing_browser_language` text NOT NULL DEFAULT '',
  `marketing_page_funnel` text NOT NULL DEFAULT '',
  `spam_factor` varchar(255) NOT NULL DEFAULT '',
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `form` (`form`),
  KEY `feuser` (`feuser`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_mail`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_powermail_domain_model_mail` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_mail` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_mail` VALUES
(1,1,1785917259,1785917259,0,0,0,0,-1,0,NULL,0,'',0,0,0,0,'Daniel Hackiewicz','dhackiewicz@gmail.com','Nachricht über das Kontaktformular','dani@studiothompfister.com','\n	\n		<p>Guten Tag </p>\n<p>Über das Bewerbungsformular auf der Website der Spitex Region Lueg wurde eine neue Bewerbung eingereicht. </p>\n<p>Die übermittelten Angaben finden Sie nachfolgend:</p>\n\n	<table class=\"powermail_all\">\n		\n			\n				\n						\n							\n\n\n\n<tr>\n	<th valign=\"top\" scope=\"row\" style=\"text-align: start;\">\n		<b>Stelle</b>\n	</th>\n	<td valign=\"top\">\n		\n				Spontantbewerbung\n			\n	</td>\n</tr>\n\n						\n					\n			\n		\n			\n				\n						\n							\n\n\n\n<tr>\n	<th valign=\"top\" scope=\"row\" style=\"text-align: start;\">\n		<b>Vorname</b>\n	</th>\n	<td valign=\"top\">\n		\n				Daniel\n			\n	</td>\n</tr>\n\n						\n					\n			\n		\n			\n				\n						\n							\n\n\n\n<tr>\n	<th valign=\"top\" scope=\"row\" style=\"text-align: start;\">\n		<b>Name</b>\n	</th>\n	<td valign=\"top\">\n		\n				Hackiewicz\n			\n	</td>\n</tr>\n\n						\n					\n			\n		\n			\n				\n						\n							\n\n\n\n<tr>\n	<th valign=\"top\" scope=\"row\" style=\"text-align: start;\">\n		<b>Tel</b>\n	</th>\n	<td valign=\"top\">\n		\n				0791999464\n			\n	</td>\n</tr>\n\n						\n					\n			\n		\n			\n				\n						\n							\n\n\n\n<tr>\n	<th valign=\"top\" scope=\"row\" style=\"text-align: start;\">\n		<b>Email</b>\n	</th>\n	<td valign=\"top\">\n		\n				dhackiewicz@gmail.com\n			\n	</td>\n</tr>\n\n						\n					\n			\n		\n			\n				\n						\n							\n\n\n\n<tr>\n	<th valign=\"top\" scope=\"row\" style=\"text-align: start;\">\n		<b>Notiz</b>\n	</th>\n	<td valign=\"top\">\n		\n				guten tag<br />\r\nich hätte Interesse<br />\r\nLG<br />\r\nDani\n			\n	</td>\n</tr>\n\n						\n					\n			\n		\n	</table>\n\n	\n\n	\n\n	<p> </p>\n	<table width=\"500px\">\n		<tr>\n			<th colspan=\"2\" align=\"left\" style=\"font-size: 14px;\">\n				<b>Marketing Informationen</b>\n			</th>\n		</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Referer Domain</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\">lueg.ddev.site</td>\n					\n\n			</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Referer URL</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\">https://lueg.ddev.site/</td>\n					\n\n			</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Land des Besuchers</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\">Country From Ip is disabled.</td>\n					\n\n			</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Besucher benutzt ein mobiles Endgerät</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\"></td>\n					\n\n			</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Webseitensprache</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\">0</td>\n					\n\n			</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Browser Sprache</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\">de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7,fr;q=0.6,it;q=0.5,es;q=0.4</td>\n					\n\n			</tr>\n		\n			<tr valign=\"top\">\n\n				<td style=\"font-size: 12px;\" width=\"50%\">\n					<b>Diese Seitenaufrufe führten zu dieser Mail (pagefunnel)</b>\n				</td>\n\n				\n						<td style=\"font-size: 12px;\" width=\"50%\">\n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/freie-stellen\">Freie Stellen</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/danke-fuer-deine-bewerbung\">Danke für Deine Bewerbung</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a> &gt; \n							\n								<a href=\"https://lueg.ddev.site/\">Lueg</a>\n							\n						</td>\n					\n\n			</tr>\n		\n	</table>\n\n\n',0,'','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36',1785917259,1,6,'lueg.ddev.site','https://lueg.ddev.site/','Country From Ip is disabled.',0,0,'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7,fr;q=0.6,it;q=0.5,es;q=0.4','[1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,3,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,3,1,1,3,1,3,1,3,1,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,12,12,12,12,12,12,12,12,1,1,1,1,1,1,1,1]','0%','');
/*!40000 ALTER TABLE `tx_powermail_domain_model_mail` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_powermail_domain_model_page`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_page` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `form` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `css` varchar(255) NOT NULL DEFAULT '',
  `fields` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent_form` (`form`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_page`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_powermail_domain_model_page` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_page` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_page` VALUES
(1,7,1785847064,1785767961,0,0,0,0,1,0,0,NULL,0,'{\"css\":\"\",\"endtime\":\"\",\"fields\":\"\",\"form\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,1,'Jetzt ganz einfach Kontakt aufnehmen und direkt bewerben','',7,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_page` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `tasktype` longtext DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `description` text DEFAULT NULL,
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `execution_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`execution_details`)),
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `number_of_days` int(11) NOT NULL DEFAULT 0,
  `selected_tables` varchar(4000) DEFAULT '',
  `file_storage` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_backends` longtext DEFAULT NULL,
  `max_file_count` int(10) unsigned NOT NULL DEFAULT 0,
  `ip_mask` int(10) unsigned NOT NULL DEFAULT 2,
  `all_tables` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `color` varchar(7) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-05 10:40:29
