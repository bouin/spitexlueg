-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1785485821,1785485821,0,0,0,0,2,'[]','a79cd3a9ee76cac8502dff95e52fc497a0868ca9','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1785485818,1785485818,0,0,'Editors have access to basic content element and modules in the backend.','pages,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,tt_content,sys_note','Editor','1','1',NULL,0,'1,3,4,7,199,254','pages,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,tt_content,sys_note','sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:alternative,sys_file_reference:autoplay,sys_file_reference:description,sys_file_reference:crop,sys_file_reference:link,sys_file_reference:title,sys_file_collection:hidden,sys_file_collection:sys_language_uid,sys_file_collection:starttime,sys_file_collection:endtime,pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:canonical_link,pages:categories,pages:rowDescription,pages:description,pages:author_email,pages:media,pages:no_follow,pages:layout,pages:no_search,pages:extendToSubpages,pages:no_index,pages:keywords,pages:lastUpdated,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:hidden,pages:sitemap_priority,pages:shortcut_mode,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:twitter_description,pages:twitter_image,pages:twitter_title,pages:doktype,pages:twitter_card,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:hidden,tt_content:imagewidth','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:shortcut,tt_content:CType:list','',NULL,'dashboard,web_layout,page_preview,records,media_management,user_setup',NULL,NULL,'','',NULL,'seo-pagesWithoutMetaDescription'),
(2,0,1785485818,1785485818,0,0,'Advanced Editors have access to all content elements and non administrative modules in the backend.','pages,sys_category,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,fe_groups,fe_users,tt_content,tx_impexp_presets,sys_redirect,sys_note','Advanced Editor','1','1',NULL,0,'1,3,4,6,7,199,254','pages,sys_category,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,fe_groups,fe_users,tt_content,tx_impexp_presets,sys_redirect,sys_note','backend_layout:hidden,backend_layout:icon,sys_category:hidden,sys_category:sys_language_uid,sys_category:starttime,sys_category:endtime,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:alternative,sys_file_reference:autoplay,sys_file_reference:description,sys_file_reference:crop,sys_file_reference:link,sys_file_reference:title,sys_file_collection:hidden,sys_file_collection:sys_language_uid,sys_file_collection:starttime,sys_file_collection:endtime,pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:cache_timeout,pages:cache_tags,pages:canonical_link,pages:categories,pages:sitemap_changefreq,pages:module,pages:rowDescription,pages:description,pages:author_email,pages:media,pages:no_follow,pages:layout,pages:php_tree_stop,pages:no_search,pages:extendToSubpages,pages:no_index,pages:is_siteroot,pages:keywords,pages:lastUpdated,pages:l18n_cfg,pages:mount_pid_ol,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:hidden,pages:sitemap_priority,pages:shortcut_mode,pages:content_from_pid,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:twitter_description,pages:twitter_image,pages:twitter_title,pages:doktype,pages:twitter_card,tt_content:pi_flexform;felogin_login;sDEF;settings.pages,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:uploads_description,tt_content:uploads_type,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:hidden,tt_content:imagewidth,sys_redirect:hitcount,sys_redirect:createdon,sys_redirect:description,sys_redirect:disabled,sys_redirect:force_https,sys_redirect:disable_hitcount,sys_redirect:is_regexp,sys_redirect:keep_query_parameters,sys_redirect:lasthiton,sys_redirect:protected,sys_redirect:respect_query_parameters,sys_redirect:starttime,sys_redirect:target_statuscode,sys_redirect:endtime,fe_users:address,fe_users:city,fe_users:company,fe_users:country,fe_users:email,fe_users:disable,fe_users:fax,fe_users:first_name,fe_users:image,fe_users:lastlogin,fe_users:last_name,fe_users:middle_name,fe_users:name,fe_users:telephone,fe_users:tx_extbase_type,fe_users:felogin_redirectPid,fe_users:starttime,fe_users:endtime,fe_users:title,fe_users:www,fe_users:zip,fe_groups:hidden,fe_groups:felogin_redirectPid,fe_groups:subgroup','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:shortcut,tt_content:CType:list,tt_content:CType:div,tt_content:CType:html,tt_content:CType:form_formframework,tt_content:CType:felogin_login','',NULL,'dashboard,web_layout,page_preview,records,web_FormFormbuilder,content_status,web_info_overview,web_info_translations,media_management,redirects,user_setup,system_log',NULL,NULL,'','',NULL,'seo-pagesWithoutMetaDescription');
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('26ee356a87a518b63b370d547f7d58650aada45cb5d4d9667990f37077d2f7fb','[DISABLED]',2,1785509548,'a:3:{s:26:\"formProtectionSessionToken\";s:64:\"8abb9b40060c9403ff7b28a13465e408504c7527d7866815afb5486a40e51004\";s:23:\"backend.sudo-mode.claim\";s:2:\"[]\";s:23:\"backend.sudo-mode.grant\";s:293:\"{\"route:\\/module\\/system\\/maintenance\":{\"subject\":{\"class\":\"TYPO3\\\\CMS\\\\Backend\\\\Security\\\\SudoMode\\\\Access\\\\RouteAccessSubject\",\"identity\":\"route:\\/module\\/system\\/maintenance\",\"subject\":\"\\/module\\/system\\/maintenance\",\"lifetime\":\"medium\",\"group\":\"systemMaintainer\"},\"expiration\":1785488788}}\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1785485807,1785485807,0,0,0,0,NULL,'a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$TFg0NkZsWmk5aGk4bnFVUA$BGJukUX7cuIsM9jy9vxo77j2/sFDmhpuJXoN97a+9M8','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1785485807,1785485807,0,0,0,0,NULL,'a:16:{s:10:\"moduleData\";a:5:{s:28:\"dashboard/current_dashboard/\";s:40:\"a79cd3a9ee76cac8502dff95e52fc497a0868ca9\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:23:\"backend_user_management\";a:1:{s:13:\"defaultAction\";s:6:\"groups\";}s:10:\"web_layout\";a:3:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:0;}}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:24:\"1:/user_upload/Homepage/\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:5:{s:28:\"dashboard/current_dashboard/\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:23:\"backend_user_management\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:10:\"web_layout\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:16:\"browse_links.php\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";}s:12:\"mfaProviders\";s:0:\"\";s:11:\"colorScheme\";s:4:\"auto\";s:5:\"theme\";s:6:\"modern\";s:11:\"startModule\";s:10:\"web_layout\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:22:\"dateTimeFirstDayOfWeek\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";s:1:\"0\";s:10:\"inlineView\";s:86:\"{\"tt_content\":{\"2\":{\"lueg_podcasts_episodes\":{\"2\":\"\"},\"sys_file_reference\":{\"1\":\"\"}}}}\";}','{\"emailMeAtLogin\":0,\"mfaProviders\":\"\",\"colorScheme\":\"auto\",\"theme\":\"modern\",\"startModule\":\"web_layout\",\"backendTitleFormat\":\"titleFirst\",\"dateTimeFirstDayOfWeek\":\"\",\"titleLen\":\"50\",\"edit_docModuleUpload\":1,\"showHiddenFilesAndFolders\":0,\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":\"0\"}',0,NULL,'','studio_lg','$argon2i$v=19$m=65536,t=16,p=1$VkJwVVZZMDRBeHd2SVo1QQ$DIsREnvDiJqisnICS2cLmLWOk1cGyVsedaL6FQbIz2A','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',1785485820,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'1_9a8a6552b7e8e52d',1817045551,'x�\�}\�r\�H�\�\�nG\�;`8ӱ3k�$\�$-�ǖ\�C۲���=;\�\rF(�p� ZꝈ}���\��}\�wz�}�?�\n A�(\�m�=d\�\�d!++3+\�ˬ\02R\�\�O\�\�\ZuR2�\��\�\�F\�}^\�$qN\��tUS�Qg\�w�^��\�\�\�\�Q��\�.�#�$�\�u\\*?:\�`%\��7|v#�\�\�	\�h�\�)rO\0\�7���e\�>\��L�R;r*�\�4�RF]ɾ���W�$KA��≔\�$\r��\'R�\�\�:��zD\��R�\�Xʒ�9T:�KG$�\"�����NvL�< ax!9��\\���d)e\�\�!\�O\�I$v�0ph��\�\"v\�ړ�?\���\�֚v�\�?��\�p �}Քo�YW:|\�dA���֪q\�ӀI�B\'\�A�iLY\�<���E$�z\\\�؅(ȡ\�4\�z�E�h݄Mz\�\�2\�7\�3\�\�u�ӑ|F��N\�B\�(�{9\�+=�nN\�\�\�\�n\ZO�뛞gC�o�TS4e੦\�]]Ut۰�\�\r�fG�f)���{P�>\�\�(\�d$\�\�ݞ(�F�B]�יPЏ\�	\�H��\�u�E�N:�\�g�EH3�ҼҢR�\�h%8\�nL\�^\�L\�\�}\�u��#E\�\r\�^:�ZǮ7&xg\�#���\�P%�稶����ںB=w`��m\��GA�\�2���\�\�w�50����Ԯ�\�ZwH�āC\�e]B0U\�u\�y\�B�۠\'\�Ѯ���\�\�\�8��\�T�\�\"/�\��\�IBɗ�s\�\�pc2C/�)\���%��e?�hE;�\�u\�\�N?ga\�R��Kr\"\�\�a	tI�?���\�\ZV0�d½��R�x\�\�ul\�M��ؕ�ߍ����ךg�S�8�\�\���\�s�h|r�\�\�\�/㓃�?<�-k����jL\�Ѽ\�t\��\�\�,KB\�ⓖ\�D���\�\�\�\�v-(�\��\�~\�P9\�iR�Ʊ�;�>y�$�6\�?T�=\�\�O\�bn��ծ\�EB>T;�~I��t\�K�Mn&�R�C*�L�\�\�\�+�k�\�j2\�\�\�&sqV/\�npDR\�\�\0q6���ۅ[ �\�d�4\�aƜ�@�3\���BMF\'��\�ov>\�@�e�7�DB@�^Qz\�+r�l��n\�\�uT��Q�{ˬ��\��M�[���KU\Z���;\���D�\�4�_B4�\�\�\�5d�\r�\�ߧ�\�,\�:�\�\�7.\��,1���ߘ�\rq\�P��巏\�y��B=\n=˥�\�\�\�e9xh\�rz\'\�Wi\�SV�\�\��W\�\�7+?*\�2Yv#\��\�+�4\�2dW�[�1@\�\�-Ř\�g��,�jyY�κ��\nY�z�\�J��\�N\���\��J.\�x\�_zV\�^�#ِ`5Y\�W\�r7�V�����KM\�\"\�\�\�r�ē�7\�ZV8>���\�&\�B�B�>&�Ʈ>x9ݑ���\\\�\�F8e#\�8\�<SzA|ui�T\�\�������A,}�\�\�n���~U#�\�\�\"��\�c@C0gG�r�8�\�7/ �\�N�1�xy09��<I?@�I\�p\� �H�KYJPwG\"\��:~B\�\�u|\�Ი�������\�y�\�\�ܑ\�L�@]`�6K \�g9\�t+e\�Hx\�\�_\�K�<\�(\�	��\0<��\0Rv)�\�\�\r0��m�i�\�4p\�\�J9ʮ~\�<4f\�\�_\�?��y��P\�e�\�@g�\�}�&\�q\�i�M\�ņORz	\���\�\�\�h,tX�M���\�b��]7:\�z�i$\�\\��m0�\n)L2�]4+�\�&|�\�3\�6\�(	݆qU��g�\'�A�2�\�\'�A\�Rvy\��\�ݧȸ\�D҃0\�\�;\��\�\�@%C�<�\\K\�3\���m�\�\�\�8�>��\�f�\�5\07A��ġߧ�A\�T:~!�\�\�0 a8��K�\�,o9Yl7qS�\�\�+\�<�f\rIO\�K��\nR�\�R8i\�Q\�,LBs\�Y1?:�\�I\�\�/pnF\�[�\�&ѐ|!M�1a���\�\�I��q+�]\�ɤ\�N&\�\�:}�/�:��\�z�\0\�[\�^\'g0\�MI\�K\�^\�H1$#�-��ב`b�´�v$�\�3P\�)\�\�A\�V�\�U\�6+�O��\�\�te��]\�Uy\�mq��0\�\�\�\�~j\0H.&t\�H\��\Zk�\�R\0G)�0:K�\�[�����\�q\�1S�\�\�HX8!]��M�m�\�n�ii�5�-08����H\���vdU\�\�\������&���\�\�8\r\�E\�@nc�KEI�m\\Z��\�\�ͫ�\\Y�Wo\\gq�s\�6o/���-�e\�g�\�ހ\��s\nF\�<�(\n�����\r{\Z?\�g�\\rSɹX��q��Q{��.�Y\�Nq\�%��n�\�\�\�X\��\�\�q7\�`xp\�!�딿�\�\�\�\�BD\�l\0\�C8\�)�\��\�4`g<,C^\�H�)&eyc��dA?U#r�b.]e\�k�ϯEC���l=\Z\�J8��Fse�\��_ͭ\�\�\ZsoyI��q�E\�[����h�h]C\�\�x80\rS�\\\�\�݈M��u\�^\�\�=op���\"*�\�,\�\�=�\\�\��RLZ�|��^\�(q�\��\�-\"�k\�\�\�\�\�\�|�vҗ����\\�i�0\�ҏ\�6$\'\r\�\�\�\�V�̳\�\\7�u#�¬�\�\�\�\�\�_k\�=�97L�\�\�Д{y\�oݚߵ+~�\�p�����\�\��\Z�>ے_0�/]K�H\\�\�>\�\�_�*ߣ`��+nG4\��R\�$�s\�y(_~\�+\�]\�A�r\�\�y��̗\�\�o�\��\�%�̓�8g��ei\\\�+\�|1�a1�q	\�%G�]}�N�pE>r�\�c\��	\Z�\�C@z�G\�Hp�r\��,\�sɻ��\�~\�W\�q�\���\Z��\�A\�be\�A\0/��7t\��[��\�$\�\�`&�a\��aX4\�e/\�\��F\��c�\�؈��\�\�Z�9\�=`�Kf<f$üV�q\�vem�5�EC\�y2����\\\�z��)X\�\�>ܚ�d\0/DO�.l�c+5 \�\��B�\�0ܔ��)��y\�>���ߊ\�3�f?���\��a\�\�Qq&\�\Z��p�\�\�m\�-Ëc\�50�\�k�q\�\�o\�\�3���[���a����`V&P\�\�\�\�\�@\�mD�\"D\�\�\�-\�1\�\�\�\�)��~�T\�\n�q����\�IqpƏ \�j?(<�³�D��\'626�M\�\�\�\�^f\�)h�g������_�\�\�G�\�\��2/�\�}Ȧ\0P\�?5Z\���fx\�ORU\�{�\�կ��/\�\�K\�,�\�\ru�=��\�2��n�+5�\�n֜ѓ{A,\�\�8\�\�\0��k�i\��	$k.�\\�ǈ�\r}�(!�fJ�0e�[~VD\� q��\�U�\�vy\�*0\�EHL\�\�\00a<�����́t�՗Ȗ\�;\�$��.��\�g#\�\�i�\�bC�cd\�.n�K\"7n\�\�\�PR[�\�xR@P\�\�1�yL�\�\\{\�:[@�>#����\�`Q9!\�B\�]�R\�7\r��g\�8�	�\n\�\�cn���e�ƃob�RHd�+  �����\�\�˚ί5\�y۠\�YW\�\�g\�\��\�\�H��k\�\�?\�Ѻ\��5~*5@o�%.z\����s�w^�r\�\�^\�N�i0\�Y\�1�P�\�T�\�$\�\��\��U2�\�i(�\�\�ј/�\�Pͷo�h\�C��Q�31��Ћ�\�փ\"�\�3\��f��w\�Fw�RH�>\�x��\"ޒpV� \�g>^W�\�׬\�\r^wi�;\�5�#\�\�\�ź�\�\�\��+C\��\�X�U�|�޴\�\�^���_\�\��\�\�n�]_[T�)\Z\�{_�;ֻ�䏛�7�M\�y�S\�x�Zt�a\��,�Aϖ\��f���w\�\�9��k�ع��۶[U\�K�ku[��	.e\�F\�\�c\�\�E*�Q��Kg5\�]�#\�3H\�=\\\\\�ht��+��\�v\�\�͸���bm�O^ϙ0�L?.��3�6\�4$E\��H\�$3䙦tgr͙\Z\�s�<���t\�\0\\�_~\�`�,\rמ��\�x\�(z\�\"\�s\\ae�EH&TJ\�\"�zR))�0\\\�[ -YT�_0\�\�0�)���|�CC�FŔ\�$�\�x*�r\�F��`!)čAJ�/}+�H�m(ن�M8oC\�L��1�$�ē;Jh�z�\�	ޱh\�\�}\"9I�O\nz{a���\�\�\�\�V�u(�ƃ�\�\"�e���\�m�l��\�\���Q &$��,��l;\�\�F��8o#\�L��1B��0�;� �i�ݱ\�\�XHE\�\�\'x�\�9���.M.8\�\�*F��\� gd�\�mpQ��.s���\�6Nl\�\���qb�\�\�\'\��L\"%\�,\rI~y\�b\�s�\�-�q1�=�\��3Nr��Y�0�\��|�+�ۄ\�)K|g\�K\�\�\�\�OC��OR�9\�\�n\���\�s\�F��\Z_c��\�3�\�-d9ą��\�tT�\�6\'g�|\�\�0\�\��r.\��\�/���.ou�\�ˀ�|f�\r\� �\�m��\�5�;}\�\�I�\�w�J��s���X\�H�\r\�3��74��S~B��\�=\�	\�\'�\�3�\�#�ݵb�\r\�\0�\�m���\�5���\�\�F�.�c\��:ˇ\�\��٭�\�V�\\*bLV��$\��|�y��!��\�L8/�А�[\�ߢ�F��\�?S\�kD��~�5J\� rB\�;�M[\\x?B^}����xh|<{\\=�]�$n�\0\�-�OIh\�\���N�ؿ\��\r8o��\�׈�w;\�̎\�\�1\�4�\�1KR�\"$\�o\�,*n\'\�_s	\�ݹ�@��=d|>P0H�qVp\�ή>\���,#AH,N�nC�6l�y\nfj�\�B�M\�\�\�\���\�K��M^\�\�ܶ�\�\��\�W~&$ЇA|YL��\�)�͏�)\"X撢HO(>�sq\�0���(�T\���\��\�`8M|0\��9��\"�@\���S�;\�\�B<\�&$2\�6\�\�-:Gx\�?|Q\�\0Q�&\�@�\�3C\�v�\�3�\�\�7��5<�\�2�\�!=��9<�\�`8�\�8\�ǿ1�\�u\�M����,]���\�;�\�o\�T��v\�ǽF.�<\�\�\r�\�b<y.ޅ@��\"kq�\�DkQ�:\�r\�8�K\�L\�\� \�fH�|$)Vw`~{�:(\��\�o\�w\�_>Vܞ�\nB-�-�\��݁1c�v-Y����Obk\��C�b�]\�\�l���e\� �\�\nW_pֆ]KGΏ��!P�$\�?��ju�b�[]u���\� ��&�nt����\�U\���\�4\�t\��x\��\�\��{\�\�\\\�\"�I\�~&\�0\��\�\�~}\��d��x��\�\�\��ZfWՐ\�)\�z?Mf�\�U\�\�aW\�\�\��\�\�O\�e\�Ufn=\0{p�~J2�l\�݇�.�&>\�\�p]�̥H�x�O�Vm\�\Z8bW��g\�u)\�?\�\�KG�8��\�XIGy��$�,����\�\r$]\�,U�g~\�`Gѻ�ӗU\�2/\�]ݐ���\�fW�7S���n�c\0e�)�\�-\�W\�OW@\��)\�\�\�\��\���kw�;Fw�\��0v��j�Ou\0C۱\0\�\�\�3\�_.\�\n\�5\��\�t}e\0z|��\�tX<\�\�n_ɠMHؚ&�\�\�\rb�0@� ԰kgK� [c\�,kg\�\�\�C� ��\Z\n�z�\n�\�2\�jhK44�\�\�\�\0�)h E\���2(�Ͽqi����Q\��\�oL�\n\�\�R\�/f�\r��I.S�^�\�z��-.<C��o\��˺1�\�A-\�j �\�\�Ƴ\\`\�\�[7��n��JJ-aB��΍\�7\�\�օ�.���>�a���Yg\��wúĜ\�ҖȌ\���[R\�\���\�eo2�\�\�7�-|�(�]�i\��\�\�\�cJf����)\�|a\�\�\�3��6��6�b�]p�)�n@\�\�\�p��/�,MLV��ꯩ#�!M]�F)O�\�xh�\�\�\�M�\�׏J���އN��ćf��\�5tŚ�.~=]U�\\�\\�|\�U\�F��\�\�o-|��\��r)/�<�g\Z�S\n���b��k3\�\�_�\�tS�IA\�p�WV٠\�Y$�Qo�\�\�y��z�\�tڝ$\�$�]\'�p�-�\�o{\�\�\�S\� \�\�έ+2�*׽`l�	oB:\�\�\�#\�1�\�.nL@o\�l\�i�`m��1D�[��c9����I�\�r�|̒8\���O^�ձ�8��j��v�\�N�<N\�V\'o+�;\�\'%�9J\Zz]�/��sI\�\�P�{��\�b\�o#�-F\�1�����\�HZ�\�8\�\�y�9(ϳJ�&\�z\�Ԭ�\"ۚ>\�,b�\�E5�\��\�?$þ7T\�[ә����\�\�rNu��)\�\��p�\�\�`jM�{�z%�W\�-���PUߢ\�CU�ȷQM\�;\�\�\�\�2�\��e\�t�b\�n�����:1�\�JR�������\�V�\Z�\ZR}\��\� \�8\�4\�T\�^\�	[<�\�x�z\�j\�_\�\�v���\��]<�KY\�w\�W�N_wsq|4$A\�r���i:\�Z;\��J�=�\�\�Uo��^<\�\�rά]L�\�\'\�DP��5a��|z����\�\0|�\�ڌ8��uA\�[\�?\���f6��8�6}h-���\���\��\�ۇ��\n$\�\�\�fA\�\�\nm�5�\�?\��~O\�:!�l|\�D�\�\�`�\�J�\�\�$瘋\�z�}�*������)g�!�҉�_�hd�f�Od*a5�\�螮h�n\��>Xo��\�����~#&l\�\�r�\'��T\�\�e��Ť\����\�\�\�\�6=�\�tR���6iܸk��E7�Ô\�\�k\�)�\�Z\n��Y\�l\�\�	\�o�\�\�L<i[j$�ηU�w\�Jy�d9�4��`�\�k��C���o��\�ɍ\0+4ޠ����!��pq�5u���F��\Z|Y\�u��}�h�B̳\�k�\�n\�\�\r2dP�G�\�+�v{�߲G\��ی`�,{\��>\'Y�I\�Y_aY�vq\�\��>T����)�\�{լ\�e�\���\�\�\�0�\��_3�i~S<tЁy\�{rNN8�I\�:���F��\nF�[ \�CF\�)1݁\��̒�<\n\�;\�����:\�(O������p���\�M\��\'xu\�y\�\�4�!C\�>\�G?�jF�z\�5ޓ\�(;)\�2�2�>\�֠�\�Qc\�w�oPs蒾2\�\�\�6T�o\�k�WNr.��iЦ6J\�\�\�\�c�DO�KbO�\�\"��o��P\�u\�\�!`���F\ZT8��\�W\�ۃ���	�o_\�\�\��\�\\ ~\�\�\�B\�\�Q\��ퟪ\�\�ڨ\�c�\�WH<)@ȃ\�]�n-\\�\�/\����r\�.DM^\�/\�]zB+ځ(]p����{�\���)�ځ\�{\�\�\���\�1LJ�y\��X\�\"�kE�\�ɖ\�,^X*h4y53*2\�E;\�nL\�^\�L\�\�}ׅ:��W\0%qJ\�{|Ӻ@:\�0\ZvJk\�\�9�O\�\Z\�\�\�\�|�.\� �)KE\�ߡJU\�K�C_ŧIZ9�ū�a$��B�fi\�``^u\��\�\� Ƅ��=Ă�Br�_ԛ\�\�Ò,KX0	\��1\'�y\��\�k}\�\�E�QZ���$!�GΟ\�\� �]T[]�+xf��\�\�g7�\'\�\�M\�3��ڷT�)�2\�\0�����n1��Cu\�䭂B\�\�\�\�d\� v%N5�ѯv\�\�\���Cize���޼\�0��x?\�#\�v�\\\�\�b��\���p�0\�./\��\�ݞ�R\Z��S\�o	G\���]Rq\"��_!�\�\�L=�/!2��\�\�\��2\�a�\�y\�L�N\�\�X*1�\�Ⱆ�\�*\�:ߪ\�xCY\�J���\�a�\\�\� \n�\�������\�S�\�\�r\�`\�\�\�OF p�\��(�@�\�k�%xx\�;f�9\�\�NˊPR\�.ڋS�\�%$��l�և�\�H�\rs/\0�\�!\Zf���;qN\�\�+\�\�>��U	�5\r\�\n\�82���J�J\�ÿ��P\�^M\�\���,���o�KfK��R.�\�\����MB��$^\�fuA\�#G�\��Z��PGY��\'�G+%V��\�K�\��O��7\�\�`\0\\\��qHШ�UAsϛ~\��3��v��{\�v)�᥷\�\��;\�h�\�!�x�\�}\Z�#\n�S8\�\��\0�J\�\�\�L���\��\�zOWV\�<\�\��Z~?\"1��	\\#e	\�\�\�\�����잢\�\�$�PH\�I�T�h�\��Y\�Sް\rW�\�\�\�u�.\�	Mfr�����cݭ6��S�ّ\�ޘ\�j\�Sq}��	��q�{	<q=�7T9ܸ���\�\����\�?\�Ҡ�H��@�\n	��~\r\�\�8ZB*�\�9\�	\�m�O�(D\�U\�D$��6j[\�\�z_\�?9~vz��\�\��\��ʖ5V\�\�@��\�h?��L\�\�`����W�U�\r\'F\Zl\�0\\�\��x/\�\��rp1k�E�ϡ�0{\�v\�xQ1C\�\�51\�\�65,��!�\�cͳ��P�Xe;�#ۭmz\�\\�\�z\rUA\r\�;\�*�?B7s��E^�\'c���rߒ5e\\Dc��V�\�p`\Z�b���)\�f&\�J�f�\�i­�W3\�5�`y/�\�}�٩ۺ�M���\�6\�o\���:\�?Y�u\�\�EE\�\�SZ\�\�\�0\�u\�!]i?\�F\�\�T�U~�b\�XPW��|����\��\�\�\�\�֊z3g�(q�\�*\�J�|QS]\�{�!zo\�*үs.\�\�}hި?A\�?��\�Г_\�l\�\�\�\'|�u�\�\�w�.�ZhORf�J}�WOK�jݘ\�\�\�uI�R��-\�s��\�\�|\�l�\�ns\�m.�\�e��\�6�\�\�\�\\v�\��#\�n��\�~\�q|:[�\����\�\�k\�$̝�>f\�y\�R�}���\���Z\�\�s\�O\�\Z<uOAP3Jk2�R��\�\��9u�J�A\�\'ЗՆ\�h\�\��~}���}����Ui�G\�\�\�\"�\�S�U�L��D:-g̑iH�\�\�?;�OTÔ�\Z���^\�\�ǯ\�a\��\�\�\�\�\�Æ	;}\�{�\�m\�o}/|8x\�\�h�\�_;�r���\�M_�?(\�\�$�\�v\�m��O&�Γ\�oGֻ\�\��r\�\�H̓g�	��\�?D\��˦[b@\�}4m6V�\�\�\�\�}M��\�leV�\�\�\��\�Vm8\�\�rD�\�\�*��\�\Z���\�:�[�\����5�t\�*,��\��k\������.W�x�\�ZM\\ח�q�����n.W\n\'o�&�s�(\�\�\�\�r��\�o\�@N�\�W*��W\�+\nu�\"\�bUk�(\���\�Ϊ\�^Q�+�\�T��� X5\�\"u�q8��j\�I\�\Z\��U\�p�\�\�G�\Zg�\�\�G�\Z�;��\�8�`\�8�\�\�\���qT޿z�qJ�\�\�\�v\�+C����)q\�1�\0UT��\�\�i�\�bT(V_70��\�#}CW=�:�m\�\�<}�8C\�\�,w�\�MO黖m8�5�,�\�w`�}�\�Π�C\�\�C\�\��gj���Ё�Q�C����\01\�|');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_9a8a6552b7e8e52d','pages_1'),
(2,'1_9a8a6552b7e8e52d','sys_file_1'),
(3,'1_9a8a6552b7e8e52d','sys_file_metadata_1'),
(4,'1_9a8a6552b7e8e52d','tt_content_1'),
(5,'1_9a8a6552b7e8e52d','tt_content_2'),
(6,'1_9a8a6552b7e8e52d','tt_content_3'),
(7,'1_9a8a6552b7e8e52d','tt_content_4'),
(8,'1_9a8a6552b7e8e52d','tt_content_5'),
(9,'1_9a8a6552b7e8e52d','sys_file_6'),
(10,'1_9a8a6552b7e8e52d','sys_file_metadata_6'),
(11,'1_9a8a6552b7e8e52d','sys_file_3'),
(12,'1_9a8a6552b7e8e52d','sys_file_metadata_3'),
(13,'1_9a8a6552b7e8e52d','sys_file_7'),
(14,'1_9a8a6552b7e8e52d','sys_file_metadata_7'),
(15,'1_9a8a6552b7e8e52d','sys_file_4'),
(16,'1_9a8a6552b7e8e52d','sys_file_metadata_4'),
(17,'1_9a8a6552b7e8e52d','sys_file_9'),
(18,'1_9a8a6552b7e8e52d','sys_file_metadata_9'),
(19,'1_9a8a6552b7e8e52d','sys_file_10'),
(20,'1_9a8a6552b7e8e52d','sys_file_metadata_10'),
(21,'1_9a8a6552b7e8e52d','sys_file_11'),
(22,'1_9a8a6552b7e8e52d','sys_file_metadata_11'),
(23,'1_9a8a6552b7e8e52d','sys_file_12'),
(24,'1_9a8a6552b7e8e52d','sys_file_metadata_12'),
(25,'1_9a8a6552b7e8e52d','sys_file_13'),
(26,'1_9a8a6552b7e8e52d','sys_file_metadata_13'),
(27,'1_9a8a6552b7e8e52d','sys_file_14'),
(28,'1_9a8a6552b7e8e52d','sys_file_metadata_14'),
(29,'1_9a8a6552b7e8e52d','sys_file_15'),
(30,'1_9a8a6552b7e8e52d','sys_file_metadata_15'),
(31,'1_9a8a6552b7e8e52d','sys_file_16'),
(32,'1_9a8a6552b7e8e52d','sys_file_metadata_16'),
(33,'1_9a8a6552b7e8e52d','sys_file_17'),
(34,'1_9a8a6552b7e8e52d','sys_file_metadata_17'),
(35,'1_9a8a6552b7e8e52d','sys_file_18'),
(36,'1_9a8a6552b7e8e52d','sys_file_metadata_18'),
(37,'1_9a8a6552b7e8e52d','sys_file_19'),
(38,'1_9a8a6552b7e8e52d','sys_file_metadata_19'),
(39,'1_9a8a6552b7e8e52d','sys_file_21'),
(40,'1_9a8a6552b7e8e52d','sys_file_metadata_21'),
(41,'1_9a8a6552b7e8e52d','sys_file_22'),
(42,'1_9a8a6552b7e8e52d','sys_file_metadata_22'),
(43,'1_9a8a6552b7e8e52d','sys_file_20'),
(44,'1_9a8a6552b7e8e52d','sys_file_metadata_20'),
(45,'1_9a8a6552b7e8e52d','sys_file_8'),
(46,'1_9a8a6552b7e8e52d','sys_file_metadata_8'),
(47,'1_9a8a6552b7e8e52d','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_0_0',1788101551,'x�uUK�\�(�/:o\�\nK�e\�ڤ��T.�\�Da@2eIh�횚��m\��\'7�kh��5\��K��P�\�\�w��M�g/��Y\Z����ř5�\�\�\�\�U�\�\�9\rӜZ5\��\�k\�\�p\�E\'�H��$\�b�g`U[+{0x&�\"5\�\ZAZ�&�ހ\�Y���Fi+�6\\D%δ�|�i9Z�ࣟ΀\�\�v��\�U\�\�\�\�\�\�N�dZ�E\�C�\�T��>�FM�E\�P`;g\��!�<\�eӄ\�\�qY}\�^L\r�l3�ed\�h��\�zi�\'�\�3=��C���!9\�\�MM\�3�\�jI\'ބ\�(;	bikV2�7Z`tP�d�#�\�S��\�I�UO\�0�<ɬ\�\�\�Fᄘc\'�\":\�\n\���:L\��\�}\�\�0��!FZ��\�^�\�\��4\�W;T�5>g5\�\�x\�:�%!=�A�Q\�\�.\����d�\� �˯��4�4�\�\�%�r\�\�\Z%#�f\'\'��<e0\�C�QJ~\ZO#�Zh5:\�eg\�������#a\'\�W\�h\�\�\Z�TZڛG�\�\'j�.\'N\�\�(\�Zᓖ\�i��Q\�\�\�S�A�D�h\�#s�n�7�U2fy\0/f=|\�\�\�	\�.\�hJ\�ސ\���*>\�\��\�\��-�7�ܿ㛝d�\�D\�\�Q\�[��ÿ\�\�\�\�\�\�����\�k��*ߗ\�\����l�)\�<\r\�B���@�:4g��\�Q\\GEnS���\�c8\�\���<I�\���]m\�|�c�?\�m\�\��\�y�\�\�\�=���M�ʠZ-x\0\�\r\0�c|?��\�Od����\�b�\�\�\�.!�\�\�3\�\�aͤ� 3�\'����$|-\�]���ؾG\�!���\0!�AD�s\�ExŰaw\�\r1�_IL�\��\n\�\�\���|�f�\�Q1[�tU�H\�\�\�}XPa��\�\�\���N\�o�\�\�\�\����y�kJ`e\�M\\<T`�\�uO�-\�|�ƟQm�\�?�\�\�\'�\�\�O�D(l\�\�m\�5�&�=���\�l�\�x\�+V�����h��U��j[���2oo�%\�\�~_�G�)\�\��v_�eMi^4l�JNs�eeU5B\���8\�j�\�\������mD\��CG[');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_ausbildung_items`
--

DROP TABLE IF EXISTS `lueg_ausbildung_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_ausbildung_items` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_ausbildung_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_ausbildung_items` WRITE;
/*!40000 ALTER TABLE `lueg_ausbildung_items` DISABLE KEYS */;
INSERT INTO `lueg_ausbildung_items` VALUES
(1,1,1785502894,1785502894,0,0,0,0,'0',1,0,0,0,0,NULL,NULL,0,0,0,0,'Voraussetzungen FaGe','<p><strong>Voraussetzungen FaGe Lehre</strong></p><ul><li>Abgeschlossene obligatorische Schulzeit</li><li>Einfühlungsvermögen und Freude an der Kommunikation</li><li>Aufmerksamkeit und Sorgfalt</li><li>Verantwortungsbewusstsein</li></ul><p><strong>Voraussetzungen FaGe E (verkürzte Lehre für Erwachsene)</strong></p><ul><li>Mindestens 22 Jahre alt</li><li>Mindestens 2 Jahre zu 60 Prozent im Berufsfeld Pflege gearbeitet</li><li>Gute Deutschkenntnisse</li></ul>',3),
(2,1,1785502894,1785502894,0,0,0,0,'0',2,0,0,0,0,NULL,NULL,0,0,0,0,'Berufswahlpraktikum','<p><strong>Pflege – mein Beruf?</strong></p><p>Wenn du gerne mit und für Menschen arbeitest, könnte ein Pflegeberuf genau das Richtige für dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah.</p>',3),
(3,1,1785502894,1785502894,0,0,0,0,'0',3,0,0,0,0,NULL,NULL,0,0,0,0,'Weiterbildung','<p>Wir unterstützen dich bei deiner fachlichen und persönlichen Weiterentwicklung – mit internen Angeboten und externen Kursen.</p>',3);
/*!40000 ALTER TABLE `lueg_ausbildung_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_benefits_tiles`
--

DROP TABLE IF EXISTS `lueg_benefits_tiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_benefits_tiles` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `color` varchar(255) NOT NULL DEFAULT 'sky',
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_benefits_tiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_benefits_tiles` WRITE;
/*!40000 ALTER TABLE `lueg_benefits_tiles` DISABLE KEYS */;
INSERT INTO `lueg_benefits_tiles` VALUES
(1,1,1785503682,1785503461,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'sky',1,'Weiterbildungen','<p>Dein Wissen, unsere Unterstützung – profitiere von internen Weiterbildungen und Entwicklungschancen.</p>',4),
(2,1,1785503682,1785503461,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'purple',1,'Kinderzulage plus / familienfreundlich','<p>Wir unterstützen dich mit einer zusätzlichen Betreuungszulage und 16 Wochen Mutterschaftsurlaub bei 100 % Lohn.</p>',4),
(3,1,1785503682,1785503461,0,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'orange',1,'Win a colleague','<p>Wenn deine Empfehlung zu einer Anstellung führt, bekommst du eine Prämie von 1000 Franken.</p>',4),
(4,1,1785503682,1785503461,0,0,0,0,'0',4,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'pink',1,'Fitnessabo / Sportverein','<p>Wir unterstützen deine Gesundheit mit einem Beitrag an ein Fitnessabo oder einen Sportverein.</p>',4),
(5,1,1785503682,1785503461,0,0,0,0,'0',5,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'orange',1,'Kostenlose Parkmöglichkeiten','<p>Stressfrei ankommen – wir stellen dir kostenfreie Parkplätze zur Verfügung.</p>',4),
(6,1,1785503682,1785503461,0,0,0,0,'0',6,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'pink',1,'Mitgestaltung','<p>Wirke aktiv mit – setz deine Fähigkeiten bei uns gezielt ein.</p>',4),
(7,1,1785503682,1785503461,0,0,0,0,'0',7,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'sky',1,'Coaching Angebot','<p>Bei uns kannst du von bis zu 3 Coaching-Gesprächen profitieren – wir übernehmen die Kosten.</p>',4),
(8,1,1785503682,1785503461,0,0,0,0,'0',8,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'teal',1,'Team-Events','<p>An unser Sommerfest und die Team-Events bist du herzlich eingeladen.</p>',4),
(9,1,1785503682,1785503461,0,0,0,0,'0',9,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'purple',1,'Beitrag zur Mobilität','<p>Unseren Lernenden bezahlen wir das Halbtax-Abo.</p>',4),
(10,1,1785503682,1785503461,0,0,0,0,'0',10,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'teal',1,'Grippe-Prophylaxe','<p>Wir sorgen dafür, dass du gesund durch die Erkältungssaison kommst.</p>',4);
/*!40000 ALTER TABLE `lueg_benefits_tiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_podcasts_episodes`
--

DROP TABLE IF EXISTS `lueg_podcasts_episodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_podcasts_episodes` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `claim` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `mediafile` int(10) unsigned NOT NULL DEFAULT 0,
  `poster` int(10) unsigned NOT NULL DEFAULT 0,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_podcasts_episodes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_podcasts_episodes` WRITE;
/*!40000 ALTER TABLE `lueg_podcasts_episodes` DISABLE KEYS */;
INSERT INTO `lueg_podcasts_episodes` VALUES
(1,1,1785498866,1785497882,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"claim\":\"\",\"description\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"mediafile\":\"\",\"poster\":\"\",\"starttime\":\"\"}',0,0,0,0,'Starte dort, wo du wirklich gebraucht wirst','Lernende bei der Spitex Region Lueg',1,1,2),
(2,1,1785498866,1785497882,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"claim\":\"\",\"description\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"mediafile\":\"\",\"poster\":\"\",\"starttime\":\"\"}',0,0,0,0,'Jeder Tag bringt eine neue Geschichte','Pflegefachfrau bei der Spitex Region Lueg',1,1,2);
/*!40000 ALTER TABLE `lueg_podcasts_episodes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1785490041,1785486308,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1785509487,0,0,0,0,0.5,1,'Lueg','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',1,1,0,'',0,'pagets__default','pagets__default','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1785491662,1785491657,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Podcasts','/podcasts',NULL,0,0,0,0,'',0,'','','Podcasts',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(3,1,1785491694,1785491690,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Freie Stellen','/freie',NULL,0,0,0,0,'',0,'','','freie-stellen',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(4,1,1785491743,1785491709,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Benefits','/benefits',NULL,0,0,0,0,'',0,'','','Benefits',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(5,1,1785491741,1785491735,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Direkt bewerben','/direkt-bewerben',NULL,0,0,0,0,'',0,'','','Direkt-bewerben',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(6,1,1785491933,1785491929,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Standorte Spitex Region Lueg','/standorte-spitex-region-lueg',NULL,0,0,0,0,'',0,'','','Standorte',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(7,1,1785491945,1785491942,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Storage','/storage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1785490037,1785490037,'/user_upload/SPITEX_SCHUH-77_2.jpg','b4cc8c1f1d5021cb2c14d7c3ae3c7ece78f40992','19669f1e02c2f16705ec7587044c66443be70725','jpg','SPITEX_SCHUH-77_2.jpg','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba',1785490037,1785490037,1020742,1,2,'image/jpeg',0,0),
(3,0,1785497882,1785497882,'/user_upload/podcast-demo-1.wav','59783830b95b9a1f74761adb88a21446627000f0','19669f1e02c2f16705ec7587044c66443be70725','wav','podcast-demo-1.wav','21724154088ac378f569066f57f4d8bd0c148fba',1785497849,1785497849,24044,1,3,'audio/x-wav',0,0),
(4,0,1785497882,1785497882,'/user_upload/podcast-demo-2.wav','7d8695ea9705d31aede3c5812b9ceca1986d40f3','19669f1e02c2f16705ec7587044c66443be70725','wav','podcast-demo-2.wav','4e121e877971d9cd60c98587b23c07b761025e50',1785497849,1785497849,24044,1,3,'audio/x-wav',0,0),
(5,0,1785498501,1785498501,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1785485715,1785485715,0,1,5,'application/x-empty',0,0),
(6,0,1785498521,1785498521,'/user_upload/podcasts/test.jpg','fced536a20ee4b1227b4c33bf2dd73958ca52a23','139c5f340a12ff6d76b8a7fb5f8d88f9e172df9d','jpg','test.jpg','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd',1785498521,1785498521,2944890,1,2,'image/jpeg',0,0),
(7,0,1785498691,1785498691,'/user_upload/Bildschirmfoto_2026-07-31_um_13.51.25.png','a0ee235bbe3ae1a02d1ec17bb2678e3f676910a5','19669f1e02c2f16705ec7587044c66443be70725','png','Bildschirmfoto_2026-07-31_um_13.51.25.png','6533ff2478b8f1307b2d80356159ecd843b89473',1785498691,1785498691,11892016,1,2,'image/png',0,0),
(8,0,1785501118,1785501118,'/favicon/spitex-favicon.png','0238aee2076656b4b28a527cbc1d5363c0216236','d250a708fb312b9f6db43a2eadf8a1882a93e725','png','spitex-favicon.png','06ff5592072e31318f265c9d4214b57a6f8ce456',1785501104,1785501013,12948,1,2,'image/png',0,0),
(9,0,1785504207,1785504207,'/user_upload/icons/weiterbildung.svg','93ebf22f8b1552eadbeae5ba39e8c931665d6f3f','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','weiterbildung.svg','7a28e1ed9045367999a439d25167b239cd00ab2c',1785504180,1785504180,308,1,2,'image/svg+xml',0,0),
(10,0,1785504207,1785504207,'/user_upload/icons/familie.svg','e9b3709258564ac1ad111b7b32955e1d514725fe','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','familie.svg','0991f88b7af9bcfb4388cf019221ad06ac289292',1785504180,1785504180,385,1,2,'image/svg+xml',0,0),
(11,0,1785504207,1785504207,'/user_upload/icons/empfehlung.svg','7936f8659e5337add9b2b839da548204ccffc3c6','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','empfehlung.svg','44589e3facf2ccbc74d9b01316e15407ecae4f26',1785504180,1785504180,289,1,2,'image/svg+xml',0,0),
(12,0,1785504207,1785504207,'/user_upload/icons/fitness.svg','826e70d2f51d07839554791f46666146dfe56539','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','fitness.svg','da4787f47f240e24917b311cb1c1498cb6320127',1785504180,1785504180,353,1,2,'image/svg+xml',0,0),
(13,0,1785504207,1785504207,'/user_upload/icons/parkplatz.svg','a3d2d221a192321d9d738206970f768d172d5a1c','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','parkplatz.svg','448587010e8a0b1b95f2b6851b5adf698bd85354',1785504180,1785504180,264,1,2,'image/svg+xml',0,0),
(14,0,1785504207,1785504207,'/user_upload/icons/mitgestaltung.svg','1c425761bb407c195c41c6a49349addcf3f50f3e','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','mitgestaltung.svg','4be54d2dccd5e4d9d01665b9485a481ff5e9503d',1785504180,1785504180,281,1,2,'image/svg+xml',0,0),
(15,0,1785504207,1785504207,'/user_upload/icons/coaching.svg','e5d368012dd9f9d23e7fd5f7e0e2b374c1dd10e6','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','coaching.svg','32ef701922af80da8b5adbe2d08190edd38eac1e',1785504180,1785504180,319,1,2,'image/svg+xml',0,0),
(16,0,1785504207,1785504207,'/user_upload/icons/team.svg','c81ad786e3d01bf9c7bb1a24ff338c6a0a0e1cc8','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','team.svg','a71039589805fbb93729c8bfd6460fea3417b6de',1785504180,1785504180,348,1,2,'image/svg+xml',0,0),
(17,0,1785504207,1785504207,'/user_upload/icons/mobilitaet.svg','ad4648537cebb3f21d9f1a00a83373ea8d4c5b33','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','mobilitaet.svg','5c39a033c64954eedb882c92a417e8b56fee16e1',1785504180,1785504180,337,1,2,'image/svg+xml',0,0),
(18,0,1785504207,1785504207,'/user_upload/icons/gesundheit.svg','43820fc67a2b21f7ba91c1871765d31e89ec2119','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','gesundheit.svg','05fa4f036d55081fb5c94fd157514a90482f5e34',1785504180,1785504180,243,1,2,'image/svg+xml',0,0),
(19,0,1785509214,1785509214,'/user_upload/Homepage/standort-weier.jpg','2c2bae590285de1ca51e5a93126a27fbe1ee8eb3','c3bc98602796440503b991e8b2595fcaa67ff01c','jpg','standort-weier.jpg','e50628414c2574017711e28be06fe7fb7a2cbc9d',1785509214,1785509214,467637,1,2,'image/jpeg',0,0),
(20,0,1785509265,1785509265,'/user_upload/spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp','0c542d7bb9972623ea5f3f90a426136c5e8c0b35','19669f1e02c2f16705ec7587044c66443be70725','webp','spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp','a3c86044ef4a40ce9fccc13fd56b6323544a1eca',1785509265,1785509265,118238,1,2,'image/webp',0,0),
(21,0,1785509423,1785509423,'/user_upload/Homepage/Frontbild_SR_2.webp','c2157ed9b6bf4fa50f5f1a969d7ae1be031b2ebc','c3bc98602796440503b991e8b2595fcaa67ff01c','webp','Frontbild_SR_2.webp','9c563176a47dedebeec108e29fc9b8ae8127403b',1785509423,1785509423,557084,1,2,'image/webp',0,0),
(22,0,1785509465,1785509465,'/user_upload/Homepage/spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp','1e66f18230dda608781cc6a6a270d2ac42006b0e','c3bc98602796440503b991e8b2595fcaa67ff01c','webp','spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp','dfe424e51de593e0765291a0266432375413a938',1785509465,1785509465,269444,1,2,'image/webp',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1785490037,1785490037,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,2280,1895),
(2,0,1785490085,1785490085,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1800,1000),
(3,0,1785497882,1785497882,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,0,0),
(4,0,1785497882,1785497882,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,0,0),
(5,0,1785498501,1785498501,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,0,0),
(6,0,1785498521,1785498521,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,3364,2020),
(7,0,1785498691,1785498691,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,3308,2184),
(8,0,1785501117,1785501117,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,439,439),
(9,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,48,48),
(10,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,10,NULL,48,48),
(11,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,48,48),
(12,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,12,NULL,48,48),
(13,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,13,NULL,48,48),
(14,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,14,NULL,48,48),
(15,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,15,NULL,48,48),
(16,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,16,NULL,48,48),
(17,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,17,NULL,48,48),
(18,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,18,NULL,48,48),
(19,0,1785509214,1785509214,0,0,NULL,'',0,0,0,0,NULL,NULL,0,19,NULL,1126,751),
(20,0,1785509265,1785509265,0,0,NULL,'',0,0,0,0,NULL,NULL,0,20,NULL,1126,751),
(21,0,1785509423,1785509423,0,0,NULL,'',0,0,0,0,NULL,NULL,0,21,NULL,2500,1395),
(22,0,1785509465,1785509465,0,0,NULL,'',0,0,0,0,NULL,NULL,0,22,NULL,1126,751);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1785490037,1785490037,1,1,'/_processed_/f/c/preview_SPITEX_SCHUH-77_2_2658161611.jpg','preview_SPITEX_SCHUH-77_2_2658161611.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.Preview','2658161611',64,53),
(2,1785490037,1785490037,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_6788af91eb.jpg','csm_SPITEX_SCHUH-77_2_6788af91eb.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','6788af91eb',180,150),
(3,1785498413,1785490037,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_14e7b14a64.jpg','csm_SPITEX_SCHUH-77_2_14e7b14a64.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','14e7b14a64',54,45),
(4,1785490401,1785490401,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2200;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','037fdf9c54df759f107ca49571c860f676dae8ae','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','7a3f4201ba',0,0),
(5,1785490802,1785490802,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8efa321b15bcada168a023d7550b15722242377b','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','8c66315667',0,0),
(6,1785491944,1785491944,1,2,'/_processed_/e/a/csm_hero-lueg_44575b8025.jpg','csm_hero-lueg_44575b8025.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1125c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d4e0b8fa4fe9062871db4f91cbb6b796b64c82fa','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','44575b8025',2000,1125),
(7,1785492221,1785492221,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_e56555b5fb.jpg','csm_SPITEX_SCHUH-77_2_e56555b5fb.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1125c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d4e0b8fa4fe9062871db4f91cbb6b796b64c82fa','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','e56555b5fb',2000,1125),
(8,1785492402,1785492402,1,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8efa321b15bcada168a023d7550b15722242377b','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','b846968f07',0,0),
(9,1785497884,1785497884,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_aadbe5e607.jpg','csm_SPITEX_SCHUH-77_2_aadbe5e607.jpg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','aadbe5e607',1600,1330),
(10,1785498413,1785498413,1,3,'',NULL,'','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','21724154088ac378f569066f57f4d8bd0c148fba','Image.CropScaleMask','45e5f21ca1',0,0),
(11,1785498501,1785498501,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_51fcfddad2.jpg','csm_SPITEX_SCHUH-77_2_51fcfddad2.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','51fcfddad2',138,115),
(12,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_02943daaa8.jpg','csm_test_02943daaa8.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','02943daaa8',166,100),
(13,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_62f470d34a.jpg','csm_test_62f470d34a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','62f470d34a',250,150),
(14,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_506fc9ef25.jpg','csm_test_506fc9ef25.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','506fc9ef25',60,36),
(15,1785498533,1785498533,1,6,'/_processed_/9/8/csm_test_f8739afa84.jpg','csm_test_f8739afa84.jpg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','f8739afa84',1600,961),
(16,1785498626,1785498626,1,4,'',NULL,'','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','4e121e877971d9cd60c98587b23c07b761025e50','Image.CropScaleMask','f2bac3877a',0,0),
(17,1785498691,1785498691,1,7,'/_processed_/7/8/preview_Bildschirmfoto_2026-07-31_um_13.51.25_caa660e4e3.png','preview_Bildschirmfoto_2026-07-31_um_13.51.25_caa660e4e3.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','6533ff2478b8f1307b2d80356159ecd843b89473','Image.Preview','caa660e4e3',64,42),
(18,1785498691,1785498691,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_22508f7cf5.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_22508f7cf5.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','22508f7cf5',227,150),
(19,1785498691,1785498691,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_353f7372ba.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_353f7372ba.png','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','353f7372ba',60,40),
(20,1785498694,1785498694,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_175e08d87a.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_175e08d87a.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','175e08d87a',1600,1056),
(21,1785499136,1785499136,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_782b863c3f.jpg','csm_SPITEX_SCHUH-77_2_782b863c3f.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','782b863c3f',1920,1280),
(22,1785499136,1785499136,1,6,'/_processed_/9/8/csm_test_3fba11eba7.jpg','csm_test_3fba11eba7.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','3fba11eba7',1920,1280),
(23,1785499136,1785499136,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_9865617d25.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_9865617d25.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','9865617d25',1920,1280),
(24,1785507436,1785507436,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_52a84846be.jpg','csm_SPITEX_SCHUH-77_2_52a84846be.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','52a84846be',640,380),
(25,1785509208,1785509208,1,15,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','32ef701922af80da8b5adbe2d08190edd38eac1e','Image.CropScaleMask','84f58b5353',48,48),
(26,1785509208,1785509208,1,11,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','44589e3facf2ccbc74d9b01316e15407ecae4f26','Image.CropScaleMask','87126e49eb',48,48),
(27,1785509208,1785509208,1,10,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','0991f88b7af9bcfb4388cf019221ad06ac289292','Image.CropScaleMask','90e097e9bc',48,48),
(28,1785509208,1785509208,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','da4787f47f240e24917b311cb1c1498cb6320127','Image.CropScaleMask','16cf7f4ccf',48,48),
(29,1785509208,1785509208,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','05fa4f036d55081fb5c94fd157514a90482f5e34','Image.CropScaleMask','35d2b3ef33',48,48),
(30,1785509208,1785509208,1,14,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4be54d2dccd5e4d9d01665b9485a481ff5e9503d','Image.CropScaleMask','3c34cd0a54',48,48),
(31,1785509208,1785509208,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5c39a033c64954eedb882c92a417e8b56fee16e1','Image.CropScaleMask','9ba76819fd',48,48),
(32,1785509208,1785509208,1,13,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','448587010e8a0b1b95f2b6851b5adf698bd85354','Image.CropScaleMask','54ca5817c6',48,48),
(33,1785509208,1785509208,1,16,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a71039589805fbb93729c8bfd6460fea3417b6de','Image.CropScaleMask','ca7f0f2281',48,48),
(34,1785509208,1785509208,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7a28e1ed9045367999a439d25167b239cd00ab2c','Image.CropScaleMask','789a4cffb9',48,48),
(35,1785509214,1785509214,1,19,'/_processed_/a/9/csm_standort-weier_35870212f5.jpg','csm_standort-weier_35870212f5.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','35870212f5',166,111),
(36,1785509216,1785509216,1,19,'/_processed_/a/9/csm_standort-weier_51ccf8e2c9.jpg','csm_standort-weier_51ccf8e2c9.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','51ccf8e2c9',225,150),
(37,1785509216,1785509216,1,19,'/_processed_/a/9/csm_standort-weier_c7a49ad61a.jpg','csm_standort-weier_c7a49ad61a.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','c7a49ad61a',60,40),
(38,1785509478,1785509265,1,20,'/_processed_/6/2/preview_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_e73e6eef93.webp','preview_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_e73e6eef93.webp','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.Preview','e73e6eef93',64,43),
(39,1785509265,1785509265,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_6b31097e14.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_6b31097e14.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','6b31097e14',225,150),
(40,1785509265,1785509265,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_2e212dd40e.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_2e212dd40e.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','2e212dd40e',60,40),
(41,1785509291,1785509291,1,19,'/_processed_/a/9/csm_standort-weier_96d59c46ba.jpg','csm_standort-weier_96d59c46ba.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','96d59c46ba',640,380),
(42,1785509291,1785509291,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_d12264a512.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_d12264a512.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','d12264a512',640,380),
(43,1785509423,1785509423,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_94c15e59e8.webp','csm_Frontbild_SR_2_94c15e59e8.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','94c15e59e8',166,93),
(44,1785509424,1785509424,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_4249a9aa6e.webp','csm_Frontbild_SR_2_4249a9aa6e.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','4249a9aa6e',269,150),
(45,1785509424,1785509424,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_68c36343a8.webp','csm_Frontbild_SR_2_68c36343a8.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','68c36343a8',60,33),
(46,1785509465,1785509465,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_2bad66f211.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_2bad66f211.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','2bad66f211',166,111),
(47,1785509466,1785509466,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_782cd51ba5.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_782cd51ba5.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','782cd51ba5',225,150),
(48,1785509466,1785509466,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_0eee4dc871.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_0eee4dc871.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','0eee4dc871',60,40),
(49,1785509489,1785509489,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_d1ccf23cb2.webp','csm_Frontbild_SR_2_d1ccf23cb2.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','d1ccf23cb2',640,380),
(50,1785509489,1785509489,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_909a90f91b.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_909a90f91b.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','909a90f91b',640,380);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(3,0,1785492219,1785492219,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,1,'pages','media',1,'',NULL,NULL,0),
(4,1,1785498866,1785497882,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,NULL,NULL,1,'lueg_podcasts_episodes','mediafile',1,'',NULL,NULL,0),
(5,1,1785498532,1785497882,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,1,'lueg_podcasts_episodes','poster',1,'',NULL,NULL,0),
(6,1,1785498866,1785497882,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,4,NULL,NULL,2,'lueg_podcasts_episodes','mediafile',1,'',NULL,NULL,0),
(7,1,1785498693,1785497882,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,2,'lueg_podcasts_episodes','poster',1,'',NULL,NULL,0),
(8,1,1785498866,1785498532,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,6,NULL,'Podcats Nr 1',1,'lueg_podcasts_episodes','poster',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(9,1,1785498866,1785498693,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,NULL,2,'lueg_podcasts_episodes','poster',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(10,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,9,NULL,NULL,1,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(11,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,10,NULL,NULL,2,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(12,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,11,NULL,NULL,3,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(13,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,12,NULL,NULL,4,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(14,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,13,NULL,NULL,5,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(15,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,14,NULL,NULL,6,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(16,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,15,NULL,NULL,7,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(17,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,16,NULL,NULL,8,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(18,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,17,NULL,NULL,9,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(19,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,18,NULL,NULL,10,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0),
(20,1,1785509276,1785507434,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin1_image',1,'',NULL,NULL,0),
(21,1,1785509276,1785507434,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,NULL,0),
(22,1,1785509487,1785507434,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin3_image',1,'',NULL,NULL,0),
(23,1,1785509487,1785507434,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin4_image',1,'',NULL,NULL,0),
(24,1,1785509547,1785509276,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,19,NULL,'standort weier',5,'tt_content','lueg_standorte_pin1_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(25,1,1785509487,1785509276,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,'standort sumiswald',5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(26,1,1785509547,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,21,NULL,'Marktgasse 5 3454 ',5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(27,1,1785509547,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,22,NULL,'Standort Affoltern',5,'tt_content','lueg_standorte_pin3_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(28,1,1785509547,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,'Standort Hasle',5,'tt_content','lueg_standorte_pin4_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1785490031,1785490031,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1785485818,0,0,0,NULL,'User Upload','1:/user_upload/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1785490041,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1785490041,1,'BE',2,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"spitex lueg\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"1\",\"sys_language_uid\":0,\"crdate\":1785490041,\"t3ver_stage\":0,\"tstamp\":1785490041,\"uid\":1}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:4cf496f597e7b095ce8b755e6cec3c0c'),
(3,1785490041,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1785491657,1,'BE',2,0,2,'pages','{\"doktype\":\"3\",\"slug\":\"\\/podcasts\",\"link\":\"Podcasts\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Podcasts\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491657,\"t3ver_stage\":0,\"tstamp\":1785491657,\"uid\":2}',0,'0400$omWpoRvZkeQ57UXdvAnM8zOxu7lb366N:f11830df10b4b0bca2db34810c2241b3'),
(5,1785491662,2,'BE',2,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4m3XTRyS-hi7BI7OSIyTYJgM_fBar73U:f11830df10b4b0bca2db34810c2241b3'),
(6,1785491690,1,'BE',2,0,3,'pages','{\"doktype\":\"3\",\"slug\":\"\\/freie\",\"link\":\"freie-stellen\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":512,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Freie Stellen\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491690,\"t3ver_stage\":0,\"tstamp\":1785491690,\"uid\":3}',0,'0400$cIHHYZBoo0Sbtg5q5wEYesEP5A4j-rB7:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(7,1785491694,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$u_pRDRoOI5jt0Yz1DNjZKDAwq_XaKgMC:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(8,1785491709,1,'BE',2,0,4,'pages','{\"doktype\":\"3\",\"slug\":\"\\/benefits\",\"link\":\"Benefits\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":768,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Benefits\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491709,\"t3ver_stage\":0,\"tstamp\":1785491709,\"uid\":4}',0,'0400$OUe05A_qUllmq2hYXIbKvGRJ09s-SsxY:412add0b3eb6ec8f1cb6710aea92e21e'),
(9,1785491735,1,'BE',2,0,5,'pages','{\"doktype\":\"3\",\"slug\":\"\\/direkt-bewerben\",\"link\":\"Direkt-bewerben\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1024,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Direkt bewerben\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491735,\"t3ver_stage\":0,\"tstamp\":1785491735,\"uid\":5}',0,'0400$bRDqUABHrCHsPge9R9pOOsd8s2cB6jby:7ef5a4e3e11db8ac3fea4d7a75468161'),
(10,1785491741,2,'BE',2,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$o5n_iRIvF235Nli5Ofw3OxONrqYKAurQ:7ef5a4e3e11db8ac3fea4d7a75468161'),
(11,1785491743,2,'BE',2,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Zabi7RvB3Q7FOOTFB4P5MR3ipON8KjJH:412add0b3eb6ec8f1cb6710aea92e21e'),
(12,1785491929,1,'BE',2,0,6,'pages','{\"doktype\":\"3\",\"slug\":\"\\/standorte-spitex-region-lueg\",\"link\":\"Standorte\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1280,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Standorte Spitex Region Lueg\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491929,\"t3ver_stage\":0,\"tstamp\":1785491929,\"uid\":6}',0,'0400$N85uCLaz2cCqgIbuWwOj6Erylk7QyEIK:c75354c439a48dbde16b03ac553a080d'),
(13,1785491933,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$femDvlEtlqnvAlb7ysZnJ4KkZKxfYs4-:c75354c439a48dbde16b03ac553a080d'),
(14,1785491942,1,'BE',2,0,7,'pages','{\"doktype\":\"254\",\"slug\":\"\\/storage\",\"module\":\"\",\"hidden\":\"1\",\"categories\":\"0\",\"pid\":1,\"sorting\":1536,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Storage\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491942,\"t3ver_stage\":0,\"tstamp\":1785491942,\"uid\":7}',0,'0400$4lgVRcYJkgbeGPL8SHF7kY_GIpDYKO3P:df50bb24cbce671cf0d61f42fbbef601'),
(15,1785491945,2,'BE',2,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$TkZA_AURYEk5YRSVCsZ8sjmHOIsW74Ii:df50bb24cbce671cf0d61f42fbbef601'),
(16,1785498371,2,'BE',2,0,2,'tt_content','{\"oldRecord\":{\"lueg_podcasts_episodes\":0,\"l18n_diffsource\":null},\"newRecord\":{\"lueg_podcasts_episodes\":2,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_podcasts_episodes\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:01dbc21fdb1263685b9147b3b1596ea8'),
(17,1785498371,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:0132d725a3cbba8232db69b70fa8cea4'),
(18,1785498371,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:147949966161cea7a4448f46cffcc51f'),
(19,1785498532,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:0132d725a3cbba8232db69b70fa8cea4'),
(20,1785498532,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autoplay\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:cea5fcd7b97871880cfe3717d6b52ef4'),
(21,1785498532,1,'BE',2,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Podcats Nr 1\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1785498532,\"t3ver_stage\":0,\"tstamp\":1785498532,\"uid\":8}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(22,1785498532,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:0132d725a3cbba8232db69b70fa8cea4'),
(23,1785498532,4,'BE',2,0,5,'sys_file_reference',NULL,0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:5f15a1453f67b933ed3314381f5d67e4'),
(24,1785498693,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:147949966161cea7a4448f46cffcc51f'),
(25,1785498693,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autoplay\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:cea5fcd7b97871880cfe3717d6b52ef4'),
(26,1785498693,2,'BE',2,0,8,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(27,1785498693,2,'BE',2,0,6,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:768f9cd4e98812f969df7ebe17f11b50'),
(28,1785498693,1,'BE',2,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1785498693,\"t3ver_stage\":0,\"tstamp\":1785498693,\"uid\":9}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:729356755eb8ee035abf6b9b02e20c8f'),
(29,1785498693,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:147949966161cea7a4448f46cffcc51f'),
(30,1785498693,4,'BE',2,0,7,'sys_file_reference',NULL,0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:117c97010b9af15cb554d115dba4e316'),
(31,1785498866,2,'BE',2,0,9,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$hNxqfbc6dgh5pKeA-3CvEaFkPC7wQPqp:729356755eb8ee035abf6b9b02e20c8f'),
(32,1785502132,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p><strong>Wir suchen ausgebildete Fachkr\\u00e4fte, Quereinsteiger:innen und Lernende.<\\/strong><\\/p><p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll \\u2013 genau das macht sie so wertvoll.<\\/p><p>Wir unterst\\u00fctzen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und er\\u00f6ffnen ihnen die M\\u00f6glichkeit, Verantwortung zu \\u00fcbernehmen, beispielsweise in Spezialfunktionen.<\\/p>\",\"l18n_diffsource\":null},\"newRecord\":{\"bodytext\":\"<p><strong>Wir suchen ausgebildete Fachkr\\u00e4fte, Quereinsteiger:innen und Lernende.<\\/strong><\\/p>\\r\\n<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll \\u2013 genau das macht sie so wertvoll.<\\/p>\\r\\n<p>Wir unterst\\u00fctzen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und er\\u00f6ffnen ihnen die M\\u00f6glichkeit, Verantwortung zu \\u00fcbernehmen, beispielsweise in Spezialfunktionen.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$DAHkPTojXteTDPDMmAW1XrbMV8z4PGuN:7fa2c035f26826fe83eeecaaeddc4d40'),
(33,1785503682,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"lueg_benefits_tiles\":0,\"l18n_diffsource\":null},\"newRecord\":{\"lueg_benefits_tiles\":10,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_benefits_tiles\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:4d391f5ef79b8d5d10dffa8a07ca167d'),
(34,1785503682,2,'BE',2,0,1,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:1380d93aca08b14d7410b8aac97055d9'),
(35,1785503682,2,'BE',2,0,2,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:f16c1939204e3f8a6b67a49b7521c33f'),
(36,1785503682,2,'BE',2,0,3,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:0c785c1cb42d424e2608d25e0a182d66'),
(37,1785503682,2,'BE',2,0,4,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:22482fded5cb2c1071b802cad4406b07'),
(38,1785503682,2,'BE',2,0,5,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:1f457869a01262deca1e13521dcdaf7c'),
(39,1785503682,2,'BE',2,0,6,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:89a116999daef93a1e986c713f9accde'),
(40,1785503682,2,'BE',2,0,7,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:fe3fe818b96053da0676e791e6593721'),
(41,1785503682,2,'BE',2,0,8,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:ce032405553aefd28279d08ba416ec8a'),
(42,1785503682,2,'BE',2,0,9,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:69eb67fcaa1c5c687d66be5ebf4a03c2'),
(43,1785503682,2,'BE',2,0,10,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:d8122aa04961ffca814bacd78fc21345'),
(44,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(45,1785509276,1,'BE',2,0,24,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"standort weier\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1785509276,\"t3ver_stage\":0,\"tstamp\":1785509276,\"uid\":24}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:ec378d8e96f494986de35c9be84dff5c'),
(46,1785509276,1,'BE',2,0,25,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"standort sumiswald\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1785509276,\"t3ver_stage\":0,\"tstamp\":1785509276,\"uid\":25}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:5ce305fb03b44e2e5ced3360656e263a'),
(47,1785509276,2,'BE',2,0,22,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:d6a5725e5b31cdd97b9c53c992e81850'),
(48,1785509276,2,'BE',2,0,23,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:a4b81cbb471961a3c12b21861b94f4e1'),
(49,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(50,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(51,1785509276,4,'BE',2,0,20,'sys_file_reference',NULL,0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:97d0d1c7a42cd9603b2010379c1e4e4d'),
(52,1785509276,4,'BE',2,0,21,'sys_file_reference',NULL,0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:bd8e6a36b477d61e04d92cfd10d00f96'),
(53,1785509279,2,'BE',2,0,24,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$tf1hLUF1l6g184HEEW-NPOU015vLTpXq:ec378d8e96f494986de35c9be84dff5c'),
(54,1785509279,2,'BE',2,0,25,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$tf1hLUF1l6g184HEEW-NPOU015vLTpXq:5ce305fb03b44e2e5ced3360656e263a'),
(55,1785509487,1,'BE',2,0,26,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Marktgasse 5 3454 \",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":26}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:2190384e72cbe31d01b0259338cca742'),
(56,1785509487,1,'BE',2,0,27,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Standort Affoltern\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":27}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:dd318efa0f8b108e87c8725b284b77c4'),
(57,1785509487,1,'BE',2,0,28,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Standort Hasle\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":28}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(58,1785509487,4,'BE',2,0,25,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:5ce305fb03b44e2e5ced3360656e263a'),
(59,1785509487,4,'BE',2,0,22,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:d6a5725e5b31cdd97b9c53c992e81850'),
(60,1785509487,4,'BE',2,0,23,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:a4b81cbb471961a3c12b21861b94f4e1'),
(61,1785509547,2,'BE',2,0,26,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:2190384e72cbe31d01b0259338cca742'),
(62,1785509547,2,'BE',2,0,27,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:dd318efa0f8b108e87c8725b284b77c4'),
(63,1785509547,2,'BE',2,0,28,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:59425f1ffdef0b99239b8bcfbe5ba5e9');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(1,2,1785490031,'pages',1,0,'studio_lg',0),
(2,2,1785490041,'pages',1,0,'studio_lg',0),
(3,2,1785498338,'tt_content',2,1,'studio_lg',0),
(4,2,1785498371,'tt_content',2,1,'studio_lg',0),
(5,2,1785498410,'tt_content',2,1,'studio_lg',0),
(6,2,1785498532,'tt_content',2,1,'studio_lg',0),
(7,2,1785498693,'tt_content',2,1,'studio_lg',0),
(8,2,1785498867,'tt_content',2,1,'studio_lg',0),
(9,2,1785501896,'tt_content',1,1,'studio_lg',0),
(10,2,1785502133,'tt_content',1,1,'studio_lg',0),
(11,2,1785502239,'tt_content',2,1,'studio_lg',0),
(12,2,1785503676,'tt_content',4,1,'studio_lg',0),
(13,2,1785503682,'tt_content',4,1,'studio_lg',0),
(14,2,1785509171,'tt_content',5,1,'studio_lg',0),
(15,2,1785509276,'tt_content',5,1,'studio_lg',0),
(16,2,1785509279,'tt_content',5,1,'studio_lg',0),
(17,2,1785509487,'tt_content',5,1,'studio_lg',0),
(18,2,1785509547,'tt_content',5,1,'studio_lg',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1785485820,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1785486315,2,1,0,'',0,0,'Personal settings changed',254,'default','172.18.0.6','',-1,0,'',0,'','info',NULL,NULL),
(3,1785490037,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"SPITEX_SCHUH-77_2.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(4,1785490041,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":1,\"history\":\"1\"}',0,0,'',0,'','info',NULL,NULL),
(5,1785490041,2,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(6,1785490041,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(7,1785490063,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(8,1785490085,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'table_local\' in \'INSERT INTO\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 63',5,'php','','',-1,0,'',0,'','error',NULL,NULL),
(9,1785490101,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(10,1785490283,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(11,1785491536,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(12,1785491537,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Layouts/Default.html, line 11 at character 2. Error: The ViewHelper \"<vite:asset>\" could not be resolved.\nBased on your spelling, the system would load the class \"Praetorius\\ViteAssetCollector\\ViewHelpers\\AssetViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <vite:asset entry=\"EXT:site_package/Resources/Private/Frontend/main.js\"/> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.6','',-1,0,'',0,'','error',NULL,NULL),
(13,1785491538,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Layouts/Default.html, line 11 at character 2. Error: The ViewHelper \"<vite:asset>\" could not be resolved.\nBased on your spelling, the system would load the class \"Praetorius\\ViteAssetCollector\\ViewHelpers\\AssetViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <vite:asset entry=\"EXT:site_package/Resources/Private/Frontend/main.js\"/> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.6','',-1,0,'',0,'','error',NULL,NULL),
(14,1785491602,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(15,1785491657,2,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(16,1785491662,2,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"history\":\"5\"}',1,0,'',0,'','info',NULL,NULL),
(17,1785491690,2,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1785491694,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"history\":\"7\"}',1,0,'',0,'','info',NULL,NULL),
(19,1785491709,2,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(20,1785491735,2,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(21,1785491741,2,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"history\":\"10\"}',1,0,'',0,'','info',NULL,NULL),
(22,1785491743,2,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"history\":\"11\"}',1,0,'',0,'','info',NULL,NULL),
(23,1785491929,2,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1785491933,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"history\":\"13\"}',1,0,'',0,'','info',NULL,NULL),
(25,1785491942,2,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1785491945,2,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":7,\"history\":\"15\"}',1,0,'',0,'','info',NULL,NULL),
(27,1785492158,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(28,1785492970,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(29,1785492999,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(30,1785493028,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(31,1785496913,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(32,1785498371,2,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"16\"}',1,0,'',0,'','info',NULL,NULL),
(33,1785498371,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"17\"}',1,0,'',0,'','info',NULL,NULL),
(34,1785498371,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"18\"}',1,0,'',0,'','info',NULL,NULL),
(35,1785498403,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(36,1785498504,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Homepage\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(37,1785498514,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"podcasts\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(38,1785498521,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"test.jpg\",\"destination\":\"\\/user_upload\\/podcasts\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(39,1785498532,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"19\"}',1,0,'',0,'','info',NULL,NULL),
(40,1785498532,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"20\"}',1,0,'',0,'','info',NULL,NULL),
(41,1785498532,2,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(42,1785498532,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"22\"}',1,0,'',0,'','info',NULL,NULL),
(43,1785498532,2,3,5,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(44,1785498691,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Bildschirmfoto 2026-07-31 um 13.51.25.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(45,1785498693,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"24\"}',1,0,'',0,'','info',NULL,NULL),
(46,1785498693,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"25\"}',1,0,'',0,'','info',NULL,NULL),
(47,1785498693,2,2,8,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":8,\"history\":\"26\"}',1,0,'',0,'','info',NULL,NULL),
(48,1785498693,2,2,6,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":6,\"history\":\"27\"}',1,0,'',0,'','info',NULL,NULL),
(49,1785498693,2,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1785498693,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"29\"}',1,0,'',0,'','info',NULL,NULL),
(51,1785498693,2,3,7,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(52,1785498866,2,2,9,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":9,\"history\":\"31\"}',1,0,'',0,'','info',NULL,NULL),
(53,1785498869,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(54,1785499009,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(55,1785499018,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(56,1785499594,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(57,1785500631,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(58,1785501115,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(59,1785502132,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"32\"}',1,0,'',0,'','info',NULL,NULL),
(60,1785502135,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(61,1785503682,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"33\"}',1,0,'',0,'','info',NULL,NULL),
(62,1785503682,2,2,1,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":1,\"history\":\"34\"}',1,0,'',0,'','info',NULL,NULL),
(63,1785503682,2,2,2,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":2,\"history\":\"35\"}',1,0,'',0,'','info',NULL,NULL),
(64,1785503682,2,2,3,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":3,\"history\":\"36\"}',1,0,'',0,'','info',NULL,NULL),
(65,1785503682,2,2,4,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":4,\"history\":\"37\"}',1,0,'',0,'','info',NULL,NULL),
(66,1785503682,2,2,5,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":5,\"history\":\"38\"}',1,0,'',0,'','info',NULL,NULL),
(67,1785503682,2,2,6,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":6,\"history\":\"39\"}',1,0,'',0,'','info',NULL,NULL),
(68,1785503682,2,2,7,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":7,\"history\":\"40\"}',1,0,'',0,'','info',NULL,NULL),
(69,1785503682,2,2,8,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":8,\"history\":\"41\"}',1,0,'',0,'','info',NULL,NULL),
(70,1785503682,2,2,9,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":9,\"history\":\"42\"}',1,0,'',0,'','info',NULL,NULL),
(71,1785503682,2,2,10,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":10,\"history\":\"43\"}',1,0,'',0,'','info',NULL,NULL),
(72,1785509214,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"standort-weier.jpg\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(73,1785509265,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(74,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"44\"}',1,0,'',0,'','info',NULL,NULL),
(75,1785509276,2,1,24,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(76,1785509276,2,1,25,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(77,1785509276,2,2,22,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":22,\"history\":\"47\"}',1,0,'',0,'','info',NULL,NULL),
(78,1785509276,2,2,23,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":23,\"history\":\"48\"}',1,0,'',0,'','info',NULL,NULL),
(79,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"49\"}',1,0,'',0,'','info',NULL,NULL),
(80,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"50\"}',1,0,'',0,'','info',NULL,NULL),
(81,1785509276,2,3,20,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(82,1785509276,2,3,21,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1785509279,2,2,24,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":24,\"history\":\"53\"}',1,0,'',0,'','info',NULL,NULL),
(84,1785509279,2,2,25,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"history\":\"54\"}',1,0,'',0,'','info',NULL,NULL),
(85,1785509423,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Frontbild_SR_2.webp\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(86,1785509465,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(87,1785509487,2,1,26,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":26,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1785509487,2,1,27,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":27,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1785509487,2,1,28,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":28,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(90,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(91,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(92,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(93,1785509487,2,3,25,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1785509487,2,3,22,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(95,1785509487,2,3,23,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(96,1785509547,2,2,26,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":26,\"history\":\"61\"}',1,0,'',0,'','info',NULL,NULL),
(97,1785509547,2,2,27,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":27,\"history\":\"62\"}',1,0,'',0,'','info',NULL,NULL),
(98,1785509547,2,2,28,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":28,\"history\":\"63\"}',1,0,'',0,'','info',NULL,NULL),
(99,1785509549,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL,
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('032c9455240737904f045d3fb40ed1d2','sys_file',16,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('06ca32ac6eb0e64f5da705b5c35de5b7','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('07a8cafecf0b85c1a89c84ab57172544','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('1891e5b68039b20ea9ed0acf765648c4','sys_file',11,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('1c382bc93ac30b52eaf2ada5cc3ded1c','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',2,0,'lueg_benefits_tiles',3,'',0,0,2147483647,0,0,''),
('1debe5f1ff14e3f1360d692113b41c1f','tt_content',2,'lueg_podcasts_episodes',0,0,2147483647,0,'','','',1,0,'lueg_podcasts_episodes',2,'',0,0,2147483647,0,0,''),
('27b62ed56b876e5330b7b7d9eb55d72e','tt_content',5,'lueg_standorte_pin2_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',26,'',0,0,2147483647,0,0,''),
('2906231fdf5b506019bbc975da352cd3','tt_content',5,'lueg_standorte_pin4_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',28,'',0,0,2147483647,0,0,''),
('2932310b34b3604c71486e46f971e5e5','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',8,0,'lueg_benefits_tiles',9,'',0,0,2147483647,0,0,''),
('34a346792c831418b0b2e95e4674867f','lueg_podcasts_episodes',2,'poster',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('40cdf7c8459e145b7ee98da411dd53f2','pages',1,'media',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('41170785eb716bc6bf2dfd49e8b7880d','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',4,0,'lueg_benefits_tiles',5,'',0,0,2147483647,0,0,''),
('49a1dca9b44dbc2f1878bcbdb69eaa56','sys_file',20,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',20,'',0,0,2147483647,0,0,''),
('59c7319c41b3f5fd154aab420e38af03','sys_file',15,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('63394b2fc893d034b736bc059fc3097b','sys_file_reference',27,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('69982b2a98cbef53cc80295c48be6116','sys_file',17,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6a94b41f5ae34b7bae0ec9070182ed92','sys_file',13,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('70309932df13074e9719fed1f2f5a380','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',0,0,'lueg_benefits_tiles',1,'',0,0,2147483647,0,0,''),
('731a3e934d4284dc1337694ff2a2e91a','sys_file',22,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('74f89f508a8d8465607d030c6629dc92','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('7ddeabd5bec17a9da953ae45845d3a2c','tt_content',5,'lueg_standorte_pin1_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',24,'',0,0,2147483647,0,0,''),
('85ce5f98e1d11d3a63413f8c25da17d8','sys_file',19,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('8c35623f6d2e812f184755b0e9da5f00','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',9,0,'lueg_benefits_tiles',10,'',0,0,2147483647,0,0,''),
('9582bb2310aa3295376e517d36d54791','tt_content',5,'lueg_standorte_pin3_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',27,'',0,0,2147483647,0,0,''),
('9752b282c0d432837f1bbed545654b32','lueg_podcasts_episodes',2,'mediafile',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('9f4f80f7417765a1fd405687474b2680','sys_file',18,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a21506ca9162f75c863170914a766564','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a71d156cbbc1fd0aea0e6f9e84024815','sys_file',14,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a7f01a3638670898c734e94169bb1838','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',7,0,'lueg_benefits_tiles',8,'',0,0,2147483647,0,0,''),
('a8ae560441da233771408a7e6b28c1b6','sys_file',20,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a8b4e24168e192fb3cc844f511bb2601','lueg_podcasts_episodes',1,'poster',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b52b3687ca0340b281d2f547cd5d35ea','sys_file_reference',28,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('bd871a48b5b62b0393e1bbfcd4306088','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',1,0,'lueg_benefits_tiles',2,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('bef4c06bde2f3af98649fb668f472127','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',5,0,'lueg_benefits_tiles',6,'',0,0,2147483647,0,0,''),
('cc38ad8c255193f5cbeb15f85896b92e','tt_content',2,'lueg_podcasts_episodes',0,0,2147483647,0,'','','',0,0,'lueg_podcasts_episodes',1,'',0,0,2147483647,0,0,''),
('ccc76f735cb38dca39df162b0b627353','sys_file',12,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('dab1afc2e3d19ecaa9f15b9368559a6b','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',3,0,'lueg_benefits_tiles',4,'',0,0,2147483647,0,0,''),
('db2015faae619ad98a32fd8044806f55','sys_file_reference',26,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('ddb0486620e0393165318a07cbbc4b8e','sys_file',21,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('e4af88b058a534b7664d8b65f3c075cc','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',6,0,'lueg_benefits_tiles',7,'',0,0,2147483647,0,0,''),
('e94a2ecd669824a1cb80959e7df9156d','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('f0d49e18db70a622c6f1679c438f280b','sys_file_reference',24,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('f6062209d87aa82eace335f4ab0c7610','sys_file',10,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f878cf5ef918189e175dcf8358956cda','lueg_podcasts_episodes',1,'mediafile',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Scheduler\\Migration\\SchedulerDatabaseStorageMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','scheduler:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','lowlevel:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','site_package:ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','lueg/project:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','typo3/app:ext_tables_static+adt.sql','s:0:\"\";'),
(42,'core','formProtectionSessionToken:2','s:64:\"8abb9b40060c9403ff7b28a13465e408504c7527d7866815afb5486a40e51004\";'),
(43,'extensionDataImport','content_blocks:ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL,
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_podcasts_episodes` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_ausbildung_items` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_benefits_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin1_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin1_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin1_address` longtext DEFAULT NULL,
  `lueg_standorte_pin1_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin2_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin2_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin2_address` longtext DEFAULT NULL,
  `lueg_standorte_pin2_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin3_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin3_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin3_address` longtext DEFAULT NULL,
  `lueg_standorte_pin3_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin4_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin4_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin4_address` longtext DEFAULT NULL,
  `lueg_standorte_pin4_link` text NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1785502132,1785493511,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_headline_text',0,0,'','',0,'Lueg – dini Zuekunft, bir Spitex Region Lueg',0,'','','','<p><strong>Wir suchen ausgebildete Fachkräfte, Quereinsteiger:innen und Lernende.</strong></p>\r\n<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll – genau das macht sie so wertvoll.</p>\r\n<p>Wir unterstützen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und eröffnen ihnen die Möglichkeit, Verantwortung zu übernehmen, beispielsweise in Spezialfunktionen.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,''),
(2,1,1785498371,1785497882,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_podcasts_episodes\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_podcasts',0,0,'','',0,'Lueg – u los ine',0,'','','','<p>In dieser Podcast-Serie erzählen unsere Mitarbeitenden aus ihrem Alltag in der ambulanten Pflege – ehrlich, persönlich und mit Geschichten, die zeigen, warum genau du hier richtig bist.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,''),
(3,1,1785502894,1785502894,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'lueg_ausbildung',0,0,'','',0,'Lueg – mir bilde lernendi us',0,'','','','<p>Die Arbeit mit Menschen gibt dir echten Sinn. Damit unsere Klientinnen und Klienten jederzeit top betreut sind, bildet die Spitex Region Lueg Fachfrauen und Fachmänner Gesundheit (FaGe) aus. Bei uns wirst du Schritt für Schritt begleitet – individuell, persönlich und immer auf deinem Weg.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,''),
(4,1,1785503682,1785503461,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_benefits_tiles\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_benefits',0,0,'','',0,'Lueg – was mir dir biete',0,'','','','<p>Wir sind ein moderner, innovativer Arbeitgeber mit guter Infrastruktur, zeitgemässen Arbeitsmitteln und Offenheit für neue Methoden. Wir kommunizieren auf Augenhöhe und leben eine offene, wertschätzende Teamkultur.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,10,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,''),
(5,1,1785509487,1785507434,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_standorte_pin1_address\":\"\",\"lueg_standorte_pin1_image\":\"\",\"lueg_standorte_pin1_link\":\"\",\"lueg_standorte_pin1_title\":\"\",\"lueg_standorte_pin2_address\":\"\",\"lueg_standorte_pin2_image\":\"\",\"lueg_standorte_pin2_link\":\"\",\"lueg_standorte_pin2_title\":\"\",\"lueg_standorte_pin3_address\":\"\",\"lueg_standorte_pin3_image\":\"\",\"lueg_standorte_pin3_link\":\"\",\"lueg_standorte_pin3_title\":\"\",\"lueg_standorte_pin4_address\":\"\",\"lueg_standorte_pin4_image\":\"\",\"lueg_standorte_pin4_link\":\"\",\"lueg_standorte_pin4_title\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_standorte',0,0,'','',0,'Lueg – wo mir si',0,'','','','<p>Das Einzugsgebiet der Spitex Region Lueg umfasst 11 Gemeinden mit insgesamt 23’000 Einwohnerinnen und Einwohnern. Dank vier Standorten ist die Organisation in der Mitte des Emmentals präsent und bestens mit den Bedürfnissen der Bevölkerung vertraut.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,1,'Standort Weier','Huttwilwestrasse 1\r\n3462 Weier i.E','https://www.google.com/maps?q=Huttwilwestrasse+1+3462+Weier',1,'Standort Sumiswald','Marktgasse 5\r\n3454 Sumiswald','https://www.google.com/maps?q=Marktgasse+5+3454+Sumiswald',1,'Standort Affoltern','Dorfstrasse 12\r\n3416 Affoltern i.E.','https://www.google.com/maps?q=Dorfstrasse+12+3416+Affoltern',1,'Standort Hasle','Bahnhofstrasse 3\r\n3415 Hasle b.B.','https://www.google.com/maps?q=Bahnhofstrasse+3+3415+Hasle');
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `tasktype` longtext DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `description` longtext DEFAULT NULL,
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `execution_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`execution_details`)),
  `nextexecution` bigint(20) NOT NULL DEFAULT 0,
  `lastexecution_time` bigint(20) NOT NULL DEFAULT 0,
  `lastexecution_failure` longtext DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `number_of_days` int(11) NOT NULL DEFAULT 0,
  `selected_tables` varchar(4000) DEFAULT '',
  `file_storage` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_backends` longtext DEFAULT NULL,
  `max_file_count` int(10) unsigned NOT NULL DEFAULT 0,
  `ip_mask` int(10) unsigned NOT NULL DEFAULT 2,
  `all_tables` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `color` varchar(7) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-07-31 16:53:22
