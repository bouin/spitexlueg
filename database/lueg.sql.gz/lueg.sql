-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.6-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1785485821,1785485821,0,0,0,0,2,'[]','a79cd3a9ee76cac8502dff95e52fc497a0868ca9','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
INSERT INTO `be_groups` VALUES
(1,0,1785485818,1785485818,0,0,'Editors have access to basic content element and modules in the backend.','pages,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,tt_content,sys_note','Editor','1','1',NULL,0,'1,3,4,7,199,254','pages,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,tt_content,sys_note','sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:alternative,sys_file_reference:autoplay,sys_file_reference:description,sys_file_reference:crop,sys_file_reference:link,sys_file_reference:title,sys_file_collection:hidden,sys_file_collection:sys_language_uid,sys_file_collection:starttime,sys_file_collection:endtime,pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:canonical_link,pages:categories,pages:rowDescription,pages:description,pages:author_email,pages:media,pages:no_follow,pages:layout,pages:no_search,pages:extendToSubpages,pages:no_index,pages:keywords,pages:lastUpdated,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:hidden,pages:sitemap_priority,pages:shortcut_mode,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:twitter_description,pages:twitter_image,pages:twitter_title,pages:doktype,pages:twitter_card,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:hidden,tt_content:imagewidth','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:shortcut,tt_content:CType:list','',NULL,'dashboard,web_layout,page_preview,records,media_management,user_setup',NULL,NULL,'','',NULL,'seo-pagesWithoutMetaDescription'),
(2,0,1785485818,1785485818,0,0,'Advanced Editors have access to all content elements and non administrative modules in the backend.','pages,sys_category,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,fe_groups,fe_users,tt_content,tx_impexp_presets,sys_redirect,sys_note','Advanced Editor','1','1',NULL,0,'1,3,4,6,7,199,254','pages,sys_category,sys_file,sys_file_collection,sys_file_metadata,sys_file_reference,sys_file_storage,backend_layout,fe_groups,fe_users,tt_content,tx_impexp_presets,sys_redirect,sys_note','backend_layout:hidden,backend_layout:icon,sys_category:hidden,sys_category:sys_language_uid,sys_category:starttime,sys_category:endtime,sys_file_metadata:categories,sys_file_metadata:title,sys_file_reference:alternative,sys_file_reference:autoplay,sys_file_reference:description,sys_file_reference:crop,sys_file_reference:link,sys_file_reference:title,sys_file_collection:hidden,sys_file_collection:sys_language_uid,sys_file_collection:starttime,sys_file_collection:endtime,pages:newUntil,pages:abstract,pages:fe_group,pages:author,pages:backend_layout_next_level,pages:backend_layout,pages:cache_timeout,pages:cache_tags,pages:canonical_link,pages:categories,pages:sitemap_changefreq,pages:module,pages:rowDescription,pages:description,pages:author_email,pages:media,pages:no_follow,pages:layout,pages:php_tree_stop,pages:no_search,pages:extendToSubpages,pages:no_index,pages:is_siteroot,pages:keywords,pages:lastUpdated,pages:l18n_cfg,pages:mount_pid_ol,pages:nav_title,pages:og_description,pages:og_image,pages:og_title,pages:nav_hide,pages:hidden,pages:sitemap_priority,pages:shortcut_mode,pages:content_from_pid,pages:starttime,pages:endtime,pages:subtitle,pages:target,pages:seo_title,pages:twitter_description,pages:twitter_image,pages:twitter_title,pages:doktype,pages:twitter_card,tt_content:pi_flexform;felogin_login;sDEF;settings.pages,tt_content:fe_group,tt_content:header_position,tt_content:imageborder,tt_content:categories,tt_content:image_zoom,tt_content:imagecols,tt_content:date,tt_content:rowDescription,tt_content:uploads_description,tt_content:uploads_type,tt_content:table_delimiter,tt_content:file_collections,tt_content:frame_class,tt_content:layout,tt_content:imageheight,tt_content:sectionIndex,tt_content:sys_language_uid,tt_content:header_link,tt_content:imageorient,tt_content:recursive,tt_content:filelink_size,tt_content:filelink_sorting,tt_content:filelink_sorting_direction,tt_content:space_after_class,tt_content:space_before_class,tt_content:starttime,tt_content:pages,tt_content:endtime,tt_content:subheader,tt_content:table_caption,tt_content:table_header_position,tt_content:table_class,tt_content:table_enclosure,tt_content:linkToTop,tt_content:header_layout,tt_content:bullets_type,tt_content:table_tfoot,tt_content:hidden,tt_content:imagewidth,sys_redirect:hitcount,sys_redirect:createdon,sys_redirect:description,sys_redirect:disabled,sys_redirect:force_https,sys_redirect:disable_hitcount,sys_redirect:is_regexp,sys_redirect:keep_query_parameters,sys_redirect:lasthiton,sys_redirect:protected,sys_redirect:respect_query_parameters,sys_redirect:starttime,sys_redirect:target_statuscode,sys_redirect:endtime,fe_users:address,fe_users:city,fe_users:company,fe_users:country,fe_users:email,fe_users:disable,fe_users:fax,fe_users:first_name,fe_users:image,fe_users:lastlogin,fe_users:last_name,fe_users:middle_name,fe_users:name,fe_users:telephone,fe_users:tx_extbase_type,fe_users:felogin_redirectPid,fe_users:starttime,fe_users:endtime,fe_users:title,fe_users:www,fe_users:zip,fe_groups:hidden,fe_groups:felogin_redirectPid,fe_groups:subgroup','tt_content:CType:header,tt_content:CType:text,tt_content:CType:textpic,tt_content:CType:image,tt_content:CType:textmedia,tt_content:CType:bullets,tt_content:CType:table,tt_content:CType:uploads,tt_content:CType:menu_abstract,tt_content:CType:menu_categorized_content,tt_content:CType:menu_categorized_pages,tt_content:CType:menu_pages,tt_content:CType:menu_subpages,tt_content:CType:menu_recently_updated,tt_content:CType:menu_related_pages,tt_content:CType:menu_section,tt_content:CType:menu_section_pages,tt_content:CType:menu_sitemap,tt_content:CType:menu_sitemap_pages,tt_content:CType:shortcut,tt_content:CType:list,tt_content:CType:div,tt_content:CType:html,tt_content:CType:form_formframework,tt_content:CType:felogin_login','',NULL,'dashboard,web_layout,page_preview,records,web_FormFormbuilder,content_status,web_info_overview,web_info_translations,media_management,redirects,user_setup,system_log',NULL,NULL,'','',NULL,'seo-pagesWithoutMetaDescription');
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('62cd7bf88a00b7db3de6d7d8a1731df4b208dc17ee63675811b9ac11d2e0b3e1','[DISABLED]',2,1785748737,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"307a4ce6a9c8026f6b273f0115b01c1eaac8f76b9e998514cbcb820e4b4c7c9c\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1785485807,1785485807,0,0,0,0,NULL,'a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$TFg0NkZsWmk5aGk4bnFVUA$BGJukUX7cuIsM9jy9vxo77j2/sFDmhpuJXoN97a+9M8','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1785485807,1785485807,0,0,0,0,NULL,'a:17:{s:10:\"moduleData\";a:6:{s:28:\"dashboard/current_dashboard/\";s:40:\"a79cd3a9ee76cac8502dff95e52fc497a0868ca9\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:23:\"backend_user_management\";a:1:{s:13:\"defaultAction\";s:6:\"groups\";}s:10:\"web_layout\";a:3:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:0;}}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:24:\"1:/user_upload/icons_OK/\";}s:7:\"records\";a:4:{s:9:\"clipBoard\";b:1;s:9:\"searchBox\";b:0;s:15:\"collapsedTables\";a:0:{}s:9:\"languages\";a:1:{i:0;i:0;}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:6:{s:28:\"dashboard/current_dashboard/\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"810794d50511955451b96ca5d9f2491d83110ecd\";s:23:\"backend_user_management\";s:40:\"f346ef53b313d91161f10f0e6af68dbfee5f8fd8\";s:10:\"web_layout\";s:40:\"810794d50511955451b96ca5d9f2491d83110ecd\";s:16:\"browse_links.php\";s:40:\"810794d50511955451b96ca5d9f2491d83110ecd\";s:7:\"records\";s:40:\"810794d50511955451b96ca5d9f2491d83110ecd\";}s:12:\"mfaProviders\";s:0:\"\";s:11:\"colorScheme\";s:4:\"auto\";s:5:\"theme\";s:6:\"modern\";s:11:\"startModule\";s:10:\"web_layout\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:22:\"dateTimeFirstDayOfWeek\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:19:\"displayRecentlyUsed\";i:1;s:20:\"contextualRecordEdit\";i:1;s:10:\"copyLevels\";s:1:\"0\";s:10:\"inlineView\";s:122:\"{\"tt_content\":{\"2\":{\"lueg_podcasts_episodes\":{\"2\":\"\"},\"sys_file_reference\":{\"1\":\"\"}},\"3\":{\"lueg_ausbildung_items\":[\"1\"]}}}\";s:10:\"modulemenu\";s:2:\"{}\";}','{\"emailMeAtLogin\":0,\"mfaProviders\":\"\",\"colorScheme\":\"auto\",\"theme\":\"modern\",\"startModule\":\"web_layout\",\"backendTitleFormat\":\"titleFirst\",\"dateTimeFirstDayOfWeek\":\"\",\"titleLen\":\"50\",\"edit_docModuleUpload\":1,\"showHiddenFilesAndFolders\":0,\"displayRecentlyUsed\":1,\"contextualRecordEdit\":1,\"copyLevels\":\"0\"}',0,NULL,'','studio_lg','$argon2i$v=19$m=65536,t=16,p=1$VkJwVVZZMDRBeHd2SVo1QQ$DIsREnvDiJqisnICS2cLmLWOk1cGyVsedaL6FQbIz2A','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',1785740600,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'3_0f0092e5cdbe24fb',1817284816,'x�\�:\�v\�Fv��~�	69���H� i��,˲lKV-f�f��g\0��@\0;3-y}Nߡ��gh�\�W�&}�\�;�\0E:r�\�\�r720�\�\�����w\�^����Ә\�xh=\�\�#�d�b��\�\�uG\���\'���~~D\�j�L�\��\�4޷Bf?9�p�\�p\��o�`��`N�dj\�*Td\0\���\�&�i:\�,�/�b.\�l\��C`�Wb�ʜ�\�$gY�0�2\"��\�5\�Q	\�H���Ȭ#��srJS�j��O]�e&��(W�&\�\r	�\�\���ʜ	rqE��g���!Ix�R	ϋ4�g\�gߵ�\�_\�ն��F\�x��3l�\�\�Im\�#G\�ɳ����jθ �J��5�L���\�I\ZebA\�i~\����YP`�\�Q��n򬳗��\���Q�	O��b�oq��\�\\�h\�jE<\�,xڊ\�5>i�v{g��{y\Z\�\�GQ�7t۞\�:N\�Dn�î\�t��G�\� `\�^\�\"�-��\�`�\�W	��,X<\"/\�\\H\��\ZM$yJ�y$h\�MSr\�$(�W\�\�\�$C\�cF�\�\�\�L\\}�I܂w\�\�IX�#D�D�\��H��o\�-�\�\�m)Xyߊበ*)�x\�2F;<���*�\�&arΘ�U鵐l��\�j/e�Ńe�/\�)-�`!���\n�)r��\0�EC�:C��Q\��Q�︮\�uX��\�{�\��K\�:���\�ٷ�7\�y݁\�\�m\�k~�\��f)h�)K6\�Cv��\�ւ�ᬕ�L.3�E�\����\�2\�<\��\�ڰ�\�X�	H�e�\\�\�N���,!H	3�I\\�D�3��c۲\�+\��F	�u|6�	�!��\�\Z9�\"�%�V�\�ϐ�h���?\���i�\�[>\r�b\�(\rm\��#R�\�\�?\�bk��,``\�p֊ZA+��\�\��\�\�\��\�\�\�\�ٞ7sg\��\��NЉ\�.\��O\�<ڱ�\�d\�\�Tpj\'\�G\�[�q�ۡ�\�\���V��G\�\r�\�H\r\��4��5y� c_L.ԸE7\r5n��m��\�^�TXw\�f<��\�\���\�$\�UpYMqǠ�\�l�dq�E{R��\'hmYeL�b\�\�Q%�c�ݡ\��[v�	���H^kD�)r䒇j�o��6\�ǰB\�[^�&bS\�\�4X\�p	�*��\'�\r\�V\�q^\�T���\�T�XW�\r\"MTd@��zV��c���JZ�\�\�J3����i��\�]\�\�I�P\"��=.�~1!\�S|d\�	\�J�j\�ғ\n\�4\n�좺$w\�\�\�q�ռ�\�~\�\�&�3aR�xAy:YG���=�˂ZV\�\�\�P\�\Z\�D\�!\�V\�%\�~�\�v\�\"Z$��Òk�l)g9wʵ�\�d��\�[�\�\�C~S̺\�@�%��-��מ}G�%\�:V[4�:(NQ�XN�v�&&�\�jW\�Ԙ�\�\�5g\�\�ٻ}�M\�\�\�\��\�l1\�\�@����\�8�jN���ΐ8\�ީ\�~b\����E�$Bn�~�YP=Ev�,(�\0�9\�\�\�̪]e�\�\�h�o\�B\�X�\�xZ���\�\�\�\�\�i:9�\�3�\"�\�t�;\���8����Ap�R�\�w\�\�n\�b\�>sg\'-\�e\�\�~\�\�y\�l�\�N/\�@\'�s\�Lj�\�\�Uw@qPQjD�=\�?.�\"\�P���o\�.Q�\rp�1k�\�F\�q�\�L\�PQ,\�T�-0ۙ��d\�\�\�\r\�		\�\��f��(?\�i\�\�@�y\�\�[\0�(�0�s�>�qN1�d��x\�p\�/h$A�\��\'\�s0@L$0�*\�璁\�)�	SK*\�c&3\n�,7h!c�\��T\�X|�	�\Z}�ȋ��U���ѻ\�xR\�\"/��Y\�,]�=�$N\�!\�\�\�=4���TLC\�\�+p�e\"Pq�\\@��\�\�sm\�C�I\�Z����\�#�\09�\�\�U�%\�}Γh�5{[�g�p\no\�\�.\�i�\�ܲIv	ð\�PDd/6a\�\�\��	^�H>\�}�4\�t\�	�ED\�H��(\"	\�\�%�\�Ħ��zZka\�0�N	G\�A\��\�f�\�R\�\�GX�W�ĠTc\�J\��\�+�\�\�[�3V\�\�\�\�^\�\n�Nѹ\0�	7x\�b���.�`H\n!���\r~�W傾\�2�s�I�����YC�%G��Rm\�#���\�+{RrcZ\�#J�\�i�3\�\n}p����\�a�L]���1\r��\�\'u[\�\�\�B�\�DY\Z\�Xc�fB�\�a�ې��B~�Qݢ\��s\�\�[�7X&\�5�r\�\�p��.d������6H�f\�%ϑ��V�\�E��$,\�RڨR\�׃\�W\� \�\�\�e,hJ�J`[xr̋���oV\�\��)F��\�\\&y�S�\nA�!\rm$\�N�\'<O��I\���[c�C\�L+!R@w5\�\�̞��П\�+e\��OR�(\�\�Cr�\�R�.\ni�\�\�n�MzP\�۸��0�j&=\�\�\�sc��\�j\�\�\�{\�R�`�f\�\�&\�%|}�\�\�\�-\�\�.\�2�>\�0w֮I\�<�\�\��/v\�p\�f��\�\�\�VRv\��B����/B�\�N>a��a]%P\�a�Tw�\�\�\�s�\�m\�BmR_C���]g0�hd�\�����G-\�\�zޮ#\�w�\�xe\�o׆w}�d4\�xF�\�ۛM�}Zo�\�U+\�\��\�O�\�w�u7*�3�Ծ!�&pO\n�\�.]\�`Yc\�M\��8yu\�/]�Ӆd\�k�\�&�̴uľe�\�De�ͼ\�\�5پ�s���\�r���m\�\�sg\"\�\�Qo����M[�Gr�C�ml\�0Ğf�V��\�V\�\�%~�1R��k`����?�\�&\�g]�L2\�	y�I�\��N�N\�\�A%fWT�(�\��sѧs �=���\�\�\�];o[9\"�\�L�~\�\�\Z�}�ۛm\�\�\�H\�n\�E��(�ƜT�?s\n\�)r!��̠HO�ҭm�n\�u\�t\�\�Y\rz\�3Z��~\����Y-�v�\�\�\��M\�\�OV\�q˘/e x�>W\�\�H\�\�5�\�T\�ۤ\�\�\�$\�\no��f\�\�4$v<\�y\���\�\�w���z%<<\\r�#4Уի^\�Qܑur6\�i`x�\�Q{\��`\�\�\�L�\�⢀�Ql!\��\�P���u��K�m�\�<D�\�A\�]�\rZ\n|Wpڽ�EG�6�\�Ff\�5{.��l\�LN����{\�ڀ\�YIP\�ƣW� 跆oO/\�f��}���>!77\�\ZyH}8��\�\���a��\�R\�]\�<�i\\\0��\�\�7�{�畢\�\�QW?\n2�č�\�\�\�r=d���5c�\�,\�G�\�\�,�,G\r���SZ\�~\�)�\�d��\�p)_r��\��	\�\�\�\n\�AEt`���AEx�\0B\�\�3m��\�\�\�,�Jm\�޺\�\nPѯIK8|WjVM�׀R�F�ثt�\�x\Z占y\r\�+\�CP�FY��\�\�{�\n{��A�n\�[a\�L\�Lp�\�\�O�EE\�e^\�\�l\�ɴ\�ڿ\�\�u\�h#�\�\'�!ށ�\��d ػEr]h�\�,�R�\�\�w\'V\ZF\�\�?\�9%Zռ݀\"F�\�&�6\����4֤��\���.(�\�סj߿\�a~{�P\Z_�W\�\�s\nv%�\����\�9�y((TI���\�ێ��/�\����\�\r0zOJ���\�P\�\\\�m0\���\��\�\�\�ܾ\�H�O\��\�\�\�_�\�\'�`!\�\0�\�\�53\�\�\�ֹ\�\�\0ߚ���RK\�{�/��ڕ\�^�i\�%6E5�ݭ\�g\��T\\ٔ\��ŋ�,(�d��U]��C\�\�#\��9t%	�`�\�G\�OG(q�&q�\'i\�:��mSIm���]�\�[�!\\՜\�o�\�\�$\�ir���\�7�\rnOu�>I�\�.\��J=�c\�Y\�}���\�\�\�l\��\�4{	�I\r�\�\'\�?M(*�\�\�\�:�\�\�\�o���Y�ԃ��\�#\���-\�{�\�Ы�ړ\�\�,K\���#�l\�\�\\�(�\0�c�\�\�J��\��\\Y�\�\�\�\�\�\�=\ncV^�\�\�ZI\�\Z�\�r<�kǮ��\�3\��\�\�*�ן&�ET\\\�\�O\�\'Ke���~�K](��:�,[\��\n��1��g\�\�\�\"9]ri\���\�\�m�*�Ǩ\Z|\�e\Z\�\�\�!\�Z�[\�7LFo����߯Z�u$\�#д[&\�<�\�fmd*�\�}\�\�)�\�_l�0�]\�Ӕ�\�w\Z���|v���\�9\�`W�����tM��\�G�\�\�\�r�\�=+7\�\��ˇ;�U��5�3j�\�\�\n\n/�b��v�\�=B�:�����C�q��-\�\�\��J�\�A\�\�\�)[\�Mï\�n\��u����u���ùr�-\�!\�\�l=\�\0g\�,\�k\�/�x{ƖRgH�\�𐧯y\�̬\�\���3J9k��M\�a\�$�r�\�+q�\�`\�\�\�ڂU�\�\�\�˚\�\�?\���7U���\\JO�e��.D���k�8\�\�\�M\�^�����\Z�7>oK\�,ak\�hy�\�\�\�\�{\�޻\�\�\�\�ٛ�\�k&y�oϻ\�\�\��o\�e>��\�\�)�~w\��\�C�l��Pr�\�Y��#Nb\�\�\'�Ðv�gm\�8�ǋ��z�\�\�\�vp\�\��\'@	\r_\�ʨ�)�W�*�fCT��u�\�+�U��Ho\�=լv\��ZEe㧫\�q�j�լl\0f\\\�=2�T\�f�{�0\�R��FbVzVY�+xhx�-p\�\0�\Zg\�\�\�8\�dS\�7\�ɦ~\�MH��\'!j�l\�W�v\�.\�5�l\�x~\��K��0���v�^C`o\�\�\�XH\�Nۡ\�\�n��\�vHY\��(pB\Z�{a;\�8�\�\� ��\�\�{�~��\�\\o8\�a\�\��Ý\�\�'),
(2,'3_889e48f5c804bf97',1817284817,'x�\�:\�v\�ȑy����\�$��H�w�bV\�\�\Z[�bjƳ�sx\Z@l�\�uq��O�oȾ\�\��\�R\�\r�\0E\�\�\�d��\�\�@���\�4\�\�q�\�7�2\Z�)�]>l\�\�?MK��wN�3�F_�9����#2S\�x�l����&ў0�\�\�\�5F�\�3�ќ)J���=+W�\��g��l�<�\�\�Kr\�<\�#p��\�L��x�\�x\�\"6\�̸\�ID2�f1#*%豯\0]\�\0%�`��K�Ls\�3r`8\'g4�\�xy,\�]�\�\n�r\�i\�_0�̎��̘ �+J\�,�@h���,�\�<Oxvr�]\�\�\�\�Nek?\�n�f�8�A\�v�n��\�:�rt\�H�&��`4\0V3\�P|\� \�u�mN�0s�\0O\�\�\�\�͂#�L\ru����TD�g����yr\�=��Ef��{V#\�1\�fΓFH��\�U\�\�.nw�$�C���\��m\�\\\�rZN?t��]�\�uz�\�}\�\�t-\�2\�a\Zn\0&\�^q�\�\�ECrȳx�\\�1�XH�hD\�/�I�i\��ߌ\Z��q�̳gEd�*)�o\�2\�>8�Xu٤����1�J	K�\�\� wW\\\�$L5�\�΃;�����\�=\09~�\\cJ%x�l\��i\���A\�^\�\�:�\�}�\�\�z�}wȥjH@\�2\�\�N�\�\���Ngm_\�\�\�\�$M�O\�uYbP\�N�\�\�I\\��F\0���5\�ڳ\�֪\�zj�8yip[\�W�t����1�a�X�7��\��1AJ\�&�%:(��@�1��c\�2\�J\�%�F	��\n>�ʘ�PEm�\�S���\�\��F\�� \nm�\�ƺ��ڬ{�G��6J[{\�\�\"�\�o+11\�D\�30d0m�\r�\�\��trqzy\�\�tr\�\�v�7u���\�\��-�\�|Ȣ\��~w˶\"�upD[�S��Smo�G`\�\�\�V\��t\�\�hg��bq\� \�k\�\�h1k|� #O�\'jԠ\�\Z5\n\�֌]QwBV\�\��G\�)O n7�\0-a=Il[V]\���8�\�i�nО�SB\��-\�L\'X�\�:�\�\"\�\�8N��a\'\ZC\��hD\�V#Lm �y�f{�\�m�|3��\�\�VD��}��\Z.�\�Q	�\�8�\�ު9\�+:����\�>�\�J�F�n��(2\�\��\�\���RIk|Q\\i��N�\�\��H\�\��N҃�r\�\�Eq\��	A\�![�\\�+Eʅ�IO*p\�T(��IyI\�\�=\��x�֣�\�M�L^g¤\�ќ\�d��Z\�gs\��������\�-\�%3�\��\�/�K�}\�\�\0�O�\�+���k9͸S�\�\�6͕\�\�\��_^0=��bV\��\\+q\�m\�\�\�{\�-@V��ܢd\�Aq�\�\�Zs��\�\�\�09�W\�2�Ƅ\\F�]�Ho\��&i�\r�/�ŌC��\�YJ\�ૣ����9\�/;g�C��\�%����\�fA\�\�2?�\� ��53�v�\��̧ٞ�mm�Cʓr�\�\�$FF�\�>��qў�r�~�Gt=�\�\�g\�6}\�\�\���Zԙ�n��\�+A@��d\0�\�J\�*Q\�K*cf����$͟�I>\�\�\�z\� \� q�Jݦ\��+5$ԃ!\���_K�m\�=\�M<�\n�\'�n2\�Z\�Sp���\�)VFy<��s<����\'���\�`6Bt ��|~�	\�@ \�ό\�yN^0%X�\0\�\�\�\�\�\�.A�}5�pI\�c�\�G8�B\�\��^�<C\�U�ܱLiJJP�;\�jq�\rpۂh\�\�9[ncV���xB��9Jq_\�\'�E ?��\�P\��Z�����\�Qu�4\�Q�Jů\�C\�J�\�\�\��\��Kǟ�!\0\�\�C�w\�?<��#(�O��sP&��\�\�sr\�@l�p\���.\�f�D/\�ے��\��\\�¯f�}��F\n\rO����{Ѹ\�\���t����V޼�`�x�\����$*c\�\�h�I���x\0�}�E��Za�Z6	�&M�\�\�FE?`[0`.�(�F9\�\�c:��7\\\���\�1��\���B^^AyɅV!\�3\�\�\�]5�Y�\�=g\�j?\�\n@��@m�Q��!�\�Т�IļTUd�\���T�����}\�-7��3Ԉ�A?Q��\�4�W\�\�!\�R\�3��\��h\��\�L@�\�\�\\r{ē2H*\�\�\�Ԩ�WP�)t.��\�.!\�/\Z\���\��\�\�\�srQ\�ka���\�ߤ\�j�v�I:P!��P2���=\�m�?\�)��i\�F�{}Iu�xT\�5\��_V\�\�9.\�\�E\�5L�\���#,\�bsgm�\�\�\�n�|K�/a֛\r7s7���\�t\��\�\"r���\�\��#|�M\�_=�QR\�E�\���\rXƏ6��\�X��x��m�Ϛ\�(��\�\�\�\\^\�u\�A��m�\�\�\�xقW\�<\�fe\�\�7qJ�/Bczw����\��މװ�u|QfUB�^�nGŗ0\�I�	<�B\�D���[X֘t�:;AK3���\�jC2\�4A{\�Zf\�8�=�2\�r�\�\�z^c9\�5k�y}\�~U�\�]\�z�\�k\�\r�~c[�\�6f6\�$\����r[4tH봊\�-�:�\�\�󏡒��ŝ6�}*�\����\��)l?��\�Ng��ݠ\�\���s �i~RD{c򮼜Y:\"�\��m\�\r\�[�h6Y`�/#	����\�3\�D5洼�\�+��\�Aߪ\��tH\�\\\�\�\�Q�)�2O�>����\�^\�\�\�\�/\�\�\�\�޽�_W}�R�\Z\�Dx)}�az�\n�G\�\��h*�\�\�C�\���\�\�\� \�\����Ďg\�0�\�X\�y\�9\�\�\�\�\�p\�m-�h5\�\�\�<\�\�!�;�N\�/y\��]:l?~̾9V|\�\�\0��I\����\�$�b�\0;p�~�Ś\��\�\�[��\�y�n\�\�t]\�\��O\�.�5Z\n|Wh�ZC�¿x��\�\�\��V�t�R�+�L�M\'�\�\r��\�Zq\�S\�\�\�a\�	\����\���T�\��\�!�\���aְ�\�C\�W���vZ,\�\�u\�&r`\�\0f\��\�^\�y��s|\�֏�4��\�`\�\�f��	+a�f͘\�,\r`�E�\�W,,C\r%>��SX\�>\�� �a֒+\�tq\�5\�*K@ߗ\�p=�X:�<\r~\�i\�k�Z����CK�\�*�Q9�����\�\n8<W3��}�k@)Q\�T�\�Mr�f�\�4\�;A�\n(\�W\�H�@�\Zuh�\�2\�\�yJ\�.(����n�\�#`RO�xR},*\Z\�+s�[�ͧ:\�-0�\�P-#EH�xʋw���\�\"\� \�\�<��\�1�\��\�0\�\�\�\�\��(�*\\\�\�\� ŗ\"�\�Lh\r\�\n�����X_\�����&\r�(���V� ��\��P��\��m	{P\ZOI\�,�\�9�ʸ\�\�s�v�3�c�\\\�0	m9x�\��ZZ߸_K�Q�\�\�Rʁ�\�U\�3\��\�C�ҝ\\\�\�\�,�$x\\\�U�~\�\�d�?h�si��͆o��(B6._\0|\�@��JB\�A}\�\�,�\��HW����\�\�mo�XK+/����Rʺd�/,N\����~�\��d1;�G\�\�f\�M\�L�����p9D��s��j}DҶ��6D\�\�.�A\�,\��jN\��1\�Q�z4��ˣd͛\�\Z�g�ƞ&\�$\��mH5cʘ\�\�{�)�ȣ\�l�q\�e�\Zz�\n\�\�\��\�uJrT\�j\�w\\\�N�,`\�xP\�\�vص�\�\�=Dw\�\�mE|{�&>{\�\�MttVB\0\�(\��v)\��pCE.�\�v\�\�yf\�\�+�\�W;b�$p�L���T���ݭ\�^\"\���Wr���\�,�\�\nG�5V>K)һ̽��\\\�\�\�T��t\�\��\�\'P�fO����\�\�5W�F��L\�~3TR=A\�p�i?i@7�)��V\�ƶ�\���:$\�\�\�i	\�4m�I4\�>\0�Gk�\n t1��b�\�&ӓ�H��n�V�η%H�k\\�C\rv\�?��\�\�K״=\Z\�|�\�\�=T4���u�\�\�L��\�\�EĎfYi~	\�\�K�ӹ���\�\�l\�vс\��\�B\�\�=\�b\�o\�ĩf˪}{e%\�\� ��!\�p�\�s\�\�+��bՠ��S��NQ\�\�<x�-\��\�l5�\0g\',\�[\�/�xή�ΐx�\�!O/x�D9�~�\�\�LPL�z�S)Xp	B��g%�0v\��^Q�:b?[�kQKZ\�)X\�,�\�\�\�\�\\鉳\�q\�=\�\�\�)ơy\�\�t�\��aJ*z�\�G㫶�\�b6���V�\�0m�\�;\�ݼ��)k_�����`�\'��M�.\�\�\�u��J1\�\�{\�_�[E����^�\�9\�4R\��\�\Z�7ً\�\�?��\��\�!z�\�\�\�;iwr\n�\�`E��������񑗳*VN[Z�\�\�*\�Z��r�fV[EfX���\�B\�]�\�jZ\�i\�;�Ɣ\�f�?V	R<\0�\�aΎ\�J��\�\�V�\�<0z\�\�h���\�\�\�/(\�i�b]\�ҟ�n2.Xݙ��\�~�\�S�\r�^�\�\��0lR\�\�w<x\�;�p\�\��v8\�PF�6�\�m\��^�\�g\�^\�����凝.\�z�\��\�\�~\�ޠ\�t\0i5�?47��');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'3_0f0092e5cdbe24fb','pages_3'),
(2,'3_0f0092e5cdbe24fb','pages_1'),
(3,'3_0f0092e5cdbe24fb','sys_file_1'),
(4,'3_0f0092e5cdbe24fb','sys_file_metadata_1'),
(5,'3_0f0092e5cdbe24fb','tt_content_8'),
(6,'3_0f0092e5cdbe24fb','tx_news_domain_model_news_5'),
(7,'3_0f0092e5cdbe24fb','tx_news_uid_5'),
(8,'3_0f0092e5cdbe24fb','sys_category_1'),
(9,'3_0f0092e5cdbe24fb','sys_file_8'),
(10,'3_0f0092e5cdbe24fb','sys_file_metadata_8'),
(11,'3_0f0092e5cdbe24fb','pageId_3'),
(12,'3_889e48f5c804bf97','pages_3'),
(13,'3_889e48f5c804bf97','pages_1'),
(14,'3_889e48f5c804bf97','sys_file_1'),
(15,'3_889e48f5c804bf97','sys_file_metadata_1'),
(16,'3_889e48f5c804bf97','tt_content_8'),
(17,'3_889e48f5c804bf97','tx_news_domain_model_news_4'),
(18,'3_889e48f5c804bf97','tx_news_uid_4'),
(19,'3_889e48f5c804bf97','sys_file_8'),
(20,'3_889e48f5c804bf97','sys_file_metadata_8'),
(21,'3_889e48f5c804bf97','pageId_3');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'3__0_0_0_0',1788340816,'x�\�VK�\�6�+�\�F�\�\�S�\�\�\�śCO��e\�ʢJR\�zv\��$%����\�L��	(�\0>\0\�Mڼ\�&y�MY4/�\�5\�\�i\���݃�F\'% M��Ƨ\�e��Y��;�!�b\�MV\'E��l\"\�z�����GN)�n\"�*�\�\'�`\�h�TMt`��b\��I�(�\�A%�\�Cg\�IjtYIq~\��|\�\\���\��\\\��<-V���(\�㡛p\�\��Ձ�>�4b\�}+1I\�\�\��m�\�$�1\��\�8��֗%	M�F.z\��I$�\�xV\�{9tvu\�V8�\Z2yRhRL:+\�|	�ۜn��?X&$��\�5S\�1:��\�K+\�\�[\���=�\�n��\�\�>�\�\��\�@M\�\nH&ք�AC\�\�A�\n.Y:�	ᅁ�\�\�ȞG$$\�\�\"�s\�NxD�\�՗\�1;�!�Dœ��l\�9\\[M|�~���\�\��\��a�j�_���ȱ�\��\�#\�\��~\�\�L\0�\�㈴d\�\"\�0\��\����2�0\�\�\�El���!\�Q\�v�Ҫ ���eg���`a\����>h\Z\Zˎ\�\0�\�z><-�\�ؾWk\��X\�O�\�w\Z8\��Ӡy\�o�31�#C��Ðb��]��G Ű$\�\�\�\�t���\�\�,$Us�3kn{�JKL� f<i0�5=\�@D1xp\�C���WȰJ\n�\�F\�\�D§�00��+\�\'Հȡ\�C\�[L��\�ha�?�\�\�J4\0)P=\�ֶ�rD| �D\�U�w	#\�<e\�!�:��g\�j\�%r��ɀ��\�3S\�A�\�-4Z��\�Ƶ�\�{u��\�$[O\��k\����z\�ݘ�1��:�%\��W\�\�bL6�1���:��\�\�b��]\\}\�Ÿ0\�[^�en\����P�7k\�:\�un\�=7�E�\�\�v�Uc(�\�y5CB;\�z=Y4d�\�b�c\'\�Et\�\�|�\��@x��7\�\�J~�8)\�3�&\�M3\�\�ƒ�\�\�K����Lv\'����nr,\�<��x\�\�\�Zp�O\�ei�+\�ZlbN�J\�/~��\�\��|w9qِV�7��\�pRl��@�gy�_�\�|o�*M\��\�\�凉uW/>\�\�\�\�c/x\��G�w`?�\��.��\�w���\�Z!�<\��O�\��\�\��￿\��\�ږt�\�E\\eV���E�Ѳ\��I\�椎�,-)\�\�IK	Kk�\���h˼��v��]\�ʶ\�q����0\�Ѥ�q�]B�M');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'3__0_0_0_0','pageId_1'),
(2,'3__0_0_0_0','pageId_3');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_ausbildung_items`
--

DROP TABLE IF EXISTS `lueg_ausbildung_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_ausbildung_items` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_ausbildung_items`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_ausbildung_items` WRITE;
/*!40000 ALTER TABLE `lueg_ausbildung_items` DISABLE KEYS */;
INSERT INTO `lueg_ausbildung_items` VALUES
(1,1,1785748737,1785502894,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"content\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,'Voraussetzungen FaGe','<p><strong>Voraussetzungen FaGe Lehre</strong></p>\r\n<ul><li data-list-item-id=\"e378522b5fd3817e204d231e18a896c08\">Abgeschlossene obligatorische Schulzeit</li><li data-list-item-id=\"eb0b4d375d6b9a81b8bf691a5727dcfe2\">Einfühlungsvermögen, wertschätzende Grundhaltung und Freude an der Kommunikation</li><li data-list-item-id=\"ee1e438cf4c182c8d422e28bf908b4bb6\">Aufmerksamkeit und Sorgfalt</li><li data-list-item-id=\"ecf3c6621fdedca1f89d0bd88736e1d1c\">Flexibilität und Organisationstalent</li><li data-list-item-id=\"e1675db02db4bce2d285e2771b5b77466\">Verantwortungsbewusstsein</li><li data-list-item-id=\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\">Freude mit hoher Selbständigkeit und im Team zu arbeiten</li><li data-list-item-id=\"e0d402a34bd785928815742fcbda596bc\">Belastbarkeit</li><li data-list-item-id=\"e7450638fb1d37dc29b77dafc1e364006\">Bereitschaft, sobald als möglich die Autoprüfung zu absolvieren</li></ul>\r\n<p><strong>Voraussetzungen FaGe E (verkürzte Lehre für Erwachsene)</strong></p>\r\n<ul><li data-list-item-id=\"eb44665fe731bbc479123d81973a72d85\">Mindestens 22 Jahre alt</li><li data-list-item-id=\"ef15ab3516e7903e712e85160a0390bcd\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet</li><li data-list-item-id=\"e60d3dd231256f50255d39c90ecc5e9d6\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung</li><li data-list-item-id=\"ebfe6f1c01f9bfd60f4522f2a105e5498\">Gute Deutschkenntnisse</li><li data-list-item-id=\"e3c82f6f7ba46d58eaacee47b9b7795b6\">Gute mündliche und schriftliche Ausdrucksfähigkeit</li><li data-list-item-id=\"ea9a85af9bf1394a4101b4721b42c598e\">Abschluss Allgemeinbildung (ABU)</li></ul>',3),
(2,1,1785748737,1785502894,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'Berufswahlpraktikum','<p><strong>Pflege – mein Beruf?</strong></p><p>Wenn du gerne mit und für Menschen arbeitest, könnte ein Pflegeberuf genau das Richtige für dich sein. Mit einem Berufswahlpraktikum bei der Spitex Region Lueg erlebst du den Spitex-Alltag hautnah.</p>',3),
(3,1,1785748737,1785502894,0,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'Weiterbildung','<p>Wir unterstützen dich bei deiner fachlichen und persönlichen Weiterentwicklung – mit internen Angeboten und externen Kursen.</p>',3);
/*!40000 ALTER TABLE `lueg_ausbildung_items` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_benefits_tiles`
--

DROP TABLE IF EXISTS `lueg_benefits_tiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_benefits_tiles` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `color` varchar(255) NOT NULL DEFAULT 'sky',
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_benefits_tiles`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_benefits_tiles` WRITE;
/*!40000 ALTER TABLE `lueg_benefits_tiles` DISABLE KEYS */;
INSERT INTO `lueg_benefits_tiles` VALUES
(1,1,1785746902,1785503461,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'sky',1,'Weiterbildungen','<p>Dein Wissen, unsere Unterstützung – profitiere von internen Weiterbildungen und Entwicklungschancen.</p>',4),
(2,1,1785746902,1785503461,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'purple',1,'Kinderzulage plus / familienfreundlich','<p>Wir unterstützen dich mit einer zusätzlichen Betreuungszulage und 16 Wochen Mutterschaftsurlaub bei 100 % Lohn.</p>',4),
(3,1,1785746902,1785503461,0,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'orange',1,'Win a colleague','<p>Wenn deine Empfehlung zu einer Anstellung führt, bekommst du eine Prämie von 1000 Franken.</p>',4),
(4,1,1785746902,1785503461,0,0,0,0,'0',4,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'pink',1,'Fitnessabo / Sportverein','<p>Wir unterstützen deine Gesundheit mit einem Beitrag an ein Fitnessabo oder einen Sportverein.</p>',4),
(5,1,1785746902,1785503461,0,0,0,0,'0',5,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'orange',1,'Kostenlose Parkmöglichkeiten','<p>Stressfrei ankommen – wir stellen dir kostenfreie Parkplätze zur Verfügung.</p>',4),
(6,1,1785746902,1785503461,0,0,0,0,'0',6,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'pink',1,'Mitgestaltung','<p>Wirke aktiv mit – setz deine Fähigkeiten bei uns gezielt ein.</p>',4),
(7,1,1785746902,1785503461,0,0,0,0,'0',7,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'sky',1,'Coaching Angebot','<p>Bei uns kannst du von bis zu 3 Coaching-Gesprächen profitieren – wir übernehmen die Kosten.</p>',4),
(8,1,1785746902,1785503461,0,0,0,0,'0',8,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'teal',1,'Team-Events','<p>An unser Sommerfest und die Team-Events bist du herzlich eingeladen.</p>',4),
(9,1,1785746902,1785503461,0,0,0,0,'0',9,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'purple',1,'Beitrag zur Mobilität','<p>Unseren Lernenden bezahlen wir das Halbtax-Abo.</p>',4),
(10,1,1785746902,1785503461,0,0,0,0,'0',10,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'teal',1,'Grippe-Prophylaxe','<p>Wir sorgen dafür, dass du gesund durch die Erkältungssaison kommst.</p>',4);
/*!40000 ALTER TABLE `lueg_benefits_tiles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_podcasts_episodes`
--

DROP TABLE IF EXISTS `lueg_podcasts_episodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_podcasts_episodes` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `claim` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `mediafile` int(10) unsigned NOT NULL DEFAULT 0,
  `poster` int(10) unsigned NOT NULL DEFAULT 0,
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_podcasts_episodes`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_podcasts_episodes` WRITE;
/*!40000 ALTER TABLE `lueg_podcasts_episodes` DISABLE KEYS */;
INSERT INTO `lueg_podcasts_episodes` VALUES
(1,1,1785498866,1785497882,0,0,0,0,'0',1,0,0,0,0,NULL,'{\"claim\":\"\",\"description\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"mediafile\":\"\",\"poster\":\"\",\"starttime\":\"\"}',0,0,0,0,'Starte dort, wo du wirklich gebraucht wirst','Lernende bei der Spitex Region Lueg',1,1,2),
(2,1,1785498866,1785497882,0,0,0,0,'0',2,0,0,0,0,NULL,'{\"claim\":\"\",\"description\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"mediafile\":\"\",\"poster\":\"\",\"starttime\":\"\"}',0,0,0,0,'Jeder Tag bringt eine neue Geschichte','Pflegefachfrau bei der Spitex Region Lueg',1,1,2);
/*!40000 ALTER TABLE `lueg_podcasts_episodes` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `lueg_stellen_stellen`
--

DROP TABLE IF EXISTS `lueg_stellen_stellen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lueg_stellen_stellen` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tag` varchar(255) NOT NULL DEFAULT '',
  `intro` longtext DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `foreign_table_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent_uid` (`foreign_table_parent_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lueg_stellen_stellen`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `lueg_stellen_stellen` WRITE;
/*!40000 ALTER TABLE `lueg_stellen_stellen` DISABLE KEYS */;
INSERT INTO `lueg_stellen_stellen` VALUES
(1,1,1785746473,1785745312,1,0,0,0,'0',1,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Zur Erweiterung unseres Fachteams Psychiatrie in Hasle-Rüegsau b. Burgdorf suchen wir','Pflegefachperson FH, Bachelor of Science in Pflege, Schwerpunkt Psychiatrie 40 – 60%','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/pflegefachperson-fh-bachelor-of-science-in-pflege-schwerpunkt-psychiatrie-40-60.php',6),
(2,1,1785746473,1785745312,1,0,0,0,'0',2,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Für unseren Standort Weier i. E. suchen wir\nnach Vereinbarung','Pflegeassistent/in oder Pflegehelfende SRK 40-50%','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/pflegeasisstent-in-oder-pflegehelfer-in-srk-40-60.php',6),
(3,1,1785746473,1785745312,1,0,0,0,'0',3,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Für unsere Standorte suchen wir ab sofort oder\nnach Vereinbarung','Fachfrau / Fachmann Gesundheit EFZ, mit / ohne Berufsbildner 50-80 %','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/fachfrau-fachmann-gesundheit-efz.php',6),
(4,1,1785746473,1785745312,1,0,0,0,'0',4,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'','Für unsere Standorte Hasle-Rüegsau, Sumiswald und Weier\nsuchen wir ab sofort oder nach Vereinbarung','Dipl. Pflegefachperson HF 40-80%','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/dipl-pflegefachperson-hf-dn-ii-akp-40-60.php',6),
(5,1,1785746473,1785745312,1,0,0,0,'0',5,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'Lehrstelle','Per 1. August 2027 bieten wir an unseren vier\nStandorten je eine','Lehrstelle als Fachfrau/Fachmann Gesundheit EFZ oder als FaGe E (verkürzte Ausbildung für Erwachsene)','https://www.spitexlueg.ch/de/aktuelles/stelleninserate/lehrstelle-als-fachfrau-fachmann-gesundheit-efz-oder-als-fage-e-verkuerzte-ausbildung-fuer-erwachsene.php',6);
/*!40000 ALTER TABLE `lueg_stellen_stellen` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` longtext DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1785490041,1785486308,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1785748229,0,0,0,0,0.5,1,'Lueg','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',1,1,0,'',0,'pagets__default','pagets__default','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,1,1785491662,1785491657,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Podcasts','/podcasts',NULL,0,0,0,0,'',0,'','','Podcasts',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(3,1,1785746473,1785491690,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,1785746473,0,0,0,0,0.5,1,'Freie Stellen','/freie',NULL,0,0,0,0,'',0,'','','freie-stellen',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(4,1,1785491743,1785491709,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Benefits','/benefits',NULL,0,0,0,0,'',0,'','','Benefits',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(5,1,1785491741,1785491735,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Direkt bewerben','/direkt-bewerben',NULL,0,0,0,0,'',0,'','','Direkt-bewerben',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(6,1,1785491933,1785491929,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,3,'Standorte Spitex Region Lueg','/standorte-spitex-region-lueg',NULL,0,0,0,0,'',0,'','','Standorte',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(7,1,1785491945,1785491942,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Storage','/storage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(8,1,1785745614,1785745609,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Jobs','/jobs',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(9,1,1785747726,1785747720,0,0,0,0,'0',1408,NULL,0,0,0,0,NULL,'{\"nav_hide\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,1,'Datenschutz','/datenschutz',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,8,1785748739,1785748739,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,0,0,0,'Lehrstelle',0,0,0,0,'','','',NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,5,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1785490037,1785490037,'/user_upload/SPITEX_SCHUH-77_2.jpg','b4cc8c1f1d5021cb2c14d7c3ae3c7ece78f40992','19669f1e02c2f16705ec7587044c66443be70725','jpg','SPITEX_SCHUH-77_2.jpg','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba',1785490037,1785490037,1020742,1,2,'image/jpeg',0,0),
(3,0,1785497882,1785497882,'/user_upload/podcast-demo-1.wav','59783830b95b9a1f74761adb88a21446627000f0','19669f1e02c2f16705ec7587044c66443be70725','wav','podcast-demo-1.wav','21724154088ac378f569066f57f4d8bd0c148fba',1785497849,1785497849,24044,1,3,'audio/x-wav',0,0),
(4,0,1785497882,1785497882,'/user_upload/podcast-demo-2.wav','7d8695ea9705d31aede3c5812b9ceca1986d40f3','19669f1e02c2f16705ec7587044c66443be70725','wav','podcast-demo-2.wav','4e121e877971d9cd60c98587b23c07b761025e50',1785497849,1785497849,24044,1,3,'audio/x-wav',0,0),
(5,0,1785498501,1785498501,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1785485715,1785485715,0,1,5,'application/x-empty',0,0),
(6,0,1785498521,1785498521,'/user_upload/podcasts/test.jpg','fced536a20ee4b1227b4c33bf2dd73958ca52a23','139c5f340a12ff6d76b8a7fb5f8d88f9e172df9d','jpg','test.jpg','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd',1785498521,1785498521,2944890,1,2,'image/jpeg',0,0),
(7,0,1785498691,1785498691,'/user_upload/Bildschirmfoto_2026-07-31_um_13.51.25.png','a0ee235bbe3ae1a02d1ec17bb2678e3f676910a5','19669f1e02c2f16705ec7587044c66443be70725','png','Bildschirmfoto_2026-07-31_um_13.51.25.png','6533ff2478b8f1307b2d80356159ecd843b89473',1785498691,1785498691,11892016,1,2,'image/png',0,0),
(8,0,1785501118,1785501118,'/favicon/spitex-favicon.png','0238aee2076656b4b28a527cbc1d5363c0216236','d250a708fb312b9f6db43a2eadf8a1882a93e725','png','spitex-favicon.png','06ff5592072e31318f265c9d4214b57a6f8ce456',1785501104,1785501013,12948,1,2,'image/png',0,0),
(9,0,1785504207,1785504207,'/user_upload/icons/weiterbildung.svg','93ebf22f8b1552eadbeae5ba39e8c931665d6f3f','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','weiterbildung.svg','7a28e1ed9045367999a439d25167b239cd00ab2c',1785504180,1785504180,308,1,2,'image/svg+xml',0,0),
(10,0,1785504207,1785504207,'/user_upload/icons/familie.svg','e9b3709258564ac1ad111b7b32955e1d514725fe','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','familie.svg','0991f88b7af9bcfb4388cf019221ad06ac289292',1785504180,1785504180,385,1,2,'image/svg+xml',0,0),
(11,0,1785504207,1785504207,'/user_upload/icons/empfehlung.svg','7936f8659e5337add9b2b839da548204ccffc3c6','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','empfehlung.svg','44589e3facf2ccbc74d9b01316e15407ecae4f26',1785504180,1785504180,289,1,2,'image/svg+xml',0,0),
(12,0,1785504207,1785504207,'/user_upload/icons/fitness.svg','826e70d2f51d07839554791f46666146dfe56539','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','fitness.svg','da4787f47f240e24917b311cb1c1498cb6320127',1785504180,1785504180,353,1,2,'image/svg+xml',0,0),
(13,0,1785504207,1785504207,'/user_upload/icons/parkplatz.svg','a3d2d221a192321d9d738206970f768d172d5a1c','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','parkplatz.svg','448587010e8a0b1b95f2b6851b5adf698bd85354',1785504180,1785504180,264,1,2,'image/svg+xml',0,0),
(14,0,1785504207,1785504207,'/user_upload/icons/mitgestaltung.svg','1c425761bb407c195c41c6a49349addcf3f50f3e','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','mitgestaltung.svg','4be54d2dccd5e4d9d01665b9485a481ff5e9503d',1785504180,1785504180,281,1,2,'image/svg+xml',0,0),
(15,0,1785504207,1785504207,'/user_upload/icons/coaching.svg','e5d368012dd9f9d23e7fd5f7e0e2b374c1dd10e6','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','coaching.svg','32ef701922af80da8b5adbe2d08190edd38eac1e',1785504180,1785504180,319,1,2,'image/svg+xml',0,0),
(16,0,1785504207,1785504207,'/user_upload/icons/team.svg','c81ad786e3d01bf9c7bb1a24ff338c6a0a0e1cc8','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','team.svg','a71039589805fbb93729c8bfd6460fea3417b6de',1785504180,1785504180,348,1,2,'image/svg+xml',0,0),
(17,0,1785504207,1785504207,'/user_upload/icons/mobilitaet.svg','ad4648537cebb3f21d9f1a00a83373ea8d4c5b33','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','mobilitaet.svg','5c39a033c64954eedb882c92a417e8b56fee16e1',1785504180,1785504180,337,1,2,'image/svg+xml',0,0),
(18,0,1785504207,1785504207,'/user_upload/icons/gesundheit.svg','43820fc67a2b21f7ba91c1871765d31e89ec2119','0254dba25222ae8bfa0ee1b38a90ca349548b97d','svg','gesundheit.svg','05fa4f036d55081fb5c94fd157514a90482f5e34',1785504180,1785504180,243,1,2,'image/svg+xml',0,0),
(19,0,1785509214,1785509214,'/user_upload/Homepage/standort-weier.jpg','2c2bae590285de1ca51e5a93126a27fbe1ee8eb3','c3bc98602796440503b991e8b2595fcaa67ff01c','jpg','standort-weier.jpg','e50628414c2574017711e28be06fe7fb7a2cbc9d',1785509214,1785509214,467637,1,2,'image/jpeg',0,0),
(20,0,1785509265,1785509265,'/user_upload/spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp','0c542d7bb9972623ea5f3f90a426136c5e8c0b35','19669f1e02c2f16705ec7587044c66443be70725','webp','spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp','a3c86044ef4a40ce9fccc13fd56b6323544a1eca',1785509265,1785509265,118238,1,2,'image/webp',0,0),
(21,0,1785509423,1785509423,'/user_upload/Homepage/Frontbild_SR_2.webp','c2157ed9b6bf4fa50f5f1a969d7ae1be031b2ebc','c3bc98602796440503b991e8b2595fcaa67ff01c','webp','Frontbild_SR_2.webp','9c563176a47dedebeec108e29fc9b8ae8127403b',1785509423,1785509423,557084,1,2,'image/webp',0,0),
(22,0,1785509465,1785509465,'/user_upload/Homepage/spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp','1e66f18230dda608781cc6a6a270d2ac42006b0e','c3bc98602796440503b991e8b2595fcaa67ff01c','webp','spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp','dfe424e51de593e0765291a0266432375413a938',1785509465,1785509465,269444,1,2,'image/webp',0,0),
(23,0,1785743003,1785743003,'/user_upload/icons_OK/Fitness.svg','4b9739b096335f086eccca1628deeb2f49314b28','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Fitness.svg','a890703c476a701fff4d7b48ff3d2b397c6cdc15',1785743003,1785743003,1628,1,2,'image/svg+xml',0,0),
(24,0,1785743003,1785743003,'/user_upload/icons_OK/TEAM-EVENTS.svg','0720c26162024dd03a6404c3f06eb1c529d27bab','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','TEAM-EVENTS.svg','357ebef8c4299621cebf7641d896da5bd2395ac0',1785743003,1785743003,2806,1,2,'image/svg+xml',0,0),
(25,0,1785743003,1785743003,'/user_upload/icons_OK/Chat.svg','f8e7ff15f86c385bf2ba4f57d183919dd7cd6cac','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Chat.svg','80dde84560c5c02140efddf0abfb7997a7720971',1785743003,1785743003,1798,1,2,'image/svg+xml',0,0),
(26,0,1785743003,1785743003,'/user_upload/icons_OK/MITGESTALTUNG.svg','0e53449a25e48174ca4af7fc842860aa5cb7c715','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','MITGESTALTUNG.svg','5073125ea2c6d56310b8f42d45cc177c30c8f02e',1785743003,1785743003,3756,1,2,'image/svg+xml',0,0),
(27,0,1785743003,1785743003,'/user_upload/icons_OK/Pin.svg','33b2ee482ae3b875fb7a9e408c7e36955d60aeb7','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Pin.svg','61068b3dc040ebe8d99ef09780cb7ce33ab249fb',1785743003,1785743003,986,1,2,'image/svg+xml',0,0),
(28,0,1785743003,1785743003,'/user_upload/icons_OK/Mobilitaet.svg','69e5f81261c49cbf03d08a86fceda29cb37643c6','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Mobilitaet.svg','18ac53db50b479c2a2e6717a025fd32cb7fda582',1785743003,1785743003,2439,1,2,'image/svg+xml',0,0),
(29,0,1785743003,1785743003,'/user_upload/icons_OK/Familie.svg','3a7aa207b1a5c8fcd0fbfe8e34aa3ddd56715cd5','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Familie.svg','5abe3d909da1cf0e493adbdde448a9364b24fb90',1785743003,1785743003,2645,1,2,'image/svg+xml',0,0),
(30,0,1785743003,1785743003,'/user_upload/icons_OK/win_a_collegue.svg','eae321849390a960c086ce3b66e62034b2612e56','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','win_a_collegue.svg','a883cb4b3fbbba750a6dc51b0be7bc169f8ea92d',1785743003,1785743003,2082,1,2,'image/svg+xml',0,0),
(31,0,1785743003,1785743003,'/user_upload/icons_OK/Grippe.svg','155b23674a0c345478039b4879b7c3064103c7f2','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Grippe.svg','1e34601e49ac1b5717d343b40bbdfae5eb1d5065',1785743003,1785743003,1241,1,2,'image/svg+xml',0,0),
(32,0,1785743003,1785743003,'/user_upload/icons_OK/Ausbildung.svg','fb19deadde7a666231ec64431a3c4a7fb9b4b794','79022834121416bd1da7ecf535e59c2dd73ff60b','svg','Ausbildung.svg','406631126905837655d0b70eb484127f009a0bf7',1785743003,1785743003,2939,1,2,'image/svg+xml',0,0),
(33,0,1785746489,1785746489,'/_assets/f6ef6adaf5c92bf687a31a3adbcb0f7b/Images/dummy-preview-image.png','35bdcfc42903a4189e40028928741a79bc48cf24','557d1939219cbaef9f24c50a9ca50baf799cfe0a','png','dummy-preview-image.png','b069aa085f06da6743b904400b0e412c3b0b5b07',1785745927,1779137606,25896,0,2,'image/png',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1785490037,1785490037,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,2280,1895),
(2,0,1785490085,1785490085,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,1800,1000),
(3,0,1785497882,1785497882,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,0,0),
(4,0,1785497882,1785497882,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,0,0),
(5,0,1785498501,1785498501,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,0,0),
(6,0,1785498521,1785498521,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,3364,2020),
(7,0,1785498691,1785498691,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,3308,2184),
(8,0,1785501117,1785501117,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,439,439),
(9,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,48,48),
(10,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,10,NULL,48,48),
(11,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,11,NULL,48,48),
(12,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,12,NULL,48,48),
(13,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,13,NULL,48,48),
(14,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,14,NULL,48,48),
(15,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,15,NULL,48,48),
(16,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,16,NULL,48,48),
(17,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,17,NULL,48,48),
(18,0,1785504206,1785504206,0,0,NULL,'',0,0,0,0,NULL,NULL,0,18,NULL,48,48),
(19,0,1785509214,1785509214,0,0,NULL,'',0,0,0,0,NULL,NULL,0,19,NULL,1126,751),
(20,0,1785509265,1785509265,0,0,NULL,'',0,0,0,0,NULL,NULL,0,20,NULL,1126,751),
(21,0,1785509423,1785509423,0,0,NULL,'',0,0,0,0,NULL,NULL,0,21,NULL,2500,1395),
(22,0,1785509465,1785509465,0,0,NULL,'',0,0,0,0,NULL,NULL,0,22,NULL,1126,751),
(23,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,23,NULL,119,119),
(24,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,24,NULL,119,119),
(25,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,25,NULL,119,119),
(26,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,26,NULL,119,119),
(27,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,27,NULL,119,119),
(28,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,28,NULL,119,119),
(29,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,30,NULL,119,119),
(30,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,29,NULL,119,119),
(31,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,31,NULL,119,119),
(32,0,1785743003,1785743003,0,0,NULL,'',0,0,0,0,NULL,NULL,0,32,NULL,119,119),
(33,0,1785746488,1785746488,0,0,NULL,'',0,0,0,0,NULL,NULL,0,33,NULL,128,128);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1785490037,1785490037,1,1,'/_processed_/f/c/preview_SPITEX_SCHUH-77_2_2658161611.jpg','preview_SPITEX_SCHUH-77_2_2658161611.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.Preview','2658161611',64,53),
(2,1785490037,1785490037,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_6788af91eb.jpg','csm_SPITEX_SCHUH-77_2_6788af91eb.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','6788af91eb',180,150),
(3,1785498413,1785490037,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_14e7b14a64.jpg','csm_SPITEX_SCHUH-77_2_14e7b14a64.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','14e7b14a64',54,45),
(4,1785490401,1785490401,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2200;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','037fdf9c54df759f107ca49571c860f676dae8ae','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','7a3f4201ba',0,0),
(5,1785490802,1785490802,1,2,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8efa321b15bcada168a023d7550b15722242377b','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','8c66315667',0,0),
(6,1785491944,1785491944,1,2,'/_processed_/e/a/csm_hero-lueg_44575b8025.jpg','csm_hero-lueg_44575b8025.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1125c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d4e0b8fa4fe9062871db4f91cbb6b796b64c82fa','f1a1eff0186308fa96461c55ba669dc4bd17c954','Image.CropScaleMask','44575b8025',2000,1125),
(7,1785492221,1785492221,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_e56555b5fb.jpg','csm_SPITEX_SCHUH-77_2_e56555b5fb.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1125c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','d4e0b8fa4fe9062871db4f91cbb6b796b64c82fa','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','e56555b5fb',2000,1125),
(8,1785492402,1785492402,1,1,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:2400;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','8efa321b15bcada168a023d7550b15722242377b','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','b846968f07',0,0),
(9,1785497884,1785497884,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_aadbe5e607.jpg','csm_SPITEX_SCHUH-77_2_aadbe5e607.jpg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','aadbe5e607',1600,1330),
(10,1785498413,1785498413,1,3,'',NULL,'','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','21724154088ac378f569066f57f4d8bd0c148fba','Image.CropScaleMask','45e5f21ca1',0,0),
(11,1785498501,1785498501,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_51fcfddad2.jpg','csm_SPITEX_SCHUH-77_2_51fcfddad2.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','51fcfddad2',138,115),
(12,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_02943daaa8.jpg','csm_test_02943daaa8.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','02943daaa8',166,100),
(13,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_62f470d34a.jpg','csm_test_62f470d34a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','62f470d34a',250,150),
(14,1785498521,1785498521,1,6,'/_processed_/9/8/csm_test_506fc9ef25.jpg','csm_test_506fc9ef25.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','506fc9ef25',60,36),
(15,1785498533,1785498533,1,6,'/_processed_/9/8/csm_test_f8739afa84.jpg','csm_test_f8739afa84.jpg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','f8739afa84',1600,961),
(16,1785498626,1785498626,1,4,'',NULL,'','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','4e121e877971d9cd60c98587b23c07b761025e50','Image.CropScaleMask','f2bac3877a',0,0),
(17,1785498691,1785498691,1,7,'/_processed_/7/8/preview_Bildschirmfoto_2026-07-31_um_13.51.25_caa660e4e3.png','preview_Bildschirmfoto_2026-07-31_um_13.51.25_caa660e4e3.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','6533ff2478b8f1307b2d80356159ecd843b89473','Image.Preview','caa660e4e3',64,42),
(18,1785498691,1785498691,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_22508f7cf5.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_22508f7cf5.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','22508f7cf5',227,150),
(19,1785498691,1785498691,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_353f7372ba.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_353f7372ba.png','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','353f7372ba',60,40),
(20,1785498694,1785498694,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_175e08d87a.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_175e08d87a.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1600;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','815024ad3b82c461e5e0d147ba656adf597c07bd','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','175e08d87a',1600,1056),
(21,1785499136,1785499136,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_782b863c3f.jpg','csm_SPITEX_SCHUH-77_2_782b863c3f.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','782b863c3f',1920,1280),
(22,1785499136,1785499136,1,6,'/_processed_/9/8/csm_test_3fba11eba7.jpg','csm_test_3fba11eba7.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','5b8f136bbfd48eb8c3cca6d7b720b4d074680dfd','Image.CropScaleMask','3fba11eba7',1920,1280),
(23,1785499136,1785499136,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_9865617d25.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_9865617d25.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','9865617d25',1920,1280),
(24,1785507436,1785507436,1,1,'/_processed_/f/c/csm_SPITEX_SCHUH-77_2_52a84846be.jpg','csm_SPITEX_SCHUH-77_2_52a84846be.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','03e2fd58a9cd66ab5f2be102a17ef6ecb06af2ba','Image.CropScaleMask','52a84846be',640,380),
(25,1785509208,1785509208,1,15,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','32ef701922af80da8b5adbe2d08190edd38eac1e','Image.CropScaleMask','84f58b5353',48,48),
(26,1785509208,1785509208,1,11,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','44589e3facf2ccbc74d9b01316e15407ecae4f26','Image.CropScaleMask','87126e49eb',48,48),
(27,1785509208,1785509208,1,10,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','0991f88b7af9bcfb4388cf019221ad06ac289292','Image.CropScaleMask','90e097e9bc',48,48),
(28,1785509208,1785509208,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','da4787f47f240e24917b311cb1c1498cb6320127','Image.CropScaleMask','16cf7f4ccf',48,48),
(29,1785509208,1785509208,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','05fa4f036d55081fb5c94fd157514a90482f5e34','Image.CropScaleMask','35d2b3ef33',48,48),
(30,1785509208,1785509208,1,14,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4be54d2dccd5e4d9d01665b9485a481ff5e9503d','Image.CropScaleMask','3c34cd0a54',48,48),
(31,1785509208,1785509208,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5c39a033c64954eedb882c92a417e8b56fee16e1','Image.CropScaleMask','9ba76819fd',48,48),
(32,1785509208,1785509208,1,13,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','448587010e8a0b1b95f2b6851b5adf698bd85354','Image.CropScaleMask','54ca5817c6',48,48),
(33,1785509208,1785509208,1,16,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a71039589805fbb93729c8bfd6460fea3417b6de','Image.CropScaleMask','ca7f0f2281',48,48),
(34,1785509208,1785509208,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7a28e1ed9045367999a439d25167b239cd00ab2c','Image.CropScaleMask','789a4cffb9',48,48),
(35,1785509214,1785509214,1,19,'/_processed_/a/9/csm_standort-weier_35870212f5.jpg','csm_standort-weier_35870212f5.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','35870212f5',166,111),
(36,1785509216,1785509216,1,19,'/_processed_/a/9/csm_standort-weier_51ccf8e2c9.jpg','csm_standort-weier_51ccf8e2c9.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','51ccf8e2c9',225,150),
(37,1785509216,1785509216,1,19,'/_processed_/a/9/csm_standort-weier_c7a49ad61a.jpg','csm_standort-weier_c7a49ad61a.jpg','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','c7a49ad61a',60,40),
(38,1785509478,1785509265,1,20,'/_processed_/6/2/preview_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_e73e6eef93.webp','preview_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_e73e6eef93.webp','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.Preview','e73e6eef93',64,43),
(39,1785509265,1785509265,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_6b31097e14.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_6b31097e14.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','6b31097e14',225,150),
(40,1785509265,1785509265,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_2e212dd40e.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_2e212dd40e.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','2e212dd40e',60,40),
(41,1785509291,1785509291,1,19,'/_processed_/a/9/csm_standort-weier_96d59c46ba.jpg','csm_standort-weier_96d59c46ba.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','e50628414c2574017711e28be06fe7fb7a2cbc9d','Image.CropScaleMask','96d59c46ba',640,380),
(42,1785509291,1785509291,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_d12264a512.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_d12264a512.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','d12264a512',640,380),
(43,1785509423,1785509423,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_94c15e59e8.webp','csm_Frontbild_SR_2_94c15e59e8.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','94c15e59e8',166,93),
(44,1785509424,1785509424,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_4249a9aa6e.webp','csm_Frontbild_SR_2_4249a9aa6e.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','4249a9aa6e',269,150),
(45,1785509424,1785509424,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_68c36343a8.webp','csm_Frontbild_SR_2_68c36343a8.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','68c36343a8',60,33),
(46,1785509465,1785509465,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_2bad66f211.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_2bad66f211.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','2bad66f211',166,111),
(47,1785509466,1785509466,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_782cd51ba5.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_782cd51ba5.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','782cd51ba5',225,150),
(48,1785509466,1785509466,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_0eee4dc871.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_0eee4dc871.webp','','a:3:{s:8:\"maxWidth\";i:60;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','1d41cec0fcdd6183fb5dc9503635ee0256a30e18','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','0eee4dc871',60,40),
(49,1785509489,1785509489,1,21,'/_processed_/2/d/csm_Frontbild_SR_2_d1ccf23cb2.webp','csm_Frontbild_SR_2_d1ccf23cb2.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','9c563176a47dedebeec108e29fc9b8ae8127403b','Image.CropScaleMask','d1ccf23cb2',640,380),
(50,1785509489,1785509489,1,22,'/_processed_/e/8/csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_909a90f91b.webp','csm_spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x_909a90f91b.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"380c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ae059c3e8b3fd5902bd7c70233abd0d964477cd8','dfe424e51de593e0765291a0266432375413a938','Image.CropScaleMask','909a90f91b',640,380),
(51,1785740608,1785740608,1,7,'/_processed_/7/8/csm_Bildschirmfoto_2026-07-31_um_13.51.25_b50c93929a.png','csm_Bildschirmfoto_2026-07-31_um_13.51.25_b50c93929a.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','6533ff2478b8f1307b2d80356159ecd843b89473','Image.CropScaleMask','b50c93929a',166,110),
(52,1785740608,1785740608,1,3,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','21724154088ac378f569066f57f4d8bd0c148fba','Image.CropScaleMask','1de74212f5',0,0),
(53,1785740608,1785740608,1,4,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4e121e877971d9cd60c98587b23c07b761025e50','Image.CropScaleMask','8111df323b',0,0),
(54,1785740608,1785740608,1,20,'/_processed_/6/2/csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_75bce87f5f.webp','csm_spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x_75bce87f5f.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a3c86044ef4a40ce9fccc13fd56b6323544a1eca','Image.CropScaleMask','75bce87f5f',166,111),
(55,1785743003,1785743003,1,24,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','357ebef8c4299621cebf7641d896da5bd2395ac0','Image.Preview','9916222a98',64,64),
(56,1785743003,1785743003,1,25,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','80dde84560c5c02140efddf0abfb7997a7720971','Image.Preview','5f29c3c396',64,64),
(57,1785743003,1785743003,1,23,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a890703c476a701fff4d7b48ff3d2b397c6cdc15','Image.Preview','8ca1bcd9f0',64,64),
(58,1785743003,1785743003,1,26,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5073125ea2c6d56310b8f42d45cc177c30c8f02e','Image.Preview','1d680b73f7',64,64),
(59,1785743003,1785743003,1,28,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','18ac53db50b479c2a2e6717a025fd32cb7fda582','Image.Preview','8276a29a69',64,64),
(60,1785743003,1785743003,1,27,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','61068b3dc040ebe8d99ef09780cb7ce33ab249fb','Image.Preview','3f47f81b64',64,64),
(61,1785743003,1785743003,1,31,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','1e34601e49ac1b5717d343b40bbdfae5eb1d5065','Image.Preview','ddbeb36d0b',64,64),
(62,1785743003,1785743003,1,30,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','a883cb4b3fbbba750a6dc51b0be7bc169f8ea92d','Image.Preview','59861d824b',64,64),
(63,1785743003,1785743003,1,29,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','5abe3d909da1cf0e493adbdde448a9364b24fb90','Image.Preview','8f96ee1675',64,64),
(64,1785743003,1785743003,1,32,'',NULL,'','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','406631126905837655d0b70eb484127f009a0bf7','Image.Preview','e379131db1',64,64),
(65,1785743005,1785743005,1,32,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','406631126905837655d0b70eb484127f009a0bf7','Image.CropScaleMask','02b9cd7cb0',115,115),
(66,1785743005,1785743005,1,25,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','80dde84560c5c02140efddf0abfb7997a7720971','Image.CropScaleMask','2b0e553126',115,115),
(67,1785743005,1785743005,1,29,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5abe3d909da1cf0e493adbdde448a9364b24fb90','Image.CropScaleMask','557c59f332',115,115),
(68,1785743005,1785743005,1,23,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a890703c476a701fff4d7b48ff3d2b397c6cdc15','Image.CropScaleMask','d50afe0657',115,115),
(69,1785743005,1785743005,1,31,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','1e34601e49ac1b5717d343b40bbdfae5eb1d5065','Image.CropScaleMask','2297efb62f',115,115),
(70,1785743005,1785743005,1,26,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','5073125ea2c6d56310b8f42d45cc177c30c8f02e','Image.CropScaleMask','558603351d',115,115),
(71,1785743005,1785743005,1,28,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','18ac53db50b479c2a2e6717a025fd32cb7fda582','Image.CropScaleMask','7fed278db3',115,115),
(72,1785743005,1785743005,1,27,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','61068b3dc040ebe8d99ef09780cb7ce33ab249fb','Image.CropScaleMask','816b9d6465',115,115),
(73,1785743005,1785743005,1,24,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','357ebef8c4299621cebf7641d896da5bd2395ac0','Image.CropScaleMask','2a4258edd3',115,115),
(74,1785743005,1785743005,1,30,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','a883cb4b3fbbba750a6dc51b0be7bc169f8ea92d','Image.CropScaleMask','261cea90f9',115,115),
(75,1785743006,1785743006,1,8,'/_processed_/4/f/csm_spitex-favicon_b63c652888.png','csm_spitex-favicon_b63c652888.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','06ff5592072e31318f265c9d4214b57a6f8ce456','Image.CropScaleMask','b63c652888',115,115),
(76,1785746488,1785746488,0,33,'/typo3temp/assets/_processed_/6/6/csm_dummy-preview-image_a1d8a4dff2.png','csm_dummy-preview-image_a1d8a4dff2.png',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:100;s:9:\"maxHeight\";i:100;s:4:\"crop\";N;}','1de85feb3e25752eaaeafd731583414ea1d5b62a','b069aa085f06da6743b904400b0e412c3b0b5b07','Image.CropScaleMask','a1d8a4dff2',100,100);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(3,0,1785492219,1785492219,0,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,1,'pages','media',1,'',NULL,NULL,0,0),
(4,1,1785498866,1785497882,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,3,NULL,NULL,1,'lueg_podcasts_episodes','mediafile',1,'',NULL,NULL,0,0),
(5,1,1785498532,1785497882,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,1,'lueg_podcasts_episodes','poster',1,'',NULL,NULL,0,0),
(6,1,1785498866,1785497882,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,4,NULL,NULL,2,'lueg_podcasts_episodes','mediafile',1,'',NULL,NULL,0,0),
(7,1,1785498693,1785497882,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,2,'lueg_podcasts_episodes','poster',1,'',NULL,NULL,0,0),
(8,1,1785498866,1785498532,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,6,NULL,'Podcats Nr 1',1,'lueg_podcasts_episodes','poster',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(9,1,1785498866,1785498693,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,NULL,2,'lueg_podcasts_episodes','poster',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(10,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,32,NULL,NULL,1,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(11,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,29,NULL,NULL,2,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(12,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,30,NULL,NULL,3,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(13,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,23,NULL,NULL,4,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(14,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,27,NULL,NULL,5,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(15,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,26,NULL,NULL,6,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(16,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,25,NULL,NULL,7,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(17,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,24,NULL,NULL,8,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(18,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,28,NULL,NULL,9,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(19,1,1785504207,1785504207,0,0,0,0,NULL,NULL,0,0,0,0,31,NULL,NULL,10,'lueg_benefits_tiles','icon',1,'',NULL,NULL,0,0),
(20,1,1785509276,1785507434,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin1_image',1,'',NULL,NULL,0,0),
(21,1,1785509276,1785507434,1,0,0,0,NULL,NULL,0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,NULL,0,0),
(22,1,1785509487,1785507434,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin3_image',1,'',NULL,NULL,0,0),
(23,1,1785509487,1785507434,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,NULL,NULL,5,'tt_content','lueg_standorte_pin4_image',1,'',NULL,NULL,0,0),
(24,1,1785746876,1785509276,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,19,NULL,'standort weier',5,'tt_content','lueg_standorte_pin1_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(25,1,1785509487,1785509276,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,'standort sumiswald',5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(26,1,1785746876,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,21,NULL,'Marktgasse 5 3454 ',5,'tt_content','lueg_standorte_pin2_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(27,1,1785746876,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,22,NULL,'Standort Affoltern',5,'tt_content','lueg_standorte_pin3_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0),
(28,1,1785746876,1785509487,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,'Standort Hasle',5,'tt_content','lueg_standorte_pin4_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0,0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1785490031,1785490031,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
INSERT INTO `sys_filemounts` VALUES
(1,0,1785485818,0,0,0,NULL,'User Upload','1:/user_upload/',0);
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1785490041,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1785490041,1,'BE',2,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"spitex lueg\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"1\",\"sys_language_uid\":0,\"crdate\":1785490041,\"t3ver_stage\":0,\"tstamp\":1785490041,\"uid\":1}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:4cf496f597e7b095ce8b755e6cec3c0c'),
(3,1785490041,2,'BE',2,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$AivkYoubtqQE7jGKcx64ax1HgjIb7RCs:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1785491657,1,'BE',2,0,2,'pages','{\"doktype\":\"3\",\"slug\":\"\\/podcasts\",\"link\":\"Podcasts\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Podcasts\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491657,\"t3ver_stage\":0,\"tstamp\":1785491657,\"uid\":2}',0,'0400$omWpoRvZkeQ57UXdvAnM8zOxu7lb366N:f11830df10b4b0bca2db34810c2241b3'),
(5,1785491662,2,'BE',2,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4m3XTRyS-hi7BI7OSIyTYJgM_fBar73U:f11830df10b4b0bca2db34810c2241b3'),
(6,1785491690,1,'BE',2,0,3,'pages','{\"doktype\":\"3\",\"slug\":\"\\/freie\",\"link\":\"freie-stellen\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":512,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Freie Stellen\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491690,\"t3ver_stage\":0,\"tstamp\":1785491690,\"uid\":3}',0,'0400$cIHHYZBoo0Sbtg5q5wEYesEP5A4j-rB7:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(7,1785491694,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$u_pRDRoOI5jt0Yz1DNjZKDAwq_XaKgMC:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(8,1785491709,1,'BE',2,0,4,'pages','{\"doktype\":\"3\",\"slug\":\"\\/benefits\",\"link\":\"Benefits\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":768,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Benefits\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491709,\"t3ver_stage\":0,\"tstamp\":1785491709,\"uid\":4}',0,'0400$OUe05A_qUllmq2hYXIbKvGRJ09s-SsxY:412add0b3eb6ec8f1cb6710aea92e21e'),
(9,1785491735,1,'BE',2,0,5,'pages','{\"doktype\":\"3\",\"slug\":\"\\/direkt-bewerben\",\"link\":\"Direkt-bewerben\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1024,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Direkt bewerben\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491735,\"t3ver_stage\":0,\"tstamp\":1785491735,\"uid\":5}',0,'0400$bRDqUABHrCHsPge9R9pOOsd8s2cB6jby:7ef5a4e3e11db8ac3fea4d7a75468161'),
(10,1785491741,2,'BE',2,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$o5n_iRIvF235Nli5Ofw3OxONrqYKAurQ:7ef5a4e3e11db8ac3fea4d7a75468161'),
(11,1785491743,2,'BE',2,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Zabi7RvB3Q7FOOTFB4P5MR3ipON8KjJH:412add0b3eb6ec8f1cb6710aea92e21e'),
(12,1785491929,1,'BE',2,0,6,'pages','{\"doktype\":\"3\",\"slug\":\"\\/standorte-spitex-region-lueg\",\"link\":\"Standorte\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1280,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Standorte Spitex Region Lueg\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491929,\"t3ver_stage\":0,\"tstamp\":1785491929,\"uid\":6}',0,'0400$N85uCLaz2cCqgIbuWwOj6Erylk7QyEIK:c75354c439a48dbde16b03ac553a080d'),
(13,1785491933,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$femDvlEtlqnvAlb7ysZnJ4KkZKxfYs4-:c75354c439a48dbde16b03ac553a080d'),
(14,1785491942,1,'BE',2,0,7,'pages','{\"doktype\":\"254\",\"slug\":\"\\/storage\",\"module\":\"\",\"hidden\":\"1\",\"categories\":\"0\",\"pid\":1,\"sorting\":1536,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Storage\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785491942,\"t3ver_stage\":0,\"tstamp\":1785491942,\"uid\":7}',0,'0400$4lgVRcYJkgbeGPL8SHF7kY_GIpDYKO3P:df50bb24cbce671cf0d61f42fbbef601'),
(15,1785491945,2,'BE',2,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$TkZA_AURYEk5YRSVCsZ8sjmHOIsW74Ii:df50bb24cbce671cf0d61f42fbbef601'),
(16,1785498371,2,'BE',2,0,2,'tt_content','{\"oldRecord\":{\"lueg_podcasts_episodes\":0,\"l18n_diffsource\":null},\"newRecord\":{\"lueg_podcasts_episodes\":2,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_podcasts_episodes\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:01dbc21fdb1263685b9147b3b1596ea8'),
(17,1785498371,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:0132d725a3cbba8232db69b70fa8cea4'),
(18,1785498371,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$UlSk1kx3Uv2Jni6K_66F_ASplEZO3e2w:147949966161cea7a4448f46cffcc51f'),
(19,1785498532,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:0132d725a3cbba8232db69b70fa8cea4'),
(20,1785498532,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autoplay\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:cea5fcd7b97871880cfe3717d6b52ef4'),
(21,1785498532,1,'BE',2,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Podcats Nr 1\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1785498532,\"t3ver_stage\":0,\"tstamp\":1785498532,\"uid\":8}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(22,1785498532,2,'BE',2,0,1,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:0132d725a3cbba8232db69b70fa8cea4'),
(23,1785498532,4,'BE',2,0,5,'sys_file_reference',NULL,0,'0400$0PUGXo_lo1uO_dQfoTHX9y6t7znnR6Lx:5f15a1453f67b933ed3314381f5d67e4'),
(24,1785498693,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:147949966161cea7a4448f46cffcc51f'),
(25,1785498693,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autoplay\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:cea5fcd7b97871880cfe3717d6b52ef4'),
(26,1785498693,2,'BE',2,0,8,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(27,1785498693,2,'BE',2,0,6,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:768f9cd4e98812f969df7ebe17f11b50'),
(28,1785498693,1,'BE',2,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1785498693,\"t3ver_stage\":0,\"tstamp\":1785498693,\"uid\":9}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:729356755eb8ee035abf6b9b02e20c8f'),
(29,1785498693,2,'BE',2,0,2,'lueg_podcasts_episodes','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"claim\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mediafile\\\":\\\"\\\",\\\"poster\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:147949966161cea7a4448f46cffcc51f'),
(30,1785498693,4,'BE',2,0,7,'sys_file_reference',NULL,0,'0400$uHgkXH_Ijz8WRiphBrclEVLoTVGLZ2S3:117c97010b9af15cb554d115dba4e316'),
(31,1785498866,2,'BE',2,0,9,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$hNxqfbc6dgh5pKeA-3CvEaFkPC7wQPqp:729356755eb8ee035abf6b9b02e20c8f'),
(32,1785502132,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"bodytext\":\"<p><strong>Wir suchen ausgebildete Fachkr\\u00e4fte, Quereinsteiger:innen und Lernende.<\\/strong><\\/p><p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll \\u2013 genau das macht sie so wertvoll.<\\/p><p>Wir unterst\\u00fctzen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und er\\u00f6ffnen ihnen die M\\u00f6glichkeit, Verantwortung zu \\u00fcbernehmen, beispielsweise in Spezialfunktionen.<\\/p>\",\"l18n_diffsource\":null},\"newRecord\":{\"bodytext\":\"<p><strong>Wir suchen ausgebildete Fachkr\\u00e4fte, Quereinsteiger:innen und Lernende.<\\/strong><\\/p>\\r\\n<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll \\u2013 genau das macht sie so wertvoll.<\\/p>\\r\\n<p>Wir unterst\\u00fctzen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und er\\u00f6ffnen ihnen die M\\u00f6glichkeit, Verantwortung zu \\u00fcbernehmen, beispielsweise in Spezialfunktionen.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$DAHkPTojXteTDPDMmAW1XrbMV8z4PGuN:7fa2c035f26826fe83eeecaaeddc4d40'),
(33,1785503682,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"lueg_benefits_tiles\":0,\"l18n_diffsource\":null},\"newRecord\":{\"lueg_benefits_tiles\":10,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_benefits_tiles\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:4d391f5ef79b8d5d10dffa8a07ca167d'),
(34,1785503682,2,'BE',2,0,1,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:1380d93aca08b14d7410b8aac97055d9'),
(35,1785503682,2,'BE',2,0,2,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:f16c1939204e3f8a6b67a49b7521c33f'),
(36,1785503682,2,'BE',2,0,3,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:0c785c1cb42d424e2608d25e0a182d66'),
(37,1785503682,2,'BE',2,0,4,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:22482fded5cb2c1071b802cad4406b07'),
(38,1785503682,2,'BE',2,0,5,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:1f457869a01262deca1e13521dcdaf7c'),
(39,1785503682,2,'BE',2,0,6,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:89a116999daef93a1e986c713f9accde'),
(40,1785503682,2,'BE',2,0,7,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:fe3fe818b96053da0676e791e6593721'),
(41,1785503682,2,'BE',2,0,8,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:ce032405553aefd28279d08ba416ec8a'),
(42,1785503682,2,'BE',2,0,9,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:69eb67fcaa1c5c687d66be5ebf4a03c2'),
(43,1785503682,2,'BE',2,0,10,'lueg_benefits_tiles','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$35d5JYybUlrH5Ts5LbU0Wvg1tizJ7-P3:d8122aa04961ffca814bacd78fc21345'),
(44,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(45,1785509276,1,'BE',2,0,24,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"standort weier\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1785509276,\"t3ver_stage\":0,\"tstamp\":1785509276,\"uid\":24}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:ec378d8e96f494986de35c9be84dff5c'),
(46,1785509276,1,'BE',2,0,25,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"standort sumiswald\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1785509276,\"t3ver_stage\":0,\"tstamp\":1785509276,\"uid\":25}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:5ce305fb03b44e2e5ced3360656e263a'),
(47,1785509276,2,'BE',2,0,22,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:d6a5725e5b31cdd97b9c53c992e81850'),
(48,1785509276,2,'BE',2,0,23,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:a4b81cbb471961a3c12b21861b94f4e1'),
(49,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(50,1785509276,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\n3415 Hasle b.B.\",\"l18n_diffsource\":null},\"newRecord\":{\"lueg_standorte_pin1_address\":\"Huttwilwestrasse 1\\r\\n3462 Weier i.E\",\"lueg_standorte_pin2_address\":\"Marktgasse 5\\r\\n3454 Sumiswald\",\"lueg_standorte_pin3_address\":\"Dorfstrasse 12\\r\\n3416 Affoltern i.E.\",\"lueg_standorte_pin4_address\":\"Bahnhofstrasse 3\\r\\n3415 Hasle b.B.\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_standorte_pin1_address\\\":\\\"\\\",\\\"lueg_standorte_pin1_image\\\":\\\"\\\",\\\"lueg_standorte_pin1_link\\\":\\\"\\\",\\\"lueg_standorte_pin1_title\\\":\\\"\\\",\\\"lueg_standorte_pin2_address\\\":\\\"\\\",\\\"lueg_standorte_pin2_image\\\":\\\"\\\",\\\"lueg_standorte_pin2_link\\\":\\\"\\\",\\\"lueg_standorte_pin2_title\\\":\\\"\\\",\\\"lueg_standorte_pin3_address\\\":\\\"\\\",\\\"lueg_standorte_pin3_image\\\":\\\"\\\",\\\"lueg_standorte_pin3_link\\\":\\\"\\\",\\\"lueg_standorte_pin3_title\\\":\\\"\\\",\\\"lueg_standorte_pin4_address\\\":\\\"\\\",\\\"lueg_standorte_pin4_image\\\":\\\"\\\",\\\"lueg_standorte_pin4_link\\\":\\\"\\\",\\\"lueg_standorte_pin4_title\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:c7626fc9bcba6f70beb6ebc085a400db'),
(51,1785509276,4,'BE',2,0,20,'sys_file_reference',NULL,0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:97d0d1c7a42cd9603b2010379c1e4e4d'),
(52,1785509276,4,'BE',2,0,21,'sys_file_reference',NULL,0,'0400$MsfzWEQF-6JZ9W4gPfi3md4lkF4oIHZU:bd8e6a36b477d61e04d92cfd10d00f96'),
(53,1785509279,2,'BE',2,0,24,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$tf1hLUF1l6g184HEEW-NPOU015vLTpXq:ec378d8e96f494986de35c9be84dff5c'),
(54,1785509279,2,'BE',2,0,25,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$tf1hLUF1l6g184HEEW-NPOU015vLTpXq:5ce305fb03b44e2e5ced3360656e263a'),
(55,1785509487,1,'BE',2,0,26,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Marktgasse 5 3454 \",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":26}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:2190384e72cbe31d01b0259338cca742'),
(56,1785509487,1,'BE',2,0,27,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Standort Affoltern\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":27}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:dd318efa0f8b108e87c8725b284b77c4'),
(57,1785509487,1,'BE',2,0,28,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Standort Hasle\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1785509487,\"t3ver_stage\":0,\"tstamp\":1785509487,\"uid\":28}',0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(58,1785509487,4,'BE',2,0,25,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:5ce305fb03b44e2e5ced3360656e263a'),
(59,1785509487,4,'BE',2,0,22,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:d6a5725e5b31cdd97b9c53c992e81850'),
(60,1785509487,4,'BE',2,0,23,'sys_file_reference',NULL,0,'0400$RoFT1KOJFH69h1lYQNr2DEXmO_WNJU3q:a4b81cbb471961a3c12b21861b94f4e1'),
(61,1785509547,2,'BE',2,0,26,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:2190384e72cbe31d01b0259338cca742'),
(62,1785509547,2,'BE',2,0,27,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:dd318efa0f8b108e87c8725b284b77c4'),
(63,1785509547,2,'BE',2,0,28,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$B_TK5HSeT2Tw4daWfd0d4A9LsQyaJiNy:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(64,1785745609,1,'BE',2,0,8,'pages','{\"doktype\":\"254\",\"slug\":\"\\/jobs\",\"module\":\"\",\"hidden\":\"1\",\"categories\":\"0\",\"pid\":1,\"sorting\":1792,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Jobs\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1785745609,\"t3ver_stage\":0,\"tstamp\":1785745609,\"uid\":8}',0,'0400$VMj9lL-3_N02g0JlyA8fhmEou_f4qHzv:595375f2fb9f014e091eb08fbc51ec88'),
(65,1785745614,2,'BE',2,0,8,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$goyiRAGSdjUFe3kVjcPdE5B5b_on0z4E:595375f2fb9f014e091eb08fbc51ec88'),
(66,1785746374,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Stelle\",\"lueg_stellen_stellen\":0,\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Jobs\",\"lueg_stellen_stellen\":5,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_stellen_stellen\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:c0db6803ab1ec5f70c36e2a72187867b'),
(67,1785746374,2,'BE',2,0,1,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:b330bba1cd3902f0e799c8f23a1700fa'),
(68,1785746374,2,'BE',2,0,2,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:c7846154fda727c6c75c4b7dbafc59ac'),
(69,1785746374,2,'BE',2,0,3,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:66ed292c32bfd38ce1ebd8ee0d9c9984'),
(70,1785746374,2,'BE',2,0,4,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:f7b484da3c22b6a5ed577823c3bc4d1b'),
(71,1785746374,2,'BE',2,0,5,'lueg_stellen_stellen','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$myuFhPyhPt3jM2fWKVl-f98DW-D2ZKU9:6007030b80c45b2c4ddd3d4b63624cfd'),
(72,1785746396,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Jobs\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>\\u00fcsi freie Jobs\"}}',0,'0400$Y7thAEEN4CM7FTqZ1Yxq3GkHT7AOZG0I:c0db6803ab1ec5f70c36e2a72187867b'),
(73,1785746643,2,'BE',2,0,7,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 \\u00fcsi freie Stelle\",\"pi_flexform\":null,\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>\\u00fcsi freie Stelle\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$i8642ZKN0JbZ_Pz0TAFEFRyaT1kfEjk3:ea41b626baac59a1fe0716bc344af5d9'),
(74,1785746680,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 wo mir si\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>wo mir si\"}}',0,'0400$sn8_vylnc9ZhTV7NZ6NqyD-KdrUa4e98:c7626fc9bcba6f70beb6ebc085a400db'),
(75,1785746902,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 was mir dir biete\"},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>was mir dir biete\"}}',0,'0400$n8Va8ImOL2DvQBqIjh7Vxx4Of3CBn9YB:4d391f5ef79b8d5d10dffa8a07ca167d'),
(76,1785746910,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 mir bilde lernendi us\",\"lueg_ausbildung_items\":0,\"l18n_diffsource\":null},\"newRecord\":{\"header\":\"Lueg \\u2013 <br>mir bilde lernendi us\",\"lueg_ausbildung_items\":3,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"lueg_ausbildung_items\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:b92300cfb5d1d3645c9cb212a7f56c1f'),
(77,1785746910,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:686d480187e1617721c3b1bb09978817'),
(78,1785746910,2,'BE',2,0,2,'lueg_ausbildung_items','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:729ffd98535f26f433ff7532650dd9e6'),
(79,1785746910,2,'BE',2,0,3,'lueg_ausbildung_items','{\"oldRecord\":{\"l10n_diffsource\":null},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$Cwm0pN2awz68i1qJomHfSyW2cI8FyNlW:c24a30159f7e49e143b807c1b78676e8'),
(80,1785747276,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 <br>mir bilde lernendi us\"},\"newRecord\":{\"header\":\"Lueg \\u2013 mir bilde<br> lernendi us\"}}',0,'0400$tZFjQMLVZ0ipkwvely-_niCKo5V7BMaJ:b92300cfb5d1d3645c9cb212a7f56c1f'),
(81,1785747294,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Lueg \\u2013 mir bilde<br> lernendi us\"},\"newRecord\":{\"header\":\"Lueg \\u2013 mir biude <br> Lernendi us\"}}',0,'0400$dCxJm3qolwUWKfjwV-sS01vU9pkGwAfa:b92300cfb5d1d3645c9cb212a7f56c1f'),
(82,1785747720,1,'BE',2,0,9,'pages','{\"doktype\":\"1\",\"slug\":\"\\/datenschutz\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":1408,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Datenschutz\",\"nav_hide\":\"0\",\"sys_language_uid\":0,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\",\"crdate\":1785747720,\"t3ver_stage\":0,\"tstamp\":1785747720,\"uid\":9}',0,'0400$cAZayLR5Mjfe_OKvEVl94PK7049dOzaF:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(83,1785747723,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$bu5LP0Q5TBDAIgk5ok_gqTHLz_N663q6:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(84,1785747726,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$cbwymNzqMbUl4K7lL3zXlXIsf6hoyHF2:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(85,1785748012,1,'BE',2,0,9,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":9,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<h2>1. Verantwortlicher im Sinne des schweizerischen Bundesgesetzes \\u00fcber den Datenschutz (DSG) f\\u00fcr die hier beschriebenen Datenbearbeitungen ist:<\\/h2>\\r\\n<p>SPITEX Region Lueg AG R\\u00fcegsaustrasse 8 3415 Hasle-R\\u00fcegsau<\\/p>\\r\\n<p>Unser Datenschutzberater ist: impunix AG \\u2013 Datenschutz Full-Service Lagerhausstrasse 18, CH-8400 Winterthur privacy@impunix.ch www.impunix.ch<\\/p>\\r\\n<p>Bei Fragen oder Anliegen zum Datenschutz und zur Aus\\u00fcbung Ihrer Rechte wenden Sie sich bitte an diese Stelle.<\\/p>\\r\\n<h2>2. Zweck der Bearbeitung im Rahmen unserer Dienstleistungen und Angebote<\\/h2>\\r\\n<p>Wir beschaffen und bearbeiten die Personendaten, die wir im Rahmen unserer Gesch\\u00e4ftst\\u00e4tigkeit insbesondere mit Klienten, Angeh\\u00f6rige, Besuchern, Interessenten, Bewerbern, Gesch\\u00e4fts-partnern sowie weiteren beteiligten Personen erhalten oder die beim Betrieb unserer Website erhoben werden. Im letzten Kapitel ist eine \\u00dcbersicht \\u00fcber die verwendeten Kategorien von Per-sonendaten. Sollten Sie uns Informationen \\u00fcber andere Personen \\u00fcbermitteln, vergewissern Sie sich bitte, dass diese Personen vorher informiert wurden und dass die angegebenen Daten korrekt sind. Die erhobenen Personendaten werden zur Erbringung unserer Dienstleistungen und Angebote verwendet. Dies umfasst insbesondere die Betreuung und Behandlung von Menschen aller Al-tersgruppen (ab 16. Jahren) mit vor\\u00fcbergehend reduzierten physischen und psychischen Kr\\u00e4f-ten, Menschen mit einer chronischen Erkrankung oder Einschr\\u00e4nkung, Betagte und gebrechliche Menschen, zu Hause in der gewohnten Umgebung. Zudem k\\u00f6nnen externe Dienstleister zur Erbringung dieser Leistungen eingesetzt werden. Weitere Informationen zu den Datenbearbei-tungen und deren Zwecken finden Sie in den folgenden Kapiteln.<\\/p>\\r\\n<h3>2.1 Kontaktaufnahme und Kommunikation<\\/h3>\\r\\n<p>Wir bearbeiten Ihre Daten zur Bearbeitung von Anfragen \\u00fcber das Kontaktformular, zur Bereit-stellung von Informationen \\u00fcber unsere Dienstleistungen sowie zur Vereinbarung von Terminen und Beratungen.<\\/p>\\r\\n<h3>2.2 Klientenaufnahme (inkl. Anamnese)<\\/h3>\\r\\n<p>Bei der Klientenaufnahme erheben und speichern wir Ihre Stammdaten sowie Ihre medizinische Vorgeschichte. Dies umfasst Informationen wie Name, Adresse, Geburtsdatum, Kontaktinfor-mationen und relevante Gesundheitsdaten. Diese Daten sind notwendig, um eine individuelle Behandlung planen zu k\\u00f6nnen.<\\/p>\\r\\n<h3>2.3 Klientenversorgung und medizinische Dienstleistungen<\\/h3>\\r\\n<p>Wir bearbeiten Ihre Gesundheitsdaten, um diagnostische Untersuchungen und therapeutische Behandlungen durchzuf\\u00fchren. Dies beinhaltet die Nutzung medizinischer Technologien und Me-thoden. Ihre Daten werden f\\u00fcr folgende Punkte genutzt:<\\/p>\\r\\n<ul><li data-list-item-id=\\\"ec3ce18193255f5fde3ba54460d453b52\\\">Abkl\\u00e4rung des Pflegebedarfs<\\/li><li data-list-item-id=\\\"e0ad57aa9c0e13d9f23246c5e1995cf5c\\\">Beratung zu Angeboten<\\/li><li data-list-item-id=\\\"e4bb93e37680c861b448047346e592126\\\">Hilfe bei der K\\u00f6rperpflege<\\/li><li data-list-item-id=\\\"e12976d41ff5c4a54cfb440edf1045884\\\">Hilfe bei der Mobilisation (Aufstehen und zu Bett gehen)<\\/li><li data-list-item-id=\\\"ef6b9fcaca1b8d5423af23702e1f94266\\\">Vorbereiten und Verabreichen von Medikamenten<\\/li><li data-list-item-id=\\\"ed915f50a459dde5f50980cfa70cefe15\\\">Medizinische Kontrollen wie Blutzucker und Blutdruck messen etc.<\\/li><li data-list-item-id=\\\"ecd19447a354f66f10f59e7371aba99dd\\\">Schmerzbehandlung<\\/li><li data-list-item-id=\\\"ed2cb2f0f3921196d168d2a2162124621\\\">Pflege von Wunden<\\/li><li data-list-item-id=\\\"e4f783386e772e11b268f4e4ab9a115b1\\\">Begleitung von Sterbenden (palliative Care)<\\/li><li data-list-item-id=\\\"e38b4572e7769e9d625e5dfed1d2b314e\\\">Psychiatrische Pflegeleistungen<\\/li><\\/ul>\\r\\n<h3>2.4 Beratungs- und Informationsveranstaltungen<\\/h3>\\r\\n<p>Wir nutzen Ihre Daten, vertraulich und anonym, f\\u00fcr interne Weiterbilungszwecke.2.5 Notfallver-sorgung Ihre Daten werden bearbeitet, um Notf\\u00e4lle w\\u00e4hrend der regul\\u00e4ren \\u00d6ffnungszeiten zu behandeln und um in solchen F\\u00e4llen weitere organisatorische Massnahmen zu treffen.<\\/p>\\r\\n<h3>2.5 F\\u00fchrung und Verwaltung der Klientendossiers<\\/h3>\\r\\n<p>Die Verwaltung Ihrer Klientendossiers umfasst die Erfassung und Speicherung von Anamnese, Diagnose, Befunden sowie der Dokumentation Ihrer Betreuung. Zudem beinhalten die Dossiers Korrespondenzen, Rechnungen, Terminplanungen und relevante Fotos, die zur l\\u00fcckenlosen Dokumentation der medizinischen Geschichte notwendig sind.<\\/p>\\r\\n<h3>2.6 Verwaltung der Daten zur Abrechnung<\\/h3>\\r\\n<p>Zur Abrechnung unserer Leistungen verwalten wir Ihre Stamm- und Betreuungsdaten. Dies um-fasst die Kommunikation mit Sozialversicherungen, Krankenkassen und Unfallversicherungen sowie zur Einholung und Verwaltung der Kostengutsprache, gelegentlich den Austausch mit Beh\\u00f6rden.<\\/p>\\r\\n<h3>2.7 Lieferantenmanagement<\\/h3>\\r\\n<p>Im Rahmen unserer Gesch\\u00e4ftsbeziehung mit unseren Partnern oder Lieferanten erhalten wir ihre beruflichen Kontaktdaten, die wir in unseren Systemen speichern k\\u00f6nnen. Dazu k\\u00f6nnen auch Ihre Interessen oder Pr\\u00e4ferenzen geh\\u00f6ren, um eine pers\\u00f6nliche Gesch\\u00e4ftsbeziehung zu pflegen.<\\/p>\\r\\n<h3>2.8 Websites und Online-Angebote<\\/h3>\\r\\n<p>Zur Erbringung unserer Dienstleistungen und zur Vermarktung unserer Angebote nutzen wir Websites und andere Online-Angebote. Wenn Sie auf unsere Website zugreifen, erheben wir Nutzungsdaten. Weitere Informationen zur Website finden Sie im entsprechenden Kapitel.<\\/p>\\r\\n<h3>2.9 Printmedien<\\/h3>\\r\\n<p>Wir versenden teilweise personalisierte Printmedien, wof\\u00fcr ihre Kontaktdaten oder berufliche Kontaktdaten bearbeitet werden. F\\u00fcr den Versand von Printmedien behalten wir uns vor, mit Dritten zusammenzuarbeiten und Ihre Kontaktdaten zu diesem Zweck weiterzugeben.<\\/p>\\r\\n<h3>2.10 Stellenbewerbung<\\/h3>\\r\\n<p>Um Ihre Eignung f\\u00fcr ein Arbeitsverh\\u00e4ltnis festzustellen, bearbeiten wir die Personendaten, die wir von Ihnen im Rahmen des Bewerbungsverfahrens erhalten haben. Dazu k\\u00f6nnen auch Straf-register- und Betreibungsausz\\u00fcge oder \\u00e4hnliche Dokumente geh\\u00f6ren. Wenn Sie Referenzen angegeben haben, k\\u00f6nnen wir bei diesen Referenzen Ausk\\u00fcnfte \\u00fcber Sie einholen. Sie haben das Recht zu erfahren, was uns mitgeteilt wurde. Tests, die der objektiven Feststellung der Eignung f\\u00fcr die betreffende Stelle dienen, k\\u00f6nnen Teil des Bewerbungsverfah-rens sein. Soweit es um die Feststellung der Eignung als F\\u00fchrungskraft geht, kann sich der Test auch auf Ihre Pers\\u00f6nlichkeit beziehen. Sollte sich aus den eingereichten Unterlagen noch kein vollst\\u00e4ndiges und verl\\u00e4ssliches Bild ergeben, erlauben wir uns, \\u00f6ffentlich zug\\u00e4ngliche Quellen, die zur Kl\\u00e4rung der konkreten berufli-chen Eignung geeignet sind, wie Xing oder LinkedIn, aber auch ganz allgemein Google, f\\u00fcr die Recherche zu nutzen. Die Recherche in privaten Netzwerken wie Facebook oder Instagram ist f\\u00fcr uns nicht relevant. Sofern objektive Gr\\u00fcnde in Ihrer Person vorliegen, die Sie f\\u00fcr das entsprechende Arbeitsver-h\\u00e4ltnis einschr\\u00e4nken oder disqualifizieren, sind Sie verpflichtet, uns diese offen zu legen. Dies kann auch eine Untersuchung Ihres Gesundheitszustandes beinhalten. Die Auskunft an uns er-folgt im gesetzlichen Rahmen<\\/p>\\r\\n<h2>3. Website, Social Media und Cookie-Hinweise<\\/h2>\\r\\n<p>Die Datenschutzerkl\\u00e4rung gilt f\\u00fcr alle betriebenen Websites, inklusive:<\\/p>\\r\\n<p>luegjobs.ch<\\/p>\\r\\n<p>\\u00dcber die Websites werden Nutzungsdaten erfasst und automatisch in sogenannten Server-Log-Dateien gespeichert, die Ihr Browser automatisch an uns \\u00fcbermittelt. Diese Daten k\\u00f6nnen von uns nicht bestimmten Personen zugeordnet werden. Eine Zusammenf\\u00fchrung dieser Daten mit anderen Datenquellen wird nicht vorgenommen. Wir behalten uns jedoch vor, diese Daten nach-tr\\u00e4glich zu pr\\u00fcfen, wenn wir konkrete Anhaltspunkte f\\u00fcr eine rechtswidrige Nutzung der Websites erhalten. Aus Sicherheitsgr\\u00fcnden und zum Schutz der \\u00fcbertragenen vertraulichen Inhalte, wie z.B. Anfra-gen, die Sie an uns als Website-Betreiber senden, wird auf den Websites eine SSL\\/TLS-Verschl\\u00fcsselung eingesetzt. Die Websites k\\u00f6nnen Links zu anderen Websites enthalten, die sich unserer Kontrolle entziehen und daher nicht von dieser Datenschutzerkl\\u00e4rung abgedeckt werden. Wenn Sie diese Links nutzen und auf andere Websites zugreifen, kann es sein, dass die Betreiber dieser Websites Informationen \\u00fcber Sie sammeln.<\\/p>\\r\\n<h3>3.1 Nutzung des Kontaktformulars<\\/h3>\\r\\n<p>Auf unserer Website steht ein Kontaktformular f\\u00fcr Fragen, Anliegen oder Informationen zur Verf\\u00fcgung. Ihre Personendaten werden bearbeitet, um Ihre Anfrage zu bearbeiten und Ihnen eine qualifizierte Antwort bereitzustellen. Dies umfasst die Erfassung und Speicherung Ihrer Kontaktdaten sowie der relevanten medizinischen Informationen, die Sie uns \\u00fcber das Kontaktfor-mular \\u00fcbermitteln.<\\/p>\\r\\n<h3>3.2 Social Media inklusive Plugins und Pixel<\\/h3>\\r\\n<p>Wir betreiben Pr\\u00e4senzen auf sozialen Netzwerken und anderen Plattformen, die von Dritten betrieben werden, und bearbeiten in diesem Zusammenhang Daten \\u00fcber Sie. Sie k\\u00f6nnen uns \\u00fcber diese Plattformen kontaktieren und wir erhalten von diesen Plattformen Daten wie z.B. Statistiken. Die Anbieter der Plattformen k\\u00f6nnen Ihre Nutzung analysieren und die Daten \\u00fcber Sie f\\u00fcr eigene Zwecke wie Marketing und Marktforschung verwenden. Die Anbieter der Plattformen handeln hierbei als eigenst\\u00e4ndige verantwortliche Stelle. Weiter k\\u00f6nnen wir auf unseren Webseiten auch sogenannte Plugins oder Pixel von sozialen Netzwerken wie Facebook, X ehemals Twitter, LinkedIn, Pinterest oder Instagram verwenden. Die Plugins sind f\\u00fcr Sie jeweils erkennbar. Sind sie aktiviert, k\\u00f6nnen die Betreiber der jeweiligen sozialen Netzwerke registrieren, dass Sie unsere Website besuchen. Bei der Verwendung von Pixel-Technologien werden auf unserer Website entsprechende Codes implementiert, die eine \\u00dcbermittlung Ihrer Nutzungsdaten erm\\u00f6glichen. Diese dienen der Reichweitenmessung unserer Social-Media-Kampagnen. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen. Die meisten dieser Anbieter befinden sich ausserhalb der Schweiz. Weitere Informationen zur Daten\\u00fcbermittlung ins Ausland entnehmen Sie dem entsprechenden Kapitel.<\\/p>\\r\\n<h3>3.3 WhatsApp oder andere Messenger-Apps<\\/h3>\\r\\n<p>Wir nutzen WhatsApp aktiv als Kommunikationsmittel und erm\\u00f6glichen Ihnen die Kontaktaufnahme \\u00fcber diesen Dienst. Bitte beachten Sie, dass bei der Nutzung von WhatsApp in der Re-gel das Adressbuch freigegeben wird und damit Personendaten an die WhatsApp Inc.&nbsp;in die USA \\u00fcbermittelt werden. Wir weisen darauf hin, dass die USA vom Bundesrat als Land ohne angemessenen Datenschutz eingestuft wurde. Weitere Informationen dar\\u00fcber, wie und zu wel-chem Zweck WhatsApp Ihre Daten bearbeitet, finden Sie in der Datenschutzerkl\\u00e4rung von WhatsApp.<\\/p>\\r\\n<h3>3.4 Permanente Cookies oder sonstige Tracking-Technologien<\\/h3>\\r\\n<p>Auf unserer Website verwenden wir in der Regel Cookies und \\u00e4hnliche Technologien, um Ihren Browser oder Ihr Ger\\u00e4t zu identifizieren. Ein Cookie ist eine kleine Datei, die beim Besuch unse-rer Website vom verwendeten Webbrowser automatisch an Ihren Computer gesendet oder auf Ihrem Computer oder Mobilger\\u00e4t gespeichert wird. Wenn Sie diese Website erneut besuchen, k\\u00f6nnen wir Sie wiedererkennen, auch wenn wir nicht wissen, wer Sie sind. Neben Cookies, die nur w\\u00e4hrend einer Sitzung verwendet und nach dem Besuch der Website gel\\u00f6scht werden (\\u201cSession Cookies\\u201d), k\\u00f6nnen Cookies auch verwendet werden, um Benutzereinstellungen und andere Informationen f\\u00fcr einen bestimmten Zeitraum zu speichern (\\u201cpermanente Cookies\\u201d). Sie k\\u00f6nnen Ihren Browser jedoch so einstellen, dass er Cookies ablehnt, nur f\\u00fcr eine Sitzung spei-chert oder andernfalls vorzeitig l\\u00f6scht. Die meisten Browser sind so eingestellt, dass sie Coo-kies akzeptieren. Wir verwenden permanente Cookies, um Benutzereinstellungen zu speichern (z.B. Sprache, Auto-Login), um besser zu verstehen, wie Sie unsere Angebote und Inhalte nut-zen, und um Ihnen auf Sie zugeschnittene Angebote und Werbung anzeigen zu k\\u00f6nnen (was auch auf Websites anderer Unternehmen der Fall sein kann). Einige Cookies werden von uns gesetzt, andere von Vertragspartnern, mit denen wir zusammenarbeiten. Wenn Sie Cookies blockieren, kann es sein, dass einige Funktionen (z.B. Sprachauswahl, Warenkorb, Bestellvor-gang) nicht mehr funktionieren. Wenn Sie dies nicht w\\u00fcnschen, m\\u00fcssen Sie Ihren Browser bzw. Ihr E-Mail-Programm entsprechend einstellen<\\/p>\\r\\n<h4>3.4.1 Google Fonts oder andere Web-Fonts<\\/h4>\\r\\n<p>Diese Website verwendet sogenannte Fonts von Google oder anderen Anbietern, um eine ein-heitliche Darstellung von Schriften zu gew\\u00e4hrleisten. Beim Aufruf der Seite l\\u00e4dt Ihr Browser die ben\\u00f6tigten Fonts in den Browser-Cache, um die Texte und Schriften korrekt darzustellen. Um Ihre Privatsph\\u00e4re zu sch\\u00fctzen, haben wir die Fonts soweit m\\u00f6glich auf unserem eigenen Webs-erver installiert, so dass Ihre IP-Adresse beim Laden der Fonts nicht an andere Diensteanbieter weitergegeben wird. Bitte beachten Sie jedoch, dass bei der Nutzung bestimmter Dienste, wie z.B. Maps, Captcha oder Bootstrap, m\\u00f6glicherweise Fonts von diesen Dienstleistern verwendet werden. Falls Ihr Browser keine externen Schriften unterst\\u00fctzt, wird automatisch eine Stan-dardschrift Ihres Computers verwendet. Weitere Informationen zu Google Fonts und deren Da-tenschutzbestimmungen finden Sie auf der Website von Google oder des jeweiligen Anbieters.<\\/p>\\r\\n<h4>3.4.2 Google Photos, Youtube oder andere Bild- und Streamingdienste<\\/h4>\\r\\n<p>Auf dieser Website sind Funktionen des Google-Dienstes Photos und YouTube oder anderer Streaming-Dienste integriert. Diese verwenden wir, um Photos oder Videos auf unserer Website einzubinden. Die Plugins sind f\\u00fcr Sie erkennbar. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen.<\\/p>\\r\\n<h4>3.4.3 Heyflow<\\/h4>\\r\\n<p>F\\u00fcr unsere Bewerbungs Experience setzen wir den Dienst Heyflow der Heyflow GmbH, Deutschland (EU), ein. Dabei werden die von Ihnen eingegebenen Angaben sowie Nutzungs und Ger\\u00e4tedaten (z. B. IP Adresse, Zeitstempel, Interaktionen, Browser\\/OS, Cookies\\/Local Storage) zur Entgegennahme, Pr\\u00fcfung und Abwicklung Ihrer Bewerbung bearbeitet. Heyflow bearbeitet diese Personendaten als unser Auftragsbearbeiter. Weitere Informationen zu Heyflow und deren Datenschutzbestimmungen finden Sie auf der Website von Heyflow.<\\/p>\\r\\n<h2>4. Herkunft von Personendaten<\\/h2>\\r\\n<p>Die Daten, die wir bearbeiten, stammen in den meisten F\\u00e4llen von Ihnen selbst, z.B. im Zusam-menhang mit der Erbringung unserer Dienstleistungen, der Nutzung unserer Website oder der Kommunikation mit uns. Wenn Sie mit uns Vertr\\u00e4ge abschliessen oder unsere Dienstleistungen in Anspruch nehmen wollen, m\\u00fcssen Sie uns bestimmte Daten bekannt geben. Dies gilt auch f\\u00fcr die Nutzung unserer Website. Dar\\u00fcber hinaus sind Sie zur Bekanntgabe von Daten verpflich-tet, um gesetzliche Verpflichtungen zu erf\\u00fcllen. Ansonsten steht es Ihnen frei, ob Sie uns Daten \\u00fcber sich mitteilen. Wir k\\u00f6nnen Daten auch von Dritten erhalten, insbesondere von unseren externen Dienstleistern oder Vertragspartnern, von Finanzdienstleistern und Versicherungen. Dar\\u00fcber hinaus k\\u00f6nnen wir Daten aus \\u00f6ffentlich zug\\u00e4nglichen Quellen wie Internetseiten, Unternehmensregistern, Grundb\\u00fc-chern, Handelsregistern, Auskunfteien, Adressh\\u00e4ndlern, Verb\\u00e4nden, Telefonb\\u00fcchern, Inter-netanalysediensten erhalten.<\\/p>\\r\\n<h2>5. Datenweitergabe und Daten\\u00fcbermittlung ins Ausland<\\/h2>\\r\\n<p>Im Rahmen unserer gesch\\u00e4ftlichen Aktivit\\u00e4ten und gem\\u00e4ss den genannten Zwecken besteht die M\\u00f6glichkeit, dass wir Informationen mit Dritten teilen, insbesondere mit folgenden Kategorien von Empf\\u00e4ngern:<\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb655ceac612723df820daa2c0d7f6f7f\\\">Fachspezialisten: Wir arbeiten mit \\u00c4rztinnen und \\u00c4rzten zusammen, mit denen teilweise auch Daten ausgetauscht werden;<\\/li><li data-list-item-id=\\\"e8335efa95f4c68819e9cd99c861262f9\\\">Dienstleister: Wir arbeiten mit Dienstleistern zusammen, die Daten in unserem Auftrag oder in gemeinsamer Verantwortlichkeit bearbeiten, wie zum Beispiel Hausarztpraxen, Apotheken, Anbieter von Praxissoftware, Marketing-Agenturen oder IT-Dienstleister, sonstige Lieferanten, Gesch\\u00e4ftspartner;<\\/li><li data-list-item-id=\\\"e93cbdcaf077a67fcf0d38211148f2d63\\\">Beh\\u00f6rden: Wir k\\u00f6nnen Daten auch an Beh\\u00f6rden im In- (und Ausland), Amtsstellen oder Gerichte bekanntgeben, wenn wir dazu rechtlich verpflichtet sind;<\\/li><li data-list-item-id=\\\"e3b0f3783dd6cc9a0b387c0ea42cdd65c\\\">Finanzdienstleister und Versicherungen: Im Zusammenhang mit Bonit\\u00e4ts- und Versi-cherungsleistungen arbeiten wir mit Auskunfteien, Banken, Versicherungen zusammen;<\\/li><li data-list-item-id=\\\"ec17b00d9c96652226b206d8e30b071cb\\\">Andere Dritte: Alle anderen Dritten, mit denen wir zur Erf\\u00fcllung der genannten Zwecke zusammenarbeiten. Dies k\\u00f6nnen beispielsweise Medien, die \\u00d6ffentlichkeit, einschliess-lich Besuchern von Websites, Mitbewerbern, Branchenorganisationen, Verb\\u00e4nde, Organisationen und weitere Gremien sein. Zus\\u00e4tzlich k\\u00f6nnen es auch Parteien im Zusam-menhang mit einer Unternehmenstransaktion wie z. B. einer Fusion, einem Verkauf von Verm\\u00f6genswerten oder Anteilen, einer Restrukturierung, einer Finanzierung, einem Kon-trollwechsel oder der \\u00dcbernahme des gesamten oder eines Teils unseres Unternehmens sein.<\\/li><\\/ul>\\r\\n<p>Diese Kategorien von Empf\\u00e4ngern k\\u00f6nnen Dritte einbeziehen, denen Personendaten zug\\u00e4nglich gemacht werden. Dienstleister und bestimmte Vertragspartner, die in unserem Auftrag t\\u00e4tig sind, k\\u00f6nnen wir vertraglich verpflichten, die Daten nicht f\\u00fcr eigene Zwecke zu verwenden. An-dere Dritte wie Finanzdienstleister, Versicherungen oder Beh\\u00f6rden verwenden die Daten f\\u00fcr eigene Zwecke, z.B. zur Erf\\u00fcllung gesetzlicher Vorgaben, weshalb wir diese Bearbeitungen nicht einschr\\u00e4nken k\\u00f6nnen. Wir bearbeiten Ihre Personendaten vorwiegend in der Schweiz. Die Personendaten k\\u00f6nnen aber auch an Empf\\u00e4nger im Ausland bekannt gegeben werden z.B. in die USA. Dar\\u00fcber hinaus k\\u00f6n-nen die Daten in weitere Staaten des Europ\\u00e4ischen Wirtschaftsraumes \\u00fcbermittelt werden. Durch die heutige globale Vernetzung und aufgrund von international t\\u00e4tigen Konzernen ist es zudem m\\u00f6glich, dass Daten \\u00fcberall auf der Welt bearbeitet werden k\\u00f6nnen. Befindet sich ein Empf\\u00e4nger in einem Land ohne angemessenes gesetzliches Datenschutzniveau, werden wir unseren Lieferanten oder Partner, den Empf\\u00e4nger vertraglich zur Einhaltung des anwendbaren Datenschutzniveaus verpflichten, soweit er nicht bereits einem gesetzlich anerkannten Regel-werk zur Sicherstellung des Datenschutzes unterliegt und wir uns nicht auf eine Ausnahmebe-stimmung berufen k\\u00f6nnen.<\\/p>\\r\\n<h2>6. Dauer der Aufbewahrung von Personendaten<\\/h2>\\r\\n<p>Wir bearbeiten und speichern Ihre Personendaten so lange, wie es f\\u00fcr die Erf\\u00fcllung unserer vertraglichen und gesetzlichen Pflichten oder sonst die mit der Bearbeitung verfolgten Zwecke erforderlich ist, d.h. also zum Beispiel f\\u00fcr die Dauer der gesamten Klientenbeziehung sowie dar\\u00fcber hinaus gem\\u00e4ss den gesetzlichen Aufbewahrungs- und Dokumentationspflichten. Dabei ist es m\\u00f6glich, dass Personendaten f\\u00fcr die Zeit aufbewahrt werden, in der Anspr\\u00fcche gegen unser Unternehmen geltend gemacht werden k\\u00f6nnen und soweit wir anderweitig gesetzlich dazu verpflichtet sind oder berechtigte Gesch\\u00e4ftsinteressen dies erfordern (z.B. f\\u00fcr Beweis- und Do-kumentationszwecke).<\\/p>\\r\\n<h2>7. Datensicherheit<\\/h2>\\r\\n<p>Wir treffen angemessene technische und organisatorische Sicherheitsvorkehrungen zum Schutz Ihrer Personendaten. Wir ber\\u00fccksichtigen dabei den Stand der Technik, das Risiko der Bearbei-tung, die Investitionskosten und orientieren uns neben dem Schweizer Datenschutzgesetz an der Datenschutzverordnung. Die Massnahmen sollen dazu dienen Datenschutzverletzungen, wie beispielsweise dem unberechtigten Zugriff und Missbrauch der Daten, zu verhindern. Die Auf-tragsbearbeiter, an die wir Daten weitergeben weisen wir ebenfalls an angemessene technische und organisatorische Sicherheitsvorkehrungen zu treffen. Kontaktaufnahme per E-Mail Die Kommunikation mittels E-Mail ist in der Regel nicht verschl\\u00fcsselt. Werden jedoch beson-ders sch\\u00fctzenswerte Daten ausgetauscht versenden wir diese verschl\\u00fcsselt mittels HIN. Es besteht die M\\u00f6glichkeit, dass Daten verloren gehen oder von Dritten abgefangen und\\/oder manipuliert werden k\\u00f6nnen, um zum Beispiel damit die Echtheit vorzut\\u00e4uschen. Wir treffen ge-eignete technische und organisatorische Sicherheitsmassnahmen, um dies innerhalb des Sys-tems zu verhindern. Dennoch kann die Vertraulichkeit von Daten bei der \\u00dcbertragung jeglicher Daten per E-Mail nicht gew\\u00e4hrleistet werden. Dieser Hinweis gilt insbesondere in Bezug auf die \\u00dcbertragung von besonders sch\\u00fctzenswerten Personendaten, \\u00fcbermitteln Sie uns diese nicht per E-Mail, sondern kontaktieren Sie uns vorg\\u00e4ngig, um einen sicheren Kanal zu vereinbaren. Externe Zugriffsger\\u00e4te (PC, Smartphone etc. von Endnutzern) und Teile der zwischen dem Ab-sender und Empf\\u00e4nger an der \\u00dcbermittlung beteiligten Infrastruktur befinden sich ausserhalb des von uns kontrollierbaren Bereichs. Wir haften nicht f\\u00fcr Konsequenzen und Sch\\u00e4den, die sich aus dem elektronischen Informationsaustausch und insbesondere aus einer missbr\\u00e4uchli-chen Verwendung des E-Mail-Systems ergeben k\\u00f6nnen. Wir behalten uns vor uns, f\\u00fcr jeglichen vors\\u00e4tzlichen Schaden, der uns aus dem Gesch\\u00e4ftsverkehr mit der betroffenen Person \\u00fcber den elektronischen Informationsaustausch entsteht, schadlos zu halten. Weiter behalten wir uns vor, im Einzelfall nicht per E-Mail zu antworten oder f\\u00fcr die per E-Mail erhaltene Auftragsertei-lung oder Information zus\\u00e4tzlich eine andere Form zu verlangen wie z.B. \\u00fcber ein Formular mit Unterschrift.<\\/p>\\r\\n<h2>8. Pr\\u00e4ferenzen und automatisierte Einzelentscheidungen<\\/h2>\\r\\n<p>Zur Begr\\u00fcndung und Durchf\\u00fchrung der Gesch\\u00e4ftsbeziehung und auch sonst nutzen wir grund-s\\u00e4tzlich keine vollautomatisierte automatische Entscheidungsfindung. Sollten wir solche Verfah-ren in Einzelf\\u00e4llen einsetzen, werden wir Sie hier\\u00fcber gesondert informieren, sofern dies gesetz-lich vorgegeben ist und Sie \\u00fcber die damit zusammenh\\u00e4ngenden Rechte aufkl\\u00e4ren.<\\/p>\\r\\n<h2>9. Rechte der betroffenen Personen<\\/h2>\\r\\n<p>Als betroffene Person haben Sie im Zusammenhang mit der Datenbearbeitung die gesetzlich vorgesehenen Rechte. Sie haben insbesondere das Recht, Auskunft \\u00fcber Ihre gespeicherten Personendaten zu verlangen. Ebenso k\\u00f6nnen Sie eine Berichtigung, Erg\\u00e4nzung, Sperrung oder L\\u00f6schung Ihrer Personendaten verlangen. Des Weiteren steht es Ihnen frei, der Verwendung Ihrer Daten zu Marketingzwecken zu widersprechen. Ihre Einwilligung k\\u00f6nnen Sie jederzeit mit Wirkung f\\u00fcr die Zukunft widerrufen. Zus\\u00e4tzlich haben Sie das Recht, die \\u00dcbertragung Ihrer Da-ten an andere Verantwortliche zu verlangen. Wir weisen jedoch darauf hin, dass wir uns das Recht vorbehalten, gesetzliche Einschr\\u00e4nkung-gen geltend zu machen, etwa wenn wir zur Aufbewahrung oder Bearbeitung bestimmter Daten verpflichtet sind, ein berechtigtes Interesse daran haben oder die Daten zur Geltendmachung von Rechtsanspr\\u00fcchen ben\\u00f6tigen. An die Stelle der L\\u00f6schung tritt die Sperrung, sofern rechtli-che Hindernisse der L\\u00f6schung entgegenstehen. Bitte beachten Sie, dass die Aus\\u00fcbung dieser Rechte mit vertraglichen Vereinbarungen in Konflikt stehen und dies Konsequenzen wie z.B. eine vorzeitige Vertragsaufl\\u00f6sung oder Kostenfolgen nach sich ziehen kann. Wir werden Sie in einem solchen Fall vorab informieren, sofern dies nicht bereits vertraglich geregelt ist. Die Aus\\u00fcbung dieser Rechte setzt in der Regel voraus, dass Sie Ihre Identit\\u00e4t eindeutig nach-weisen (z. B. durch Vorlage einer Kopie Ihres Identit\\u00e4tsdokuments, wenn Ihre Identit\\u00e4t sonst nicht eindeutig ist oder nicht \\u00fcberpr\\u00fcft werden kann). Zur Geltendmachung Ihrer Rechte k\\u00f6nnen Sie sich an den in Kapitel 1 genannten Datenschutzberater wenden. Jede betroffene Person hat zudem das Recht, ihre Anspr\\u00fcche gerichtlich geltend zu machen oder sich bei der zust\\u00e4ndigen Datenschutzbeh\\u00f6rde zu beschweren. Zust\\u00e4ndige Datenschutzbe-h\\u00f6rde in der Schweiz ist der Eidgen\\u00f6ssische Datenschutz- und \\u00d6ffentlichkeitsbeauftragte (https:\\/\\/www.edoeb.admin.ch).<\\/p>\\r\\n<h2>10. \\u00c4nderungen dieser Datenschutzerkl\\u00e4rung<\\/h2>\\r\\n<p>Wir k\\u00f6nnen diese Datenschutzerkl\\u00e4rung jederzeit ohne vorherige Ank\\u00fcndigung \\u00e4ndern. Diese Datenschutzerkl\\u00e4rung ist nicht Teil eines Vertrages mit Ihnen. Es gilt grunds\\u00e4tzlich die jeweils aktuelle Fassung, die auf unserer Website ver\\u00f6ffentlicht ist.<\\/p>\\r\\n<h2>11. Urheberrecht und Lizenz<\\/h2>\\r\\n<p>Diese Datenschutzerkl\\u00e4rung wurde im Rahmen des Datenschutz Service von der impunix AG erstellt. Bei Fragen oder Anmerkungen d\\u00fcrfen Sie uns gerne \\u00fcber die Kontaktdaten in Kapitel 1 kontaktieren. Der Gebrauch dieser Datenschutzerkl\\u00e4rung ist ausschliesslich Kunden unseres Datenschutz Full-Service vorbehalten.<\\/p>\\r\\n<h2>12. Kategorien von Personendaten<\\/h2>\\r\\n<p>Je nach Gesch\\u00e4ftsvorfall bearbeiten wir eine oder mehrere der nachfolgenden Kategorien von Personendaten in der unten aufgelisteten Tabelle.<\\/p>\\r\\n<ul><li data-list-item-id=\\\"e00bc9d0bb0b155afa665fecf408793d4\\\">Stammdaten: Daten f\\u00fcr die Zuordnung, Behandlung und Abrechnung, wie Name, Ge-burtsdatum, Adresse, Versicherungsnummer, Klientennummer und Kontaktdaten, etc.;<\\/li><li data-list-item-id=\\\"e752925bcac1946f526f48263269de94a\\\">Bonit\\u00e4ts- und Bankdaten: Lohn, Wohnkosten, frei verf\\u00fcgbares Einkommen, Zahlungs-verhalten, Bilanzen, Daten von Auskunfteien, Score-Werte, Verm\\u00f6gensverh\\u00e4ltnisse, Kon-toverbindung, Kreditkartennummer, etc.;<\\/li><li data-list-item-id=\\\"e220a6a22f5b0fb4d2cad41e8e2604a99\\\">Gesundheitliche und medizinische Daten: Medizinische Beurteilungen, Arztzeugnisse, Diagnosen, Behandlungsverl\\u00e4ufe, Therapiepl\\u00e4ne, Ergebnisse von Untersuchungen und Laborberichten, etc.;<\\/li><li data-list-item-id=\\\"e7d947e383df5c177d3b495d1e1f39ca8\\\">Identit\\u00e4tsangaben: Daten zur Feststellung Ihrer Identit\\u00e4t, z.B. ID, etc.<\\/li><li data-list-item-id=\\\"e8231f2a04bb9589a825826ab997ff5ef\\\">Interessen und Pr\\u00e4ferenzen: Von Ihnen bereitgestellte oder erfasste Informationen \\u00fcber Ihre Interessenbereiche, z. B. die f\\u00fcr Sie interessanten Produkte, Hobbies und weitere pers\\u00f6nliche Pr\\u00e4ferenzen.;<\\/li><li data-list-item-id=\\\"ed012a16dbce9e498bbf2acc5efa31deb\\\">Kontaktdaten: Name, Adresse, Telefonnummer, E-Mail-Adresse;<\\/li><li data-list-item-id=\\\"e8700f8c2ada0c0a8a70315dd3ed8ea7b\\\">Kontaktdaten erweitert: Daten zum Ehegatten oder Kindern, Familienstand, Portraitfoto, Ehrenamt, Berufsbezeichnung, beruflicher Werdegang, Betriebszugeh\\u00f6rigkeit, Aufgaben, T\\u00e4tigkeiten, Qualifikationen, Bewertungen \\/ Beurteilungen, Zertifikate, Geburtsdatum etc.;<\\/li><li data-list-item-id=\\\"eb384bfae041adfe11890f99116a499a3\\\">Kontaktdaten beruflich: Name, Vorname, Anrede, Anschrift, E-Mail-Adresse, Telefon-nummer, Mobiltelefonnummer, Arbeitgeber, Funktion, Abteilung, Zust\\u00e4ndigkeiten, etc.;<\\/li><li data-list-item-id=\\\"ee2da6756679841591128e315c225aa20\\\">Nutzungsdaten der Website: Die IP-Adresse, Art und Version des Browsers, verwende-tes Betriebssystem und Ger\\u00e4tetyp, Referrer URL (die vorherige Website, von der aus Sie auf unsere Seite gelangt sind), den Internet-Service-Provider, Hostname des zugreifen-den Computers, Zeitpunkt der Serveranfrage, etc. Sie geben uns auch Informationen dar\\u00fcber, wie Sie die Website nutzen. Die Datenbearbeitung bei der Nutzung der Website und der App einschliesslich des Trackings mit Cookies erl\\u00e4utern wir in den Hinweisen zur Website.;<\\/li><li data-list-item-id=\\\"e5ee60508830bda8563031d5478c4dc57\\\">Technische Daten: Daten zu technischen Gegebenheiten der Systeme, wie Konfiguratio-nen, IP-Adressen, Seriennummern, Produktinformationen, Lizenzen, Dokumentationen, etc.<\\/li><li data-list-item-id=\\\"ee007410a2f398958134d7f9e58bb702c\\\">Vertragsdaten: Daten zur Gesch\\u00e4ftsbeziehung, Kundennummer, Angebote und gekaufte Produkte, Dienstleistungen oder Services (inkl. Online-Services, Datum Vertrag, Kauf-preis, Sonderw\\u00fcnsche, Garantien, Kulanz, etc.;<\\/li><li data-list-item-id=\\\"e9fad143dbbb98fa2ad39ce43d201c792\\\">Zugangsdaten: Zugangsdaten zur Authentifizierung in Systemen.<\\/li><\\/ul>\",\"linkToTop\":\"0\",\"editlock\":\"0\",\"rowDescription\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\",\"crdate\":1785748012,\"t3ver_stage\":0,\"tstamp\":1785748012,\"uid\":9}',0,'0400$bWlmv5t-KNLhV0aAjLMujzc9gQvmuA3T:367f4f227870d8e2a11496a182574aa3'),
(86,1785748214,3,'BE',2,0,7,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1785747362,\"sorting\":1290},\"newData\":{\"tstamp\":1785748214,\"sorting\":384,\"pid\":1}}',0,'0400$ubWgs6E56i5kPOkWH5MutBp3dvIaL14K:ea41b626baac59a1fe0716bc344af5d9'),
(87,1785748214,2,'BE',2,0,7,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$Pa9BRZ61NyWx6YpxXQ7wml68vMNfO2O5:ea41b626baac59a1fe0716bc344af5d9'),
(88,1785748229,3,'BE',2,0,7,'tt_content','{\"oldData\":{\"pid\":1,\"tstamp\":1785748214,\"sorting\":384},\"newData\":{\"tstamp\":1785748229,\"sorting\":640,\"pid\":1}}',0,'0400$bguX9TibbQM_i5dK4rh0PfBM4foHMzEY:ea41b626baac59a1fe0716bc344af5d9'),
(89,1785748737,2,'BE',2,0,1,'lueg_ausbildung_items','{\"oldRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p><ul><li>Abgeschlossene obligatorische Schulzeit<\\/li><li>Einf\\u00fchlungsverm\\u00f6gen und Freude an der Kommunikation<\\/li><li>Aufmerksamkeit und Sorgfalt<\\/li><li>Verantwortungsbewusstsein<\\/li><\\/ul><p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p><ul><li>Mindestens 22 Jahre alt<\\/li><li>Mindestens 2 Jahre zu 60 Prozent im Berufsfeld Pflege gearbeitet<\\/li><li>Gute Deutschkenntnisse<\\/li><\\/ul>\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"content\":\"<p><strong>Voraussetzungen FaGe Lehre<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"e378522b5fd3817e204d231e18a896c08\\\">Abgeschlossene obligatorische Schulzeit<\\/li><li data-list-item-id=\\\"eb0b4d375d6b9a81b8bf691a5727dcfe2\\\">Einf\\u00fchlungsverm\\u00f6gen, wertsch\\u00e4tzende Grundhaltung und Freude an der Kommunikation<\\/li><li data-list-item-id=\\\"ee1e438cf4c182c8d422e28bf908b4bb6\\\">Aufmerksamkeit und Sorgfalt<\\/li><li data-list-item-id=\\\"ecf3c6621fdedca1f89d0bd88736e1d1c\\\">Flexibilit\\u00e4t und Organisationstalent<\\/li><li data-list-item-id=\\\"e1675db02db4bce2d285e2771b5b77466\\\">Verantwortungsbewusstsein<\\/li><li data-list-item-id=\\\"e3f8ca5bb1c96187b9696dd73ce9f2f3e\\\">Freude mit hoher Selbst\\u00e4ndigkeit und im Team zu arbeiten<\\/li><li data-list-item-id=\\\"e0d402a34bd785928815742fcbda596bc\\\">Belastbarkeit<\\/li><li data-list-item-id=\\\"e7450638fb1d37dc29b77dafc1e364006\\\">Bereitschaft, sobald als m\\u00f6glich die Autopr\\u00fcfung zu absolvieren<\\/li><\\/ul>\\r\\n<p><strong>Voraussetzungen FaGe E (verk\\u00fcrzte Lehre f\\u00fcr Erwachsene)<\\/strong><\\/p>\\r\\n<ul><li data-list-item-id=\\\"eb44665fe731bbc479123d81973a72d85\\\">Mindestens 22 Jahre alt<\\/li><li data-list-item-id=\\\"ef15ab3516e7903e712e85160a0390bcd\\\">Mindestens 2 Jahre zu 60 Prozent oder mehr im Berufsfeld Pflege und Betreuung gearbeitet<\\/li><li data-list-item-id=\\\"e60d3dd231256f50255d39c90ecc5e9d6\\\">Ausnahme: Abschluss Pflegeassistentin: 1 Jahr Arbeitserfahrung<\\/li><li data-list-item-id=\\\"ebfe6f1c01f9bfd60f4522f2a105e5498\\\">Gute Deutschkenntnisse<\\/li><li data-list-item-id=\\\"e3c82f6f7ba46d58eaacee47b9b7795b6\\\">Gute m\\u00fcndliche und schriftliche Ausdrucksf\\u00e4higkeit<\\/li><li data-list-item-id=\\\"ea9a85af9bf1394a4101b4721b42c598e\\\">Abschluss Allgemeinbildung (ABU)<\\/li><\\/ul>\",\"l10n_diffsource\":\"{\\\"content\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$vMAuEalg3m5MziQebhJjNMTAKxfp8cNk:686d480187e1617721c3b1bb09978817');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(37,2,1785748012,'tt_content',9,9,'studio_lg',0),
(38,2,1785748621,'tt_content',3,1,'studio_lg',0),
(39,2,1785748737,'tt_content',3,1,'studio_lg',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1785485820,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1785486315,2,1,0,'',0,0,'Personal settings changed',254,'default','172.18.0.6','',-1,0,'',0,'','info',NULL,NULL),
(3,1785490037,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"SPITEX_SCHUH-77_2.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(4,1785490041,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":1,\"history\":\"1\"}',0,0,'',0,'','info',NULL,NULL),
(5,1785490041,2,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(6,1785490041,2,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(7,1785490063,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(8,1785490085,0,0,0,'',0,2,'Core: Exception handler (CLI): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'table_local\' in \'INSERT INTO\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 63',5,'php','','',-1,0,'',0,'','error',NULL,NULL),
(9,1785490101,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(10,1785490283,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(11,1785491536,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(12,1785491537,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Layouts/Default.html, line 11 at character 2. Error: The ViewHelper \"<vite:asset>\" could not be resolved.\nBased on your spelling, the system would load the class \"Praetorius\\ViteAssetCollector\\ViewHelpers\\AssetViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <vite:asset entry=\"EXT:site_package/Resources/Private/Frontend/main.js\"/> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.6','',-1,0,'',0,'','error',NULL,NULL),
(13,1785491538,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Layouts/Default.html, line 11 at character 2. Error: The ViewHelper \"<vite:asset>\" could not be resolved.\nBased on your spelling, the system would load the class \"Praetorius\\ViteAssetCollector\\ViewHelpers\\AssetViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: <vite:asset entry=\"EXT:site_package/Resources/Private/Frontend/main.js\"/> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.6','',-1,0,'',0,'','error',NULL,NULL),
(14,1785491602,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(15,1785491657,2,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(16,1785491662,2,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"history\":\"5\"}',1,0,'',0,'','info',NULL,NULL),
(17,1785491690,2,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(18,1785491694,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"history\":\"7\"}',1,0,'',0,'','info',NULL,NULL),
(19,1785491709,2,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(20,1785491735,2,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(21,1785491741,2,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"history\":\"10\"}',1,0,'',0,'','info',NULL,NULL),
(22,1785491743,2,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"history\":\"11\"}',1,0,'',0,'','info',NULL,NULL),
(23,1785491929,2,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(24,1785491933,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"history\":\"13\"}',1,0,'',0,'','info',NULL,NULL),
(25,1785491942,2,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(26,1785491945,2,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"pages\",\"uid\":7,\"history\":\"15\"}',1,0,'',0,'','info',NULL,NULL),
(27,1785492158,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(28,1785492970,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(29,1785492999,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(30,1785493028,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(31,1785496913,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(32,1785498371,2,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"16\"}',1,0,'',0,'','info',NULL,NULL),
(33,1785498371,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"17\"}',1,0,'',0,'','info',NULL,NULL),
(34,1785498371,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"18\"}',1,0,'',0,'','info',NULL,NULL),
(35,1785498403,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(36,1785498504,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Homepage\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(37,1785498514,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"podcasts\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(38,1785498521,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"test.jpg\",\"destination\":\"\\/user_upload\\/podcasts\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(39,1785498532,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"19\"}',1,0,'',0,'','info',NULL,NULL),
(40,1785498532,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"20\"}',1,0,'',0,'','info',NULL,NULL),
(41,1785498532,2,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(42,1785498532,2,2,1,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":1,\"history\":\"22\"}',1,0,'',0,'','info',NULL,NULL),
(43,1785498532,2,3,5,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(44,1785498691,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Bildschirmfoto 2026-07-31 um 13.51.25.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(45,1785498693,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"24\"}',1,0,'',0,'','info',NULL,NULL),
(46,1785498693,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"25\"}',1,0,'',0,'','info',NULL,NULL),
(47,1785498693,2,2,8,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":8,\"history\":\"26\"}',1,0,'',0,'','info',NULL,NULL),
(48,1785498693,2,2,6,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":6,\"history\":\"27\"}',1,0,'',0,'','info',NULL,NULL),
(49,1785498693,2,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(50,1785498693,2,2,2,'lueg_podcasts_episodes',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_podcasts_episodes\",\"uid\":2,\"history\":\"29\"}',1,0,'',0,'','info',NULL,NULL),
(51,1785498693,2,3,7,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(52,1785498866,2,2,9,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":9,\"history\":\"31\"}',1,0,'',0,'','info',NULL,NULL),
(53,1785498869,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(54,1785499009,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(55,1785499018,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(56,1785499594,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(57,1785500631,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(58,1785501115,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(59,1785502132,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"32\"}',1,0,'',0,'','info',NULL,NULL),
(60,1785502135,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(61,1785503682,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"33\"}',1,0,'',0,'','info',NULL,NULL),
(62,1785503682,2,2,1,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":1,\"history\":\"34\"}',1,0,'',0,'','info',NULL,NULL),
(63,1785503682,2,2,2,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":2,\"history\":\"35\"}',1,0,'',0,'','info',NULL,NULL),
(64,1785503682,2,2,3,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":3,\"history\":\"36\"}',1,0,'',0,'','info',NULL,NULL),
(65,1785503682,2,2,4,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":4,\"history\":\"37\"}',1,0,'',0,'','info',NULL,NULL),
(66,1785503682,2,2,5,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":5,\"history\":\"38\"}',1,0,'',0,'','info',NULL,NULL),
(67,1785503682,2,2,6,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":6,\"history\":\"39\"}',1,0,'',0,'','info',NULL,NULL),
(68,1785503682,2,2,7,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":7,\"history\":\"40\"}',1,0,'',0,'','info',NULL,NULL),
(69,1785503682,2,2,8,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":8,\"history\":\"41\"}',1,0,'',0,'','info',NULL,NULL),
(70,1785503682,2,2,9,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":9,\"history\":\"42\"}',1,0,'',0,'','info',NULL,NULL),
(71,1785503682,2,2,10,'lueg_benefits_tiles',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"lueg_benefits_tiles\",\"uid\":10,\"history\":\"43\"}',1,0,'',0,'','info',NULL,NULL),
(72,1785509214,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"standort-weier.jpg\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(73,1785509265,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"spitexlueg-standort-hasle-ruegsau-66ce164d-b34837ab@1126w2x.webp\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(74,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"44\"}',1,0,'',0,'','info',NULL,NULL),
(75,1785509276,2,1,24,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(76,1785509276,2,1,25,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(77,1785509276,2,2,22,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":22,\"history\":\"47\"}',1,0,'',0,'','info',NULL,NULL),
(78,1785509276,2,2,23,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":23,\"history\":\"48\"}',1,0,'',0,'','info',NULL,NULL),
(79,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"49\"}',1,0,'',0,'','info',NULL,NULL),
(80,1785509276,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"50\"}',1,0,'',0,'','info',NULL,NULL),
(81,1785509276,2,3,20,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(82,1785509276,2,3,21,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(83,1785509279,2,2,24,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":24,\"history\":\"53\"}',1,0,'',0,'','info',NULL,NULL),
(84,1785509279,2,2,25,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"history\":\"54\"}',1,0,'',0,'','info',NULL,NULL),
(85,1785509423,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"Frontbild_SR_2.webp\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(86,1785509465,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.6','{\"identifier\":\"spitexlueg-standort-wynigen-b4063791-b34837ab@1126w2x.webp\",\"destination\":\"\\/user_upload\\/Homepage\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(87,1785509487,2,1,26,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":26,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(88,1785509487,2,1,27,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":27,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(89,1785509487,2,1,28,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":28,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(90,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(91,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(92,1785509487,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',1,0,'',0,'','info',NULL,NULL),
(93,1785509487,2,3,25,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(94,1785509487,2,3,22,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(95,1785509487,2,3,23,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(96,1785509547,2,2,26,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":26,\"history\":\"61\"}',1,0,'',0,'','info',NULL,NULL),
(97,1785509547,2,2,27,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":27,\"history\":\"62\"}',1,0,'',0,'','info',NULL,NULL),
(98,1785509547,2,2,28,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.6','{\"table\":\"sys_file_reference\",\"uid\":28,\"history\":\"63\"}',1,0,'',0,'','info',NULL,NULL),
(99,1785509549,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.6','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(100,1785740600,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"studio_lg\"]',-1,-99,'',0,'','info',NULL,NULL),
(101,1785740613,2,6,0,'',0,1,'File or directory \"{identifier}\" already exists',2,'file','172.18.0.5','{\"identifier\":\"Icons\"}',-1,0,'',0,'','info',NULL,NULL),
(102,1785742992,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"icons OK\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(103,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"TEAM-EVENTS.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(104,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Chat.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(105,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Fitness.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(106,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Mobilitaet.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(107,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"MITGESTALTUNG.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(108,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Pin.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(109,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Familie.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(110,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Grippe.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(111,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"win a collegue.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(112,1785743003,2,1,0,'',0,0,'File \"{identifier}\" uploaded to \"{destination}\"',2,'file','172.18.0.5','{\"identifier\":\"Ausbildung.svg\",\"destination\":\"\\/user_upload\\/icons_OK\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(113,1785743102,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(114,1785745609,2,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(115,1785745614,2,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"history\":\"65\"}',1,0,'',0,'','info',NULL,NULL),
(116,1785746317,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(117,1785746374,2,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"66\"}',1,0,'',0,'','info',NULL,NULL),
(118,1785746374,2,2,1,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":1,\"history\":\"67\"}',1,0,'',0,'','info',NULL,NULL),
(119,1785746374,2,2,2,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":2,\"history\":\"68\"}',1,0,'',0,'','info',NULL,NULL),
(120,1785746374,2,2,3,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":3,\"history\":\"69\"}',1,0,'',0,'','info',NULL,NULL),
(121,1785746374,2,2,4,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":4,\"history\":\"70\"}',1,0,'',0,'','info',NULL,NULL),
(122,1785746374,2,2,5,'lueg_stellen_stellen',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_stellen_stellen\",\"uid\":5,\"history\":\"71\"}',1,0,'',0,'','info',NULL,NULL),
(123,1785746396,2,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"72\"}',1,0,'',0,'','info',NULL,NULL),
(124,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(125,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(126,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(127,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(128,1785746550,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1407060572: Fluid parse error in template /var/www/html/vendor/lueg/site-package/Resources/Private/Templates/News/List.html, line 12 at character 91. Error: The ViewHelper \"<f:transform>\" could not be resolved.\nBased on your spelling, the system would load the class \"TYPO3Fluid\\Fluid\\ViewHelpers\\TransformViewHelper\", however this class does not exist. (error code 1407060572). Template source chunk: </f:transform> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 130. Requested URL: https://lueg.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(129,1785746643,2,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"73\"}',1,0,'',0,'','info',NULL,NULL),
(130,1785746680,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"74\"}',1,0,'',0,'','info',NULL,NULL),
(131,1785746881,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(132,1785746902,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"75\"}',1,0,'',0,'','info',NULL,NULL),
(133,1785746910,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"76\"}',1,0,'',0,'','info',NULL,NULL),
(134,1785746910,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"77\"}',1,0,'',0,'','info',NULL,NULL),
(135,1785746910,2,2,2,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":2,\"history\":\"78\"}',1,0,'',0,'','info',NULL,NULL),
(136,1785746910,2,2,3,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":3,\"history\":\"79\"}',1,0,'',0,'','info',NULL,NULL),
(137,1785747276,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"80\"}',1,0,'',0,'','info',NULL,NULL),
(138,1785747294,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"81\"}',1,0,'',0,'','info',NULL,NULL),
(139,1785747529,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(140,1785747720,2,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(141,1785747723,2,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"83\"}',1,0,'',0,'','info',NULL,NULL),
(142,1785747726,2,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"84\"}',1,0,'',0,'','info',NULL,NULL),
(143,1785747994,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(144,1785748012,2,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(145,1785748080,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"studio_lg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(146,1785748214,2,4,7,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(147,1785748214,2,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"87\"}',1,0,'',0,'','info',NULL,NULL),
(148,1785748229,2,4,7,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(149,1785748737,2,2,1,'lueg_ausbildung_items',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"lueg_ausbildung_items\",\"uid\":1,\"history\":\"89\"}',1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL,
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('0157c3fc784638c036e41226d1f21682','sys_file',29,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('032c9455240737904f045d3fb40ed1d2','sys_file',16,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('06ca32ac6eb0e64f5da705b5c35de5b7','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('07a8cafecf0b85c1a89c84ab57172544','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('10e7ac050b17195f9b3dca4e5adddad0','lueg_benefits_tiles',5,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('12436f0c9c5f822e95d1eac7447dbe47','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',1,0,'lueg_stellen_stellen',2,'',0,0,2147483647,0,0,''),
('1891e5b68039b20ea9ed0acf765648c4','sys_file',11,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('1c382bc93ac30b52eaf2ada5cc3ded1c','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',2,0,'lueg_benefits_tiles',3,'',0,0,2147483647,0,0,''),
('1debe5f1ff14e3f1360d692113b41c1f','tt_content',2,'lueg_podcasts_episodes',0,0,2147483647,0,'','','',1,0,'lueg_podcasts_episodes',2,'',0,0,2147483647,0,0,''),
('27b62ed56b876e5330b7b7d9eb55d72e','tt_content',5,'lueg_standorte_pin2_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',26,'',0,0,2147483647,0,0,''),
('2906231fdf5b506019bbc975da352cd3','tt_content',5,'lueg_standorte_pin4_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',28,'',0,0,2147483647,0,0,''),
('2932310b34b3604c71486e46f971e5e5','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',8,0,'lueg_benefits_tiles',9,'',0,0,2147483647,0,0,''),
('2e7772355450c1ca9600404b666a9f15','lueg_benefits_tiles',6,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',15,'',0,0,2147483647,0,0,''),
('31bcb916b23fca2191523336f3f8977b','lueg_benefits_tiles',1,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('34a346792c831418b0b2e95e4674867f','lueg_podcasts_episodes',2,'poster',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('40cdf7c8459e145b7ee98da411dd53f2','pages',1,'media',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('41170785eb716bc6bf2dfd49e8b7880d','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',4,0,'lueg_benefits_tiles',5,'',0,0,2147483647,0,0,''),
('43c11b7c2d075b45c65be6b7b0d1a017','sys_file',23,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('48c9b53b5c4f85e504ab82e6fde40c97','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',4,0,'lueg_stellen_stellen',5,'',0,0,2147483647,0,0,''),
('49a1dca9b44dbc2f1878bcbdb69eaa56','sys_file',20,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',20,'',0,0,2147483647,0,0,''),
('531f57caee814017df3806a1886a5753','lueg_benefits_tiles',9,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',18,'',0,0,2147483647,0,0,''),
('56336f58f29686eb54502ae7cf4e3728','sys_file',32,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('584487dceb88c30c8f4fdcef5662f571','lueg_benefits_tiles',4,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('59c7319c41b3f5fd154aab420e38af03','sys_file',15,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('5eabf5fd76d603ac826d76f818a28377','tt_content',7,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('63394b2fc893d034b736bc059fc3097b','sys_file_reference',27,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('64f91d9385c66159e0535b5b94f95d8f','sys_file',25,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('656b2851ee7dddc375e1caf43969289a','sys_file',26,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('69982b2a98cbef53cc80295c48be6116','sys_file',17,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6a94b41f5ae34b7bae0ec9070182ed92','sys_file',13,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6bbb48189e40223a6f1b944a8c1e11a5','lueg_benefits_tiles',8,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',17,'',0,0,2147483647,0,0,''),
('70309932df13074e9719fed1f2f5a380','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',0,0,'lueg_benefits_tiles',1,'',0,0,2147483647,0,0,''),
('731a3e934d4284dc1337694ff2a2e91a','sys_file',22,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('74f89f508a8d8465607d030c6629dc92','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('75e554675bdff6fb7eb7fac50561d72d','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',3,0,'lueg_stellen_stellen',4,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('7ddeabd5bec17a9da953ae45845d3a2c','tt_content',5,'lueg_standorte_pin1_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',24,'',0,0,2147483647,0,0,''),
('7fa40541aaf322ad3877e351b6d4541d','lueg_benefits_tiles',10,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('80ffd427efd1ab09fe204d5356a348e3','sys_file',31,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('810777333f9c8ac6fb2e4554afe693a5','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',2,0,'lueg_stellen_stellen',3,'',0,0,2147483647,0,0,''),
('85ce5f98e1d11d3a63413f8c25da17d8','sys_file',19,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('88c80057eb453b13de190fd8ad9a7f5d','sys_file',28,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('8c35623f6d2e812f184755b0e9da5f00','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',9,0,'lueg_benefits_tiles',10,'',0,0,2147483647,0,0,''),
('911e3ac73be2b6eda62728c9565cce71','tt_content',9,'bodytext',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'privacy@impunix.ch'),
('94ae29634a690fa96fe9fbcec4aa56f5','lueg_benefits_tiles',7,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('9582bb2310aa3295376e517d36d54791','tt_content',5,'lueg_standorte_pin3_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',27,'',0,0,2147483647,0,0,''),
('9752b282c0d432837f1bbed545654b32','lueg_podcasts_episodes',2,'mediafile',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('9c892dd54a2813a95c126ed46c1af1e7','sys_file',30,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('9f4f80f7417765a1fd405687474b2680','sys_file',18,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a21506ca9162f75c863170914a766564','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a71d156cbbc1fd0aea0e6f9e84024815','sys_file',14,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a7f01a3638670898c734e94169bb1838','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',7,0,'lueg_benefits_tiles',8,'',0,0,2147483647,0,0,''),
('a8ae560441da233771408a7e6b28c1b6','sys_file',20,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a8b4e24168e192fb3cc844f511bb2601','lueg_podcasts_episodes',1,'poster',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b52b3687ca0340b281d2f547cd5d35ea','sys_file_reference',28,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('ba40b368f96510ff2ffaec95e134ea75','lueg_benefits_tiles',2,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',11,'',0,0,2147483647,0,0,''),
('bd871a48b5b62b0393e1bbfcd4306088','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',1,0,'lueg_benefits_tiles',2,'',0,0,2147483647,0,0,''),
('bdee36aee3aecbf9eb6a414e9ff6dafa','lueg_benefits_tiles',3,'icon',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('bef4c06bde2f3af98649fb668f472127','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',5,0,'lueg_benefits_tiles',6,'',0,0,2147483647,0,0,''),
('c2f9b2aa0e2662b2247f3cef3f69e9f3','tt_content',3,'lueg_ausbildung_items',0,0,2147483647,0,'','','',2,0,'lueg_ausbildung_items',3,'',0,0,2147483647,0,0,''),
('cc38ad8c255193f5cbeb15f85896b92e','tt_content',2,'lueg_podcasts_episodes',0,0,2147483647,0,'','','',0,0,'lueg_podcasts_episodes',1,'',0,0,2147483647,0,0,''),
('ccc76f735cb38dca39df162b0b627353','sys_file',12,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('d13168be0bea9b8c9787d6ab86e5f654','tt_content',3,'lueg_ausbildung_items',0,0,2147483647,0,'','','',0,0,'lueg_ausbildung_items',1,'',0,0,2147483647,0,0,''),
('d67db873aebd3c6e2630c34cfa1a7f9a','tt_content',6,'lueg_stellen_stellen',0,0,2147483647,0,'','','',0,0,'lueg_stellen_stellen',1,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('dab1afc2e3d19ecaa9f15b9368559a6b','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',3,0,'lueg_benefits_tiles',4,'',0,0,2147483647,0,0,''),
('db2015faae619ad98a32fd8044806f55','sys_file_reference',26,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('ddb0486620e0393165318a07cbbc4b8e','sys_file',21,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('e4af88b058a534b7664d8b65f3c075cc','tt_content',4,'lueg_benefits_tiles',0,0,2147483647,0,'','','',6,0,'lueg_benefits_tiles',7,'',0,0,2147483647,0,0,''),
('e660a0426c3c9494add60c131e202199','sys_file',27,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('e94a2ecd669824a1cb80959e7df9156d','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('eaa9218683f19d5bd2aff3f3bac7ebb3','tt_content',3,'lueg_ausbildung_items',0,0,2147483647,0,'','','',1,0,'lueg_ausbildung_items',2,'',0,0,2147483647,0,0,''),
('f0d49e18db70a622c6f1679c438f280b','sys_file_reference',24,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('f314d7d7160398937ff84f7b9d34bba8','sys_file',24,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f6062209d87aa82eace335f4ab0c7610','sys_file',10,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f878cf5ef918189e175dcf8358956cda','lueg_podcasts_episodes',1,'mediafile',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Scheduler\\Migration\\SchedulerDatabaseStorageMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(13,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(14,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','scheduler:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','lowlevel:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','site_package:ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','lueg/project:ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','typo3/app:ext_tables_static+adt.sql','s:0:\"\";'),
(42,'core','formProtectionSessionToken:2','s:64:\"307a4ce6a9c8026f6b273f0115b01c1eaac8f76b9e998514cbcb820e4b4c7c9c\";'),
(43,'extensionDataImport','content_blocks:ext_tables_static+adt.sql','s:0:\"\";'),
(44,'extensionDataImport','news:ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL,
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_podcasts_episodes` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_ausbildung_items` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_benefits_tiles` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin1_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin1_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin1_address` longtext DEFAULT NULL,
  `lueg_standorte_pin1_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin2_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin2_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin2_address` longtext DEFAULT NULL,
  `lueg_standorte_pin2_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin3_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin3_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin3_address` longtext DEFAULT NULL,
  `lueg_standorte_pin3_link` text NOT NULL DEFAULT '',
  `lueg_standorte_pin4_image` int(10) unsigned NOT NULL DEFAULT 0,
  `lueg_standorte_pin4_title` varchar(255) NOT NULL DEFAULT '',
  `lueg_standorte_pin4_address` longtext DEFAULT NULL,
  `lueg_standorte_pin4_link` text NOT NULL DEFAULT '',
  `lueg_stellen_stellen` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1785502132,1785493511,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_headline_text',0,0,'','',0,'Lueg – dini Zuekunft, bir Spitex Region Lueg',0,'','','','<p><strong>Wir suchen ausgebildete Fachkräfte, Quereinsteiger:innen und Lernende.</strong></p>\r\n<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll – genau das macht sie so wertvoll.</p>\r\n<p>Wir unterstützen unsere Mitarbeitenden aktiv in ihrer fachlichen Weiterentwicklung und eröffnen ihnen die Möglichkeit, Verantwortung zu übernehmen, beispielsweise in Spezialfunktionen.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0),
(2,1,1785498371,1785497882,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_podcasts_episodes\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_podcasts',0,0,'','',0,'Lueg – u los ine',0,'','','','<p>In dieser Podcast-Serie erzählen unsere Mitarbeitenden aus ihrem Alltag in der ambulanten Pflege – ehrlich, persönlich und mit Geschichten, die zeigen, warum genau du hier richtig bist.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0),
(3,1,1785747294,1785502894,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_ausbildung_items\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_ausbildung',0,0,'','',0,'Lueg – mir biude <br> Lernendi us',0,'','','','<p>Die Arbeit mit Menschen gibt dir echten Sinn. Damit unsere Klientinnen und Klienten jederzeit top betreut sind, bildet die Spitex Region Lueg Fachfrauen und Fachmänner Gesundheit (FaGe) aus. Bei uns wirst du Schritt für Schritt begleitet – individuell, persönlich und immer auf deinem Weg.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,3,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0),
(4,1,1785746902,1785503461,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_benefits_tiles\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_benefits',0,0,'','',0,'Lueg – <br>was mir dir biete',0,'','','','<p>Wir sind ein moderner, innovativer Arbeitgeber mit guter Infrastruktur, zeitgemässen Arbeitsmitteln und Offenheit für neue Methoden. Wir kommunizieren auf Augenhöhe und leben eine offene, wertschätzende Teamkultur.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,10,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0),
(5,1,1785746680,1785507434,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_standorte_pin1_address\":\"\",\"lueg_standorte_pin1_image\":\"\",\"lueg_standorte_pin1_link\":\"\",\"lueg_standorte_pin1_title\":\"\",\"lueg_standorte_pin2_address\":\"\",\"lueg_standorte_pin2_image\":\"\",\"lueg_standorte_pin2_link\":\"\",\"lueg_standorte_pin2_title\":\"\",\"lueg_standorte_pin3_address\":\"\",\"lueg_standorte_pin3_image\":\"\",\"lueg_standorte_pin3_link\":\"\",\"lueg_standorte_pin3_title\":\"\",\"lueg_standorte_pin4_address\":\"\",\"lueg_standorte_pin4_image\":\"\",\"lueg_standorte_pin4_link\":\"\",\"lueg_standorte_pin4_title\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_standorte',0,0,'','',0,'Lueg – <br>wo mir si',0,'','','','<p>Das Einzugsgebiet der Spitex Region Lueg umfasst 11 Gemeinden mit insgesamt 23’000 Einwohnerinnen und Einwohnern. Dank vier Standorten ist die Organisation in der Mitte des Emmentals präsent und bestens mit den Bedürfnissen der Bevölkerung vertraut.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,1,'Standort Weier','Huttwilwestrasse 1\r\n3462 Weier i.E','https://www.google.com/maps?q=Huttwilwestrasse+1+3462+Weier',1,'Standort Sumiswald','Marktgasse 5\r\n3454 Sumiswald','https://www.google.com/maps?q=Marktgasse+5+3454+Sumiswald',1,'Standort Affoltern','Dorfstrasse 12\r\n3416 Affoltern i.E.','https://www.google.com/maps?q=Dorfstrasse+12+3416+Affoltern',1,'Standort Hasle','Bahnhofstrasse 3\r\n3415 Hasle b.B.','https://www.google.com/maps?q=Bahnhofstrasse+3+3415+Hasle',0,0),
(6,1,1785746473,1785745312,1,0,0,0,'0',1290,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"lueg_stellen_stellen\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\"}',0,0,0,0,'default',0,NULL,0,'lueg_stellen',0,0,'','',0,'Lueg – <br>üsi freie Jobs',0,'','','','<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll. Finde hier die Stelle, die zu dir passt.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',5,0),
(7,1,1785748229,1785746473,0,0,0,0,'0',640,NULL,0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',0,NULL,0,'news_pi1',0,0,'','',0,'Lueg – <br>üsi freie Stelle',100,'','','','<p>Ein Job bei der Spitex Region Lueg bedeutet Vielfalt, Verantwortung und Sinnhaftigkeit. Unsere Arbeit ist spannend, abwechslungsreich und zugleich anspruchsvoll. Finde hier die Stelle, die zu dir passt.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0),
(8,3,1785746473,1785746473,0,0,0,0,'0',10,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'news_pi1',0,0,'','',0,'Freie Stelle',100,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0),
(9,9,1785748012,1785748012,0,0,0,0,'0',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'',0,'','','','<h2>1. Verantwortlicher im Sinne des schweizerischen Bundesgesetzes über den Datenschutz (DSG) für die hier beschriebenen Datenbearbeitungen ist:</h2>\r\n<p>SPITEX Region Lueg AG Rüegsaustrasse 8 3415 Hasle-Rüegsau</p>\r\n<p>Unser Datenschutzberater ist: impunix AG – Datenschutz Full-Service Lagerhausstrasse 18, CH-8400 Winterthur privacy@impunix.ch www.impunix.ch</p>\r\n<p>Bei Fragen oder Anliegen zum Datenschutz und zur Ausübung Ihrer Rechte wenden Sie sich bitte an diese Stelle.</p>\r\n<h2>2. Zweck der Bearbeitung im Rahmen unserer Dienstleistungen und Angebote</h2>\r\n<p>Wir beschaffen und bearbeiten die Personendaten, die wir im Rahmen unserer Geschäftstätigkeit insbesondere mit Klienten, Angehörige, Besuchern, Interessenten, Bewerbern, Geschäfts-partnern sowie weiteren beteiligten Personen erhalten oder die beim Betrieb unserer Website erhoben werden. Im letzten Kapitel ist eine Übersicht über die verwendeten Kategorien von Per-sonendaten. Sollten Sie uns Informationen über andere Personen übermitteln, vergewissern Sie sich bitte, dass diese Personen vorher informiert wurden und dass die angegebenen Daten korrekt sind. Die erhobenen Personendaten werden zur Erbringung unserer Dienstleistungen und Angebote verwendet. Dies umfasst insbesondere die Betreuung und Behandlung von Menschen aller Al-tersgruppen (ab 16. Jahren) mit vorübergehend reduzierten physischen und psychischen Kräf-ten, Menschen mit einer chronischen Erkrankung oder Einschränkung, Betagte und gebrechliche Menschen, zu Hause in der gewohnten Umgebung. Zudem können externe Dienstleister zur Erbringung dieser Leistungen eingesetzt werden. Weitere Informationen zu den Datenbearbei-tungen und deren Zwecken finden Sie in den folgenden Kapiteln.</p>\r\n<h3>2.1 Kontaktaufnahme und Kommunikation</h3>\r\n<p>Wir bearbeiten Ihre Daten zur Bearbeitung von Anfragen über das Kontaktformular, zur Bereit-stellung von Informationen über unsere Dienstleistungen sowie zur Vereinbarung von Terminen und Beratungen.</p>\r\n<h3>2.2 Klientenaufnahme (inkl. Anamnese)</h3>\r\n<p>Bei der Klientenaufnahme erheben und speichern wir Ihre Stammdaten sowie Ihre medizinische Vorgeschichte. Dies umfasst Informationen wie Name, Adresse, Geburtsdatum, Kontaktinfor-mationen und relevante Gesundheitsdaten. Diese Daten sind notwendig, um eine individuelle Behandlung planen zu können.</p>\r\n<h3>2.3 Klientenversorgung und medizinische Dienstleistungen</h3>\r\n<p>Wir bearbeiten Ihre Gesundheitsdaten, um diagnostische Untersuchungen und therapeutische Behandlungen durchzuführen. Dies beinhaltet die Nutzung medizinischer Technologien und Me-thoden. Ihre Daten werden für folgende Punkte genutzt:</p>\r\n<ul><li data-list-item-id=\"ec3ce18193255f5fde3ba54460d453b52\">Abklärung des Pflegebedarfs</li><li data-list-item-id=\"e0ad57aa9c0e13d9f23246c5e1995cf5c\">Beratung zu Angeboten</li><li data-list-item-id=\"e4bb93e37680c861b448047346e592126\">Hilfe bei der Körperpflege</li><li data-list-item-id=\"e12976d41ff5c4a54cfb440edf1045884\">Hilfe bei der Mobilisation (Aufstehen und zu Bett gehen)</li><li data-list-item-id=\"ef6b9fcaca1b8d5423af23702e1f94266\">Vorbereiten und Verabreichen von Medikamenten</li><li data-list-item-id=\"ed915f50a459dde5f50980cfa70cefe15\">Medizinische Kontrollen wie Blutzucker und Blutdruck messen etc.</li><li data-list-item-id=\"ecd19447a354f66f10f59e7371aba99dd\">Schmerzbehandlung</li><li data-list-item-id=\"ed2cb2f0f3921196d168d2a2162124621\">Pflege von Wunden</li><li data-list-item-id=\"e4f783386e772e11b268f4e4ab9a115b1\">Begleitung von Sterbenden (palliative Care)</li><li data-list-item-id=\"e38b4572e7769e9d625e5dfed1d2b314e\">Psychiatrische Pflegeleistungen</li></ul>\r\n<h3>2.4 Beratungs- und Informationsveranstaltungen</h3>\r\n<p>Wir nutzen Ihre Daten, vertraulich und anonym, für interne Weiterbilungszwecke.2.5 Notfallver-sorgung Ihre Daten werden bearbeitet, um Notfälle während der regulären Öffnungszeiten zu behandeln und um in solchen Fällen weitere organisatorische Massnahmen zu treffen.</p>\r\n<h3>2.5 Führung und Verwaltung der Klientendossiers</h3>\r\n<p>Die Verwaltung Ihrer Klientendossiers umfasst die Erfassung und Speicherung von Anamnese, Diagnose, Befunden sowie der Dokumentation Ihrer Betreuung. Zudem beinhalten die Dossiers Korrespondenzen, Rechnungen, Terminplanungen und relevante Fotos, die zur lückenlosen Dokumentation der medizinischen Geschichte notwendig sind.</p>\r\n<h3>2.6 Verwaltung der Daten zur Abrechnung</h3>\r\n<p>Zur Abrechnung unserer Leistungen verwalten wir Ihre Stamm- und Betreuungsdaten. Dies um-fasst die Kommunikation mit Sozialversicherungen, Krankenkassen und Unfallversicherungen sowie zur Einholung und Verwaltung der Kostengutsprache, gelegentlich den Austausch mit Behörden.</p>\r\n<h3>2.7 Lieferantenmanagement</h3>\r\n<p>Im Rahmen unserer Geschäftsbeziehung mit unseren Partnern oder Lieferanten erhalten wir ihre beruflichen Kontaktdaten, die wir in unseren Systemen speichern können. Dazu können auch Ihre Interessen oder Präferenzen gehören, um eine persönliche Geschäftsbeziehung zu pflegen.</p>\r\n<h3>2.8 Websites und Online-Angebote</h3>\r\n<p>Zur Erbringung unserer Dienstleistungen und zur Vermarktung unserer Angebote nutzen wir Websites und andere Online-Angebote. Wenn Sie auf unsere Website zugreifen, erheben wir Nutzungsdaten. Weitere Informationen zur Website finden Sie im entsprechenden Kapitel.</p>\r\n<h3>2.9 Printmedien</h3>\r\n<p>Wir versenden teilweise personalisierte Printmedien, wofür ihre Kontaktdaten oder berufliche Kontaktdaten bearbeitet werden. Für den Versand von Printmedien behalten wir uns vor, mit Dritten zusammenzuarbeiten und Ihre Kontaktdaten zu diesem Zweck weiterzugeben.</p>\r\n<h3>2.10 Stellenbewerbung</h3>\r\n<p>Um Ihre Eignung für ein Arbeitsverhältnis festzustellen, bearbeiten wir die Personendaten, die wir von Ihnen im Rahmen des Bewerbungsverfahrens erhalten haben. Dazu können auch Straf-register- und Betreibungsauszüge oder ähnliche Dokumente gehören. Wenn Sie Referenzen angegeben haben, können wir bei diesen Referenzen Auskünfte über Sie einholen. Sie haben das Recht zu erfahren, was uns mitgeteilt wurde. Tests, die der objektiven Feststellung der Eignung für die betreffende Stelle dienen, können Teil des Bewerbungsverfah-rens sein. Soweit es um die Feststellung der Eignung als Führungskraft geht, kann sich der Test auch auf Ihre Persönlichkeit beziehen. Sollte sich aus den eingereichten Unterlagen noch kein vollständiges und verlässliches Bild ergeben, erlauben wir uns, öffentlich zugängliche Quellen, die zur Klärung der konkreten berufli-chen Eignung geeignet sind, wie Xing oder LinkedIn, aber auch ganz allgemein Google, für die Recherche zu nutzen. Die Recherche in privaten Netzwerken wie Facebook oder Instagram ist für uns nicht relevant. Sofern objektive Gründe in Ihrer Person vorliegen, die Sie für das entsprechende Arbeitsver-hältnis einschränken oder disqualifizieren, sind Sie verpflichtet, uns diese offen zu legen. Dies kann auch eine Untersuchung Ihres Gesundheitszustandes beinhalten. Die Auskunft an uns er-folgt im gesetzlichen Rahmen</p>\r\n<h2>3. Website, Social Media und Cookie-Hinweise</h2>\r\n<p>Die Datenschutzerklärung gilt für alle betriebenen Websites, inklusive:</p>\r\n<p>luegjobs.ch</p>\r\n<p>Über die Websites werden Nutzungsdaten erfasst und automatisch in sogenannten Server-Log-Dateien gespeichert, die Ihr Browser automatisch an uns übermittelt. Diese Daten können von uns nicht bestimmten Personen zugeordnet werden. Eine Zusammenführung dieser Daten mit anderen Datenquellen wird nicht vorgenommen. Wir behalten uns jedoch vor, diese Daten nach-träglich zu prüfen, wenn wir konkrete Anhaltspunkte für eine rechtswidrige Nutzung der Websites erhalten. Aus Sicherheitsgründen und zum Schutz der übertragenen vertraulichen Inhalte, wie z.B. Anfra-gen, die Sie an uns als Website-Betreiber senden, wird auf den Websites eine SSL/TLS-Verschlüsselung eingesetzt. Die Websites können Links zu anderen Websites enthalten, die sich unserer Kontrolle entziehen und daher nicht von dieser Datenschutzerklärung abgedeckt werden. Wenn Sie diese Links nutzen und auf andere Websites zugreifen, kann es sein, dass die Betreiber dieser Websites Informationen über Sie sammeln.</p>\r\n<h3>3.1 Nutzung des Kontaktformulars</h3>\r\n<p>Auf unserer Website steht ein Kontaktformular für Fragen, Anliegen oder Informationen zur Verfügung. Ihre Personendaten werden bearbeitet, um Ihre Anfrage zu bearbeiten und Ihnen eine qualifizierte Antwort bereitzustellen. Dies umfasst die Erfassung und Speicherung Ihrer Kontaktdaten sowie der relevanten medizinischen Informationen, die Sie uns über das Kontaktfor-mular übermitteln.</p>\r\n<h3>3.2 Social Media inklusive Plugins und Pixel</h3>\r\n<p>Wir betreiben Präsenzen auf sozialen Netzwerken und anderen Plattformen, die von Dritten betrieben werden, und bearbeiten in diesem Zusammenhang Daten über Sie. Sie können uns über diese Plattformen kontaktieren und wir erhalten von diesen Plattformen Daten wie z.B. Statistiken. Die Anbieter der Plattformen können Ihre Nutzung analysieren und die Daten über Sie für eigene Zwecke wie Marketing und Marktforschung verwenden. Die Anbieter der Plattformen handeln hierbei als eigenständige verantwortliche Stelle. Weiter können wir auf unseren Webseiten auch sogenannte Plugins oder Pixel von sozialen Netzwerken wie Facebook, X ehemals Twitter, LinkedIn, Pinterest oder Instagram verwenden. Die Plugins sind für Sie jeweils erkennbar. Sind sie aktiviert, können die Betreiber der jeweiligen sozialen Netzwerke registrieren, dass Sie unsere Website besuchen. Bei der Verwendung von Pixel-Technologien werden auf unserer Website entsprechende Codes implementiert, die eine Übermittlung Ihrer Nutzungsdaten ermöglichen. Diese dienen der Reichweitenmessung unserer Social-Media-Kampagnen. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen. Die meisten dieser Anbieter befinden sich ausserhalb der Schweiz. Weitere Informationen zur Datenübermittlung ins Ausland entnehmen Sie dem entsprechenden Kapitel.</p>\r\n<h3>3.3 WhatsApp oder andere Messenger-Apps</h3>\r\n<p>Wir nutzen WhatsApp aktiv als Kommunikationsmittel und ermöglichen Ihnen die Kontaktaufnahme über diesen Dienst. Bitte beachten Sie, dass bei der Nutzung von WhatsApp in der Re-gel das Adressbuch freigegeben wird und damit Personendaten an die WhatsApp Inc.&nbsp;in die USA übermittelt werden. Wir weisen darauf hin, dass die USA vom Bundesrat als Land ohne angemessenen Datenschutz eingestuft wurde. Weitere Informationen darüber, wie und zu wel-chem Zweck WhatsApp Ihre Daten bearbeitet, finden Sie in der Datenschutzerklärung von WhatsApp.</p>\r\n<h3>3.4 Permanente Cookies oder sonstige Tracking-Technologien</h3>\r\n<p>Auf unserer Website verwenden wir in der Regel Cookies und ähnliche Technologien, um Ihren Browser oder Ihr Gerät zu identifizieren. Ein Cookie ist eine kleine Datei, die beim Besuch unse-rer Website vom verwendeten Webbrowser automatisch an Ihren Computer gesendet oder auf Ihrem Computer oder Mobilgerät gespeichert wird. Wenn Sie diese Website erneut besuchen, können wir Sie wiedererkennen, auch wenn wir nicht wissen, wer Sie sind. Neben Cookies, die nur während einer Sitzung verwendet und nach dem Besuch der Website gelöscht werden (“Session Cookies”), können Cookies auch verwendet werden, um Benutzereinstellungen und andere Informationen für einen bestimmten Zeitraum zu speichern (“permanente Cookies”). Sie können Ihren Browser jedoch so einstellen, dass er Cookies ablehnt, nur für eine Sitzung spei-chert oder andernfalls vorzeitig löscht. Die meisten Browser sind so eingestellt, dass sie Coo-kies akzeptieren. Wir verwenden permanente Cookies, um Benutzereinstellungen zu speichern (z.B. Sprache, Auto-Login), um besser zu verstehen, wie Sie unsere Angebote und Inhalte nut-zen, und um Ihnen auf Sie zugeschnittene Angebote und Werbung anzeigen zu können (was auch auf Websites anderer Unternehmen der Fall sein kann). Einige Cookies werden von uns gesetzt, andere von Vertragspartnern, mit denen wir zusammenarbeiten. Wenn Sie Cookies blockieren, kann es sein, dass einige Funktionen (z.B. Sprachauswahl, Warenkorb, Bestellvor-gang) nicht mehr funktionieren. Wenn Sie dies nicht wünschen, müssen Sie Ihren Browser bzw. Ihr E-Mail-Programm entsprechend einstellen</p>\r\n<h4>3.4.1 Google Fonts oder andere Web-Fonts</h4>\r\n<p>Diese Website verwendet sogenannte Fonts von Google oder anderen Anbietern, um eine ein-heitliche Darstellung von Schriften zu gewährleisten. Beim Aufruf der Seite lädt Ihr Browser die benötigten Fonts in den Browser-Cache, um die Texte und Schriften korrekt darzustellen. Um Ihre Privatsphäre zu schützen, haben wir die Fonts soweit möglich auf unserem eigenen Webs-erver installiert, so dass Ihre IP-Adresse beim Laden der Fonts nicht an andere Diensteanbieter weitergegeben wird. Bitte beachten Sie jedoch, dass bei der Nutzung bestimmter Dienste, wie z.B. Maps, Captcha oder Bootstrap, möglicherweise Fonts von diesen Dienstleistern verwendet werden. Falls Ihr Browser keine externen Schriften unterstützt, wird automatisch eine Stan-dardschrift Ihres Computers verwendet. Weitere Informationen zu Google Fonts und deren Da-tenschutzbestimmungen finden Sie auf der Website von Google oder des jeweiligen Anbieters.</p>\r\n<h4>3.4.2 Google Photos, Youtube oder andere Bild- und Streamingdienste</h4>\r\n<p>Auf dieser Website sind Funktionen des Google-Dienstes Photos und YouTube oder anderer Streaming-Dienste integriert. Diese verwenden wir, um Photos oder Videos auf unserer Website einzubinden. Die Plugins sind für Sie erkennbar. Die Bearbeitung Ihrer Personendaten erfolgt in der Verantwortung des jeweiligen Betreibers nach dessen Datenschutzbestimmungen.</p>\r\n<h4>3.4.3 Heyflow</h4>\r\n<p>Für unsere Bewerbungs Experience setzen wir den Dienst Heyflow der Heyflow GmbH, Deutschland (EU), ein. Dabei werden die von Ihnen eingegebenen Angaben sowie Nutzungs und Gerätedaten (z. B. IP Adresse, Zeitstempel, Interaktionen, Browser/OS, Cookies/Local Storage) zur Entgegennahme, Prüfung und Abwicklung Ihrer Bewerbung bearbeitet. Heyflow bearbeitet diese Personendaten als unser Auftragsbearbeiter. Weitere Informationen zu Heyflow und deren Datenschutzbestimmungen finden Sie auf der Website von Heyflow.</p>\r\n<h2>4. Herkunft von Personendaten</h2>\r\n<p>Die Daten, die wir bearbeiten, stammen in den meisten Fällen von Ihnen selbst, z.B. im Zusam-menhang mit der Erbringung unserer Dienstleistungen, der Nutzung unserer Website oder der Kommunikation mit uns. Wenn Sie mit uns Verträge abschliessen oder unsere Dienstleistungen in Anspruch nehmen wollen, müssen Sie uns bestimmte Daten bekannt geben. Dies gilt auch für die Nutzung unserer Website. Darüber hinaus sind Sie zur Bekanntgabe von Daten verpflich-tet, um gesetzliche Verpflichtungen zu erfüllen. Ansonsten steht es Ihnen frei, ob Sie uns Daten über sich mitteilen. Wir können Daten auch von Dritten erhalten, insbesondere von unseren externen Dienstleistern oder Vertragspartnern, von Finanzdienstleistern und Versicherungen. Darüber hinaus können wir Daten aus öffentlich zugänglichen Quellen wie Internetseiten, Unternehmensregistern, Grundbü-chern, Handelsregistern, Auskunfteien, Adresshändlern, Verbänden, Telefonbüchern, Inter-netanalysediensten erhalten.</p>\r\n<h2>5. Datenweitergabe und Datenübermittlung ins Ausland</h2>\r\n<p>Im Rahmen unserer geschäftlichen Aktivitäten und gemäss den genannten Zwecken besteht die Möglichkeit, dass wir Informationen mit Dritten teilen, insbesondere mit folgenden Kategorien von Empfängern:</p>\r\n<ul><li data-list-item-id=\"eb655ceac612723df820daa2c0d7f6f7f\">Fachspezialisten: Wir arbeiten mit Ärztinnen und Ärzten zusammen, mit denen teilweise auch Daten ausgetauscht werden;</li><li data-list-item-id=\"e8335efa95f4c68819e9cd99c861262f9\">Dienstleister: Wir arbeiten mit Dienstleistern zusammen, die Daten in unserem Auftrag oder in gemeinsamer Verantwortlichkeit bearbeiten, wie zum Beispiel Hausarztpraxen, Apotheken, Anbieter von Praxissoftware, Marketing-Agenturen oder IT-Dienstleister, sonstige Lieferanten, Geschäftspartner;</li><li data-list-item-id=\"e93cbdcaf077a67fcf0d38211148f2d63\">Behörden: Wir können Daten auch an Behörden im In- (und Ausland), Amtsstellen oder Gerichte bekanntgeben, wenn wir dazu rechtlich verpflichtet sind;</li><li data-list-item-id=\"e3b0f3783dd6cc9a0b387c0ea42cdd65c\">Finanzdienstleister und Versicherungen: Im Zusammenhang mit Bonitäts- und Versi-cherungsleistungen arbeiten wir mit Auskunfteien, Banken, Versicherungen zusammen;</li><li data-list-item-id=\"ec17b00d9c96652226b206d8e30b071cb\">Andere Dritte: Alle anderen Dritten, mit denen wir zur Erfüllung der genannten Zwecke zusammenarbeiten. Dies können beispielsweise Medien, die Öffentlichkeit, einschliess-lich Besuchern von Websites, Mitbewerbern, Branchenorganisationen, Verbände, Organisationen und weitere Gremien sein. Zusätzlich können es auch Parteien im Zusam-menhang mit einer Unternehmenstransaktion wie z. B. einer Fusion, einem Verkauf von Vermögenswerten oder Anteilen, einer Restrukturierung, einer Finanzierung, einem Kon-trollwechsel oder der Übernahme des gesamten oder eines Teils unseres Unternehmens sein.</li></ul>\r\n<p>Diese Kategorien von Empfängern können Dritte einbeziehen, denen Personendaten zugänglich gemacht werden. Dienstleister und bestimmte Vertragspartner, die in unserem Auftrag tätig sind, können wir vertraglich verpflichten, die Daten nicht für eigene Zwecke zu verwenden. An-dere Dritte wie Finanzdienstleister, Versicherungen oder Behörden verwenden die Daten für eigene Zwecke, z.B. zur Erfüllung gesetzlicher Vorgaben, weshalb wir diese Bearbeitungen nicht einschränken können. Wir bearbeiten Ihre Personendaten vorwiegend in der Schweiz. Die Personendaten können aber auch an Empfänger im Ausland bekannt gegeben werden z.B. in die USA. Darüber hinaus kön-nen die Daten in weitere Staaten des Europäischen Wirtschaftsraumes übermittelt werden. Durch die heutige globale Vernetzung und aufgrund von international tätigen Konzernen ist es zudem möglich, dass Daten überall auf der Welt bearbeitet werden können. Befindet sich ein Empfänger in einem Land ohne angemessenes gesetzliches Datenschutzniveau, werden wir unseren Lieferanten oder Partner, den Empfänger vertraglich zur Einhaltung des anwendbaren Datenschutzniveaus verpflichten, soweit er nicht bereits einem gesetzlich anerkannten Regel-werk zur Sicherstellung des Datenschutzes unterliegt und wir uns nicht auf eine Ausnahmebe-stimmung berufen können.</p>\r\n<h2>6. Dauer der Aufbewahrung von Personendaten</h2>\r\n<p>Wir bearbeiten und speichern Ihre Personendaten so lange, wie es für die Erfüllung unserer vertraglichen und gesetzlichen Pflichten oder sonst die mit der Bearbeitung verfolgten Zwecke erforderlich ist, d.h. also zum Beispiel für die Dauer der gesamten Klientenbeziehung sowie darüber hinaus gemäss den gesetzlichen Aufbewahrungs- und Dokumentationspflichten. Dabei ist es möglich, dass Personendaten für die Zeit aufbewahrt werden, in der Ansprüche gegen unser Unternehmen geltend gemacht werden können und soweit wir anderweitig gesetzlich dazu verpflichtet sind oder berechtigte Geschäftsinteressen dies erfordern (z.B. für Beweis- und Do-kumentationszwecke).</p>\r\n<h2>7. Datensicherheit</h2>\r\n<p>Wir treffen angemessene technische und organisatorische Sicherheitsvorkehrungen zum Schutz Ihrer Personendaten. Wir berücksichtigen dabei den Stand der Technik, das Risiko der Bearbei-tung, die Investitionskosten und orientieren uns neben dem Schweizer Datenschutzgesetz an der Datenschutzverordnung. Die Massnahmen sollen dazu dienen Datenschutzverletzungen, wie beispielsweise dem unberechtigten Zugriff und Missbrauch der Daten, zu verhindern. Die Auf-tragsbearbeiter, an die wir Daten weitergeben weisen wir ebenfalls an angemessene technische und organisatorische Sicherheitsvorkehrungen zu treffen. Kontaktaufnahme per E-Mail Die Kommunikation mittels E-Mail ist in der Regel nicht verschlüsselt. Werden jedoch beson-ders schützenswerte Daten ausgetauscht versenden wir diese verschlüsselt mittels HIN. Es besteht die Möglichkeit, dass Daten verloren gehen oder von Dritten abgefangen und/oder manipuliert werden können, um zum Beispiel damit die Echtheit vorzutäuschen. Wir treffen ge-eignete technische und organisatorische Sicherheitsmassnahmen, um dies innerhalb des Sys-tems zu verhindern. Dennoch kann die Vertraulichkeit von Daten bei der Übertragung jeglicher Daten per E-Mail nicht gewährleistet werden. Dieser Hinweis gilt insbesondere in Bezug auf die Übertragung von besonders schützenswerten Personendaten, übermitteln Sie uns diese nicht per E-Mail, sondern kontaktieren Sie uns vorgängig, um einen sicheren Kanal zu vereinbaren. Externe Zugriffsgeräte (PC, Smartphone etc. von Endnutzern) und Teile der zwischen dem Ab-sender und Empfänger an der Übermittlung beteiligten Infrastruktur befinden sich ausserhalb des von uns kontrollierbaren Bereichs. Wir haften nicht für Konsequenzen und Schäden, die sich aus dem elektronischen Informationsaustausch und insbesondere aus einer missbräuchli-chen Verwendung des E-Mail-Systems ergeben können. Wir behalten uns vor uns, für jeglichen vorsätzlichen Schaden, der uns aus dem Geschäftsverkehr mit der betroffenen Person über den elektronischen Informationsaustausch entsteht, schadlos zu halten. Weiter behalten wir uns vor, im Einzelfall nicht per E-Mail zu antworten oder für die per E-Mail erhaltene Auftragsertei-lung oder Information zusätzlich eine andere Form zu verlangen wie z.B. über ein Formular mit Unterschrift.</p>\r\n<h2>8. Präferenzen und automatisierte Einzelentscheidungen</h2>\r\n<p>Zur Begründung und Durchführung der Geschäftsbeziehung und auch sonst nutzen wir grund-sätzlich keine vollautomatisierte automatische Entscheidungsfindung. Sollten wir solche Verfah-ren in Einzelfällen einsetzen, werden wir Sie hierüber gesondert informieren, sofern dies gesetz-lich vorgegeben ist und Sie über die damit zusammenhängenden Rechte aufklären.</p>\r\n<h2>9. Rechte der betroffenen Personen</h2>\r\n<p>Als betroffene Person haben Sie im Zusammenhang mit der Datenbearbeitung die gesetzlich vorgesehenen Rechte. Sie haben insbesondere das Recht, Auskunft über Ihre gespeicherten Personendaten zu verlangen. Ebenso können Sie eine Berichtigung, Ergänzung, Sperrung oder Löschung Ihrer Personendaten verlangen. Des Weiteren steht es Ihnen frei, der Verwendung Ihrer Daten zu Marketingzwecken zu widersprechen. Ihre Einwilligung können Sie jederzeit mit Wirkung für die Zukunft widerrufen. Zusätzlich haben Sie das Recht, die Übertragung Ihrer Da-ten an andere Verantwortliche zu verlangen. Wir weisen jedoch darauf hin, dass wir uns das Recht vorbehalten, gesetzliche Einschränkung-gen geltend zu machen, etwa wenn wir zur Aufbewahrung oder Bearbeitung bestimmter Daten verpflichtet sind, ein berechtigtes Interesse daran haben oder die Daten zur Geltendmachung von Rechtsansprüchen benötigen. An die Stelle der Löschung tritt die Sperrung, sofern rechtli-che Hindernisse der Löschung entgegenstehen. Bitte beachten Sie, dass die Ausübung dieser Rechte mit vertraglichen Vereinbarungen in Konflikt stehen und dies Konsequenzen wie z.B. eine vorzeitige Vertragsauflösung oder Kostenfolgen nach sich ziehen kann. Wir werden Sie in einem solchen Fall vorab informieren, sofern dies nicht bereits vertraglich geregelt ist. Die Ausübung dieser Rechte setzt in der Regel voraus, dass Sie Ihre Identität eindeutig nach-weisen (z. B. durch Vorlage einer Kopie Ihres Identitätsdokuments, wenn Ihre Identität sonst nicht eindeutig ist oder nicht überprüft werden kann). Zur Geltendmachung Ihrer Rechte können Sie sich an den in Kapitel 1 genannten Datenschutzberater wenden. Jede betroffene Person hat zudem das Recht, ihre Ansprüche gerichtlich geltend zu machen oder sich bei der zuständigen Datenschutzbehörde zu beschweren. Zuständige Datenschutzbe-hörde in der Schweiz ist der Eidgenössische Datenschutz- und Öffentlichkeitsbeauftragte (https://www.edoeb.admin.ch).</p>\r\n<h2>10. Änderungen dieser Datenschutzerklärung</h2>\r\n<p>Wir können diese Datenschutzerklärung jederzeit ohne vorherige Ankündigung ändern. Diese Datenschutzerklärung ist nicht Teil eines Vertrages mit Ihnen. Es gilt grundsätzlich die jeweils aktuelle Fassung, die auf unserer Website veröffentlicht ist.</p>\r\n<h2>11. Urheberrecht und Lizenz</h2>\r\n<p>Diese Datenschutzerklärung wurde im Rahmen des Datenschutz Service von der impunix AG erstellt. Bei Fragen oder Anmerkungen dürfen Sie uns gerne über die Kontaktdaten in Kapitel 1 kontaktieren. Der Gebrauch dieser Datenschutzerklärung ist ausschliesslich Kunden unseres Datenschutz Full-Service vorbehalten.</p>\r\n<h2>12. Kategorien von Personendaten</h2>\r\n<p>Je nach Geschäftsvorfall bearbeiten wir eine oder mehrere der nachfolgenden Kategorien von Personendaten in der unten aufgelisteten Tabelle.</p>\r\n<ul><li data-list-item-id=\"e00bc9d0bb0b155afa665fecf408793d4\">Stammdaten: Daten für die Zuordnung, Behandlung und Abrechnung, wie Name, Ge-burtsdatum, Adresse, Versicherungsnummer, Klientennummer und Kontaktdaten, etc.;</li><li data-list-item-id=\"e752925bcac1946f526f48263269de94a\">Bonitäts- und Bankdaten: Lohn, Wohnkosten, frei verfügbares Einkommen, Zahlungs-verhalten, Bilanzen, Daten von Auskunfteien, Score-Werte, Vermögensverhältnisse, Kon-toverbindung, Kreditkartennummer, etc.;</li><li data-list-item-id=\"e220a6a22f5b0fb4d2cad41e8e2604a99\">Gesundheitliche und medizinische Daten: Medizinische Beurteilungen, Arztzeugnisse, Diagnosen, Behandlungsverläufe, Therapiepläne, Ergebnisse von Untersuchungen und Laborberichten, etc.;</li><li data-list-item-id=\"e7d947e383df5c177d3b495d1e1f39ca8\">Identitätsangaben: Daten zur Feststellung Ihrer Identität, z.B. ID, etc.</li><li data-list-item-id=\"e8231f2a04bb9589a825826ab997ff5ef\">Interessen und Präferenzen: Von Ihnen bereitgestellte oder erfasste Informationen über Ihre Interessenbereiche, z. B. die für Sie interessanten Produkte, Hobbies und weitere persönliche Präferenzen.;</li><li data-list-item-id=\"ed012a16dbce9e498bbf2acc5efa31deb\">Kontaktdaten: Name, Adresse, Telefonnummer, E-Mail-Adresse;</li><li data-list-item-id=\"e8700f8c2ada0c0a8a70315dd3ed8ea7b\">Kontaktdaten erweitert: Daten zum Ehegatten oder Kindern, Familienstand, Portraitfoto, Ehrenamt, Berufsbezeichnung, beruflicher Werdegang, Betriebszugehörigkeit, Aufgaben, Tätigkeiten, Qualifikationen, Bewertungen / Beurteilungen, Zertifikate, Geburtsdatum etc.;</li><li data-list-item-id=\"eb384bfae041adfe11890f99116a499a3\">Kontaktdaten beruflich: Name, Vorname, Anrede, Anschrift, E-Mail-Adresse, Telefon-nummer, Mobiltelefonnummer, Arbeitgeber, Funktion, Abteilung, Zuständigkeiten, etc.;</li><li data-list-item-id=\"ee2da6756679841591128e315c225aa20\">Nutzungsdaten der Website: Die IP-Adresse, Art und Version des Browsers, verwende-tes Betriebssystem und Gerätetyp, Referrer URL (die vorherige Website, von der aus Sie auf unsere Seite gelangt sind), den Internet-Service-Provider, Hostname des zugreifen-den Computers, Zeitpunkt der Serveranfrage, etc. Sie geben uns auch Informationen darüber, wie Sie die Website nutzen. Die Datenbearbeitung bei der Nutzung der Website und der App einschliesslich des Trackings mit Cookies erläutern wir in den Hinweisen zur Website.;</li><li data-list-item-id=\"e5ee60508830bda8563031d5478c4dc57\">Technische Daten: Daten zu technischen Gegebenheiten der Systeme, wie Konfiguratio-nen, IP-Adressen, Seriennummern, Produktinformationen, Lizenzen, Dokumentationen, etc.</li><li data-list-item-id=\"ee007410a2f398958134d7f9e58bb702c\">Vertragsdaten: Daten zur Geschäftsbeziehung, Kundennummer, Angebote und gekaufte Produkte, Dienstleistungen oder Services (inkl. Online-Services, Datum Vertrag, Kauf-preis, Sonderwünsche, Garantien, Kulanz, etc.;</li><li data-list-item-id=\"e9fad143dbbb98fa2ad39ce43d201c792\">Zugangsdaten: Zugangsdaten zur Authentifizierung in Systemen.</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,0,0,0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,'',NULL,'',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(NULL,1,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Pflegefachperson FH, Bachelor of Science in Pflege, Schwerpunkt Psychiatrie 40 – 60%','Zur Erweiterung unseres Fachteams Psychiatrie in Hasle-Rüegsau b. Burgdorf suchen wir nach Vereinbarung.','<p>Arbeitsort: Spitex Region Lueg, Hasle-Rüegsau b. Burgdorf<br>Arbeitszeiten: Montag bis Freitag – flexibel während der Bürozeiten<br>Stellenantritt: nach Vereinbarung</p>\n<h3>Deine Aufgaben</h3><ul><li>Du coachst Mitarbeitende im Pflegeprozess und in komplexen Pflegesituationen (ca. 10%)</li><li>Du übernimmst Fallführung und Pflegeorganisation für Klientinnen und Klienten</li><li>Du entwickelst gemeinsam mit Teamleitung und Qualitätsmanagement den Fachbereich Psychiatrie evidenzbasiert weiter</li><li>Du führst interne Schulungen zu Fachthemen durch</li><li>Du engagierst dich in interdisziplinären Projekten und stärkst die multiprofessionelle Zusammenarbeit</li></ul>\n<h3>Dein Profil</h3><ul><li>Bachelor of Science in Pflege, Psychiatrie oder mehrjährige Facherfahrung mit ausgewiesenem Leistungsausweis</li><li>Spitex-Erfahrung oder mehrjährige Erfahrung in der psychiatrischen Pflege</li><li>Konstruktive Haltung mit ausgeprägter Lösungsorientierung und Innovationsfreude</li><li>Klare, empathische Kommunikation auf Augenhöhe</li><li>Führerausweis Kategorie B</li></ul>\n<h3>Was wir bieten</h3><ul><li>Geregelte Arbeitszeiten (Mo–Fr) und mindestens 25 Ferientage</li><li>Echte Wertschätzung: offener Teamaustausch, Gestaltungsspielraum, Mitbestimmung</li><li>Attraktive interne und externe Weiterbildungsmöglichkeiten</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>Sorgfältige Einführung und starke Teamunterstützung</li><li>Moderne Infrastruktur</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pflegefachperson-fh-psychiatrie-40-60',NULL,'',0.5,'',''),
(NULL,2,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Pflegeassistent/in oder Pflegehelfende SRK 40-50%','Für unseren Standort Weier i. E. suchen wir nach Vereinbarung.','<p>Arbeitsort: Weier i. E.<br>Stellenantritt: nach Vereinbarung</p>\n<h3>Ihre Aufgaben</h3><ul><li>Sie führen eine kompetente, bedarfsgerechte Grundpflege bei Klientinnen und Klienten in stabilen Situationen durch</li><li>Sie arbeiten selbständig und übernehmen Eigenverantwortung</li><li>Sie führen eine professionelle Pflegedokumentation</li></ul>\n<h3>Ihr Profil</h3><ul><li>Abgeschlossene Ausbildung als Pflegehelfende SRK oder Pflegeassistent/-in</li><li>Mindestens ein Jahr Berufserfahrung in der Pflege</li><li>Empathisch, einfühlsam und hilfsbereit</li><li>Führerausweis sowie eigenes Auto</li></ul>\n<h3>Ihre Vorteile</h3><ul><li>Kommunikation auf Augenhöhe</li><li>Vielfältige interne und externe Weiterbildungsmöglichkeiten</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>5 Wochen Ferien als Grundguthaben</li><li>Sorgfältige Einführung und starke Teamunterstützung</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch<br>SPITEX Region Lueg, Personalabteilung, Rüegsaustrasse 8, Postfach, 3415 Hasle-Rüegsau</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'pflegeassistent-pflegehelfende-srk-40-50',NULL,'',0.5,'',''),
(NULL,3,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Fachfrau / Fachmann Gesundheit EFZ, mit / ohne Berufsbildner 50-80 %','Für unsere Standorte suchen wir ab sofort oder nach Vereinbarung.','<p>Stellenantritt: ab sofort oder nach Vereinbarung</p>\n<h3>Ihre Aufgaben</h3><ul><li>Sie stellen eine bedürfnisorientierte, bedarfs- und fachgerechte Pflege und Beratung unserer Klientinnen und Klienten zu Hause sicher</li><li>Sie übernehmen Mitverantwortung in der Fallführung als zweite Bezugsperson</li><li>Sie erfassen und dokumentieren Pflegeleistungen</li><li>Sie begleiten Lernende im Alltag</li></ul>\n<h3>Ihr Profil</h3><ul><li>Abgeschlossene Ausbildung als Fachfrau/Fachmann Gesundheit</li><li>Achtsamkeit, Engagement und Empathie für unsere Klientinnen und Klienten</li><li>Flexibilität in der Arbeitsorganisation</li><li>Führerausweis, gute Fahrpraxis und eigenes Auto</li></ul>\n<h3>Ihre Vorteile</h3><ul><li>Kommunikation auf Augenhöhe</li><li>Vielfältige interne und externe Weiterbildungsangebote</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>5 Wochen Ferien als Grundguthaben</li><li>Sorgfältige Einführung und starke Teamunterstützung</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch<br>SPITEX Region Lueg AG, Personal, Rüegsaustrasse 8, Postfach, 3415 Hasle-Rüegsau</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'fachfrau-fachmann-gesundheit-efz-50-80',NULL,'',0.5,'',''),
(NULL,4,8,1785746122,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Dipl. Pflegefachperson HF 40-80%','Für unsere Standorte Hasle-Rüegsau, Sumiswald und Weier suchen wir ab sofort oder nach Vereinbarung.','<p>Standorte: Hasle-Rüegsau, Sumiswald und Weier<br>Stellenantritt: ab sofort oder nach Vereinbarung</p>\n<h3>Ihre Aufgaben</h3><ul><li>Sie übernehmen Verantwortung für fachliche Pflege, Betreuung und Beratung zu Hause</li><li>Sie beteiligen sich am Fallführungskonzept und tragen Mitverantwortung für den Pflegeprozess</li><li>Pflege nach Kinaesthetics-Grundsätzen</li><li>Klassifizierung der Pflegediagnostik auf Basis von NANDA</li><li>Förderliche interdisziplinäre Zusammenarbeit im Team und mit Ärztinnen und Ärzten</li></ul>\n<h3>Ihr Profil</h3><ul><li>Abgeschlossene Ausbildung zur/zum diplomierten Pflegefachperson</li><li>Achtsamkeit, Engagement und Empathie</li><li>Flexibilität in der Arbeitsorganisation</li><li>Führerausweis und gute Fahrpraxis</li></ul>\n<h3>Ihre Vorteile</h3><ul><li>Organisationskultur mit Teamgeist und Eigenverantwortung</li><li>Vielfältige interne und externe Weiterbildungsangebote</li><li>Faire Entlöhnung nach den Richtlinien des Kantonspersonals</li><li>5 Wochen Ferien als Grundguthaben</li><li>Sorgfältige Einführung</li></ul>\n<h3>Kontakt &amp; Bewerbung</h3><p>Anita Beer, Personalleiterin · 034 460 50 00 · personal@spitexlueg.ch</p>',1785746122,0,NULL,NULL,0,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'dipl-pflegefachperson-hf-40-80',NULL,'',0.5,'',''),
(NULL,5,8,1785748739,1785746122,0,0,0,0,'0',0,0,0,0,NULL,0,NULL,0,0,0,0,0,'Lehrstelle als Fachfrau/Fachmann Gesundheit EFZ oder als FaGe E (verkürzte Ausbildung für Erwachsene)','Per 1. August 2027 bieten wir an unseren vier Standorten je eine Lehrstelle an.','<p>Stellenantritt: 1. August 2027 · vier Lehrstellen an vier Standorten</p>\n<h3>Warum Spitex?</h3><ul><li>Weil du mehr willst als einfach einen Job.</li><li>Menschen, unterwegs sein, Abwechslung – bei uns erlebst du jeden Tag etwas Besonderes.</li></ul>\n<h3>Drei Gründe für deine Lehre bei uns</h3><ul><li><strong>Abwechslung pur</strong> – kein Tag ist gleich, du bist selbstständig unterwegs und lernst viele Lebensgeschichten kennen.</li><li><strong>Sinnstiftende Arbeit</strong> – du hilfst Menschen, zu Hause gut zu leben.</li><li><strong>Top Ausbildung</strong> – wir begleiten dich persönlich und bereiten dich optimal auf den Berufsalltag vor.</li></ul>\n<h3>Das bist du</h3><ul><li>offen, interessiert und zuverlässig</li><li>gerne bei Menschen zu Hause</li><li>voller Neugier auf neue Erfahrungen und Begegnungen</li></ul>\n<h3>Das erwartet dich</h3><ul><li>eine praxisnahe und vielseitige Ausbildung</li><li>spannende Einblicke in Pflege, Betreuung und Gesundheit</li><li>ein motiviertes Team, das dich unterstützt</li><li>erfahrene und engagierte Berufsbildnerinnen</li></ul>\n<h3>Zusätzliche Voraussetzungen für FaGe E</h3><ul><li>Mind. 22. Altersjahr vollendet</li><li>2 Jahre Berufserfahrung im Berufsfeld Pflege und Betreuung (85% Anstellungsgrad inkl. 25% Schulanteil)</li><li>Vorbildung: EFZ-Abschluss, Matura, gleichwertiges Diplom oder ABU-Abschluss vor Ausbildungsbeginn</li></ul>\n<h3>Kontakt</h3><p>Anita Beer, Personalleitung · 034 460 50 00 · personal@spitexlueg.ch</p>',1785746122,0,NULL,NULL,1,0,0,0,0,'0',NULL,NULL,0,0,NULL,NULL,0,0,'lehrstelle-fage-efz-fage-e-2027',NULL,'',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text DEFAULT NULL,
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_tag` VALUES
(NULL,1,8,0,0,1,0,0,0,0,NULL,NULL,0,0,0,0,'Lehrstelle','lehrstelle','',NULL,'',NULL);
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `tasktype` longtext DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  `priority` int(10) unsigned NOT NULL DEFAULT 100,
  `description` longtext DEFAULT NULL,
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `execution_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`execution_details`)),
  `nextexecution` bigint(20) NOT NULL DEFAULT 0,
  `lastexecution_time` bigint(20) NOT NULL DEFAULT 0,
  `lastexecution_failure` longtext DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `number_of_days` int(11) NOT NULL DEFAULT 0,
  `selected_tables` varchar(4000) DEFAULT '',
  `file_storage` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_backends` longtext DEFAULT NULL,
  `max_file_count` int(10) unsigned NOT NULL DEFAULT 0,
  `ip_mask` int(10) unsigned NOT NULL DEFAULT 2,
  `all_tables` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `color` varchar(7) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-03 11:20:29
